"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const auth_module_1 = require("./modules/auth/auth.module");
const users_module_1 = require("./modules/users/users.module");
const admins_module_1 = require("./modules/admins/admins.module");
const courses_module_1 = require("./modules/courses/courses.module");
const course_categories_module_1 = require("./modules/course-categories/course-categories.module");
const cart_module_1 = require("./modules/cart/cart.module");
const enrollments_module_1 = require("./modules/enrollments/enrollments.module");
const orders_module_1 = require("./modules/orders/orders.module");
const config_1 = require("@nestjs/config");
const app_config_1 = __importDefault(require("./config/app.config"));
const database_config_1 = __importDefault(require("./config/database.config"));
const jwt_config_1 = __importDefault(require("./config/jwt.config"));
const storage_config_1 = __importDefault(require("./config/storage.config"));
const razorpay_config_1 = __importDefault(require("./config/razorpay.config"));
const google_config_1 = __importDefault(require("./config/google.config"));
const firebase_config_1 = __importDefault(require("./config/firebase.config"));
const mail_config_1 = __importDefault(require("./config/mail.config"));
const database_module_1 = require("./database/database.module");
const uploads_module_1 = require("./modules/uploads/uploads.module");
const dashboard_module_1 = require("./modules/dashboard/dashboard.module");
const notifications_module_1 = require("./modules/notifications/notifications.module");
const free_courses_module_1 = require("./modules/free-courses/free-courses.module");
const marquee_module_1 = require("./modules/marquee/marquee.module");
const login_activity_module_1 = require("./modules/login-activity/login-activity.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
                load: [
                    app_config_1.default,
                    database_config_1.default,
                    jwt_config_1.default,
                    storage_config_1.default,
                    razorpay_config_1.default,
                    google_config_1.default,
                    firebase_config_1.default,
                    mail_config_1.default,
                ],
                envFilePath: ['.env'],
            }),
            database_module_1.DatabaseModule,
            auth_module_1.AuthModule,
            users_module_1.UsersModule,
            admins_module_1.AdminsModule,
            courses_module_1.CoursesModule,
            course_categories_module_1.CourseCategoriesModule,
            uploads_module_1.UploadsModule,
            cart_module_1.CartModule,
            enrollments_module_1.EnrollmentsModule,
            orders_module_1.OrdersModule,
            dashboard_module_1.DashboardModule,
            notifications_module_1.NotificationsModule,
            free_courses_module_1.FreeCoursesModule,
            marquee_module_1.MarqueeModule,
            login_activity_module_1.LoginActivityModule,
        ],
        controllers: [app_controller_1.AppController],
        providers: [app_service_1.AppService],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map