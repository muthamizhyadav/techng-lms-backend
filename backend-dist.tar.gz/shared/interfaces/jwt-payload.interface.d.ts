export interface StudentJwtPayload {
    sub: string;
    email: string;
    role: string;
    type: 'student';
    sid?: string;
    iat?: number;
    exp?: number;
}
export interface DeviceApprovalPayload {
    sub: string;
    email: string;
    role: string;
    type: 'device-approval';
    did?: string;
    iat?: number;
    exp?: number;
}
export interface GoogleOAuthStatePayload {
    type: 'oauth-state';
    did?: string;
    dn?: string;
    pf?: string;
    nonce?: string;
    iat?: number;
    exp?: number;
}
export interface AdminJwtPayload {
    sub: string;
    email: string;
    role: string;
    username?: string;
    sessionId?: string;
    type: 'admin';
    iat?: number;
    exp?: number;
}
