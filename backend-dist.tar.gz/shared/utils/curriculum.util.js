"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withCurriculumIds = exports.getLessonKey = exports.getModuleKey = void 0;
const toPlainObject = (value) => {
    if (!value)
        return {};
    return typeof value.toObject === 'function' ? value.toObject() : { ...value };
};
const getModuleKey = (module, moduleIndex) => {
    const plain = toPlainObject(module);
    const base = plain._id ?? plain.id ?? `module-${plain.order ?? moduleIndex + 1}`;
    return String(base);
};
exports.getModuleKey = getModuleKey;
const getLessonKey = (module, lesson, moduleIndex, lessonIndex) => {
    const plain = toPlainObject(lesson);
    const base = plain._id ??
        plain.id ??
        `${(0, exports.getModuleKey)(module, moduleIndex)}-lesson-${plain.order ?? lessonIndex + 1}`;
    return String(base);
};
exports.getLessonKey = getLessonKey;
const withCurriculumIds = (modules = []) => {
    return (modules || []).map((module, moduleIndex) => {
        const moduleObj = toPlainObject(module);
        const moduleKey = (0, exports.getModuleKey)(moduleObj, moduleIndex);
        const lessons = (moduleObj.lessons || []).map((lesson, lessonIndex) => {
            const lessonObj = toPlainObject(lesson);
            return {
                ...lessonObj,
                _id: (0, exports.getLessonKey)(moduleObj, lessonObj, moduleIndex, lessonIndex),
            };
        });
        return {
            ...moduleObj,
            _id: moduleKey,
            lessons,
        };
    });
};
exports.withCurriculumIds = withCurriculumIds;
//# sourceMappingURL=curriculum.util.js.map