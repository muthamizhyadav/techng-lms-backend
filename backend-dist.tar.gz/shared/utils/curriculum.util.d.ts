export declare const getModuleKey: (module: Record<string, any> | undefined, moduleIndex: number) => string;
export declare const getLessonKey: (module: Record<string, any> | undefined, lesson: Record<string, any> | undefined, moduleIndex: number, lessonIndex: number) => string;
export declare const withCurriculumIds: (modules?: any[]) => any[];
