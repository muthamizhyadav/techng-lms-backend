export declare enum AdminRole {
    ADMIN = "admin",
    SUPER_ADMIN = "super_admin",
    SUPPORT = "support",
    FINANCE = "finance",
    TRAINER = "trainer"
}
export declare enum AdminStatus {
    ACTIVE = "active",
    INACTIVE = "inactive",
    SUSPENDED = "suspended"
}
