"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminStatus = exports.AdminRole = void 0;
var AdminRole;
(function (AdminRole) {
    AdminRole["ADMIN"] = "admin";
    AdminRole["SUPER_ADMIN"] = "super_admin";
    AdminRole["SUPPORT"] = "support";
    AdminRole["FINANCE"] = "finance";
    AdminRole["TRAINER"] = "trainer";
})(AdminRole || (exports.AdminRole = AdminRole = {}));
var AdminStatus;
(function (AdminStatus) {
    AdminStatus["ACTIVE"] = "active";
    AdminStatus["INACTIVE"] = "inactive";
    AdminStatus["SUSPENDED"] = "suspended";
})(AdminStatus || (exports.AdminStatus = AdminStatus = {}));
//# sourceMappingURL=user-status.enum.js.map