export declare const ADMIN_PERMISSIONS: {
    readonly COURSE: {
        readonly CREATE: "course.create";
        readonly EDIT: "course.edit";
        readonly DELETE: "course.delete";
        readonly VIEW: "course.view";
    };
    readonly STUDENT: {
        readonly VIEW: "student.view";
        readonly EDIT: "student.edit";
        readonly SUSPEND: "student.suspend";
        readonly DELETE: "student.delete";
    };
    readonly BATCH: {
        readonly CREATE: "batch.create";
        readonly EDIT: "batch.edit";
        readonly DELETE: "batch.delete";
        readonly VIEW: "batch.view";
    };
    readonly PAYMENT: {
        readonly VIEW: "payment.view";
        readonly REFUND: "payment.refund";
        readonly CREATE: "payment.create";
    };
    readonly TRAINER: {
        readonly CREATE: "trainer.create";
        readonly EDIT: "trainer.edit";
        readonly DELETE: "trainer.delete";
        readonly VIEW: "trainer.view";
    };
    readonly ADMIN: {
        readonly CREATE: "admin.create";
        readonly EDIT: "admin.edit";
        readonly DELETE: "admin.delete";
        readonly VIEW: "admin.view";
    };
    readonly REPORT: {
        readonly VIEW: "report.view";
        readonly EXPORT: "report.export";
    };
    readonly SETTINGS: {
        readonly MANAGE: "settings.manage";
    };
};
