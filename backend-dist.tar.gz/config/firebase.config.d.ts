declare const _default: (() => {
    projectId: string;
    clientEmail: string;
    privateKey: string;
    adminPanelUrl: string;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    projectId: string;
    clientEmail: string;
    privateKey: string;
    adminPanelUrl: string;
}>;
export default _default;
