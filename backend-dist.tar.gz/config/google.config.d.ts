declare const _default: (() => {
    clientId: string;
    clientSecret: string;
    callbackUrl: string;
    frontendUrl: string;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    clientId: string;
    clientSecret: string;
    callbackUrl: string;
    frontendUrl: string;
}>;
export default _default;
