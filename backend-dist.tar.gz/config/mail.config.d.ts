declare const _default: (() => {
    host: string;
    port: number;
    secure: boolean;
    user: string;
    password: string;
    fromName: string;
    fromAddress: string;
    adminPanelUrl: string;
    studentPanelUrl: string;
    resetTokenTtlMinutes: number;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    host: string;
    port: number;
    secure: boolean;
    user: string;
    password: string;
    fromName: string;
    fromAddress: string;
    adminPanelUrl: string;
    studentPanelUrl: string;
    resetTokenTtlMinutes: number;
}>;
export default _default;
