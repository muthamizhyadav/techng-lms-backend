declare const _default: (() => {
    keyId: string;
    keySecret: string;
    currency: string;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    keyId: string;
    keySecret: string;
    currency: string;
}>;
export default _default;
