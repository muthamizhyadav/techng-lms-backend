declare const _default: (() => {
    provider: string;
    endpoint: string;
    region: string;
    accessKeyId: string;
    secretAccessKey: string;
    bucketName: string;
    publicBaseUrl: string;
    publicBucketUrl: string;
    uploadExpiresIn: number;
    maxVideoSizeMb: number;
    maxThumbnailSizeMb: number;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    provider: string;
    endpoint: string;
    region: string;
    accessKeyId: string;
    secretAccessKey: string;
    bucketName: string;
    publicBaseUrl: string;
    publicBucketUrl: string;
    uploadExpiresIn: number;
    maxVideoSizeMb: number;
    maxThumbnailSizeMb: number;
}>;
export default _default;
