declare const _default: (() => {
    nodeEnv: string;
    port: number;
    apiPrefix: string;
    bcryptRounds: number;
}) & import("@nestjs/config").ConfigFactoryKeyHost<{
    nodeEnv: string;
    port: number;
    apiPrefix: string;
    bcryptRounds: number;
}>;
export default _default;
