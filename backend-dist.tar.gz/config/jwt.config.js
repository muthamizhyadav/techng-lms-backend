"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("@nestjs/config");
exports.default = (0, config_1.registerAs)('jwt', () => ({
    student: {
        secret: process.env.JWT_SECRET,
        expiresIn: process.env.JWT_EXPIRATION || '15m',
        refreshSecret: process.env.JWT_REFRESH_SECRET,
        refreshExpiresIn: process.env.JWT_REFRESH_EXPIRATION || '7d',
    },
    admin: {
        secret: process.env.ADMIN_JWT_SECRET,
        expiresIn: process.env.ADMIN_JWT_EXPIRATION || '15m',
        refreshSecret: process.env.ADMIN_JWT_REFRESH_SECRET,
        refreshExpiresIn: process.env.ADMIN_JWT_REFRESH_EXPIRATION || '7d',
    },
}));
//# sourceMappingURL=jwt.config.js.map