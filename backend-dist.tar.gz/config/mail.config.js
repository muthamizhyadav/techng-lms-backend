"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = require("@nestjs/config");
exports.default = (0, config_1.registerAs)('mail', () => ({
    host: process.env.MAIL_HOST || 'smtpout.secureserver.net',
    port: parseInt(process.env.MAIL_PORT, 10) || 465,
    secure: (process.env.MAIL_SECURE ?? 'true').toLowerCase() !== 'false',
    user: process.env.MAIL_USER || 'connect@techng.in',
    password: process.env.MAIL_PASSWORD,
    fromName: process.env.MAIL_FROM_NAME || 'TechNG LMS',
    fromAddress: process.env.MAIL_FROM_ADDRESS ||
        process.env.MAIL_USER ||
        'connect@techng.in',
    adminPanelUrl: process.env.ADMIN_PANEL_URL ||
        process.env.FRONTEND_URL ||
        'https://lms.techng.in',
    studentPanelUrl: process.env.STUDENT_PANEL_URL ||
        process.env.FRONTEND_URL ||
        'https://lms.techng.in',
    resetTokenTtlMinutes: parseInt(process.env.MAIL_RESET_TTL_MINUTES, 10) || 60,
}));
//# sourceMappingURL=mail.config.js.map