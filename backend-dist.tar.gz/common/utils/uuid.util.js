"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateUuid = void 0;
const node_crypto_1 = require("node:crypto");
const generateUuid = () => (0, node_crypto_1.randomUUID)();
exports.generateUuid = generateUuid;
//# sourceMappingURL=uuid.util.js.map