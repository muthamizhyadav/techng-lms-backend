"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.phoneDuplicateRegex = exports.canonicalPhoneDigits = exports.compactPhone = exports.normalizeEmail = void 0;
const normalizeEmail = (email) => (email ?? '').trim().toLowerCase();
exports.normalizeEmail = normalizeEmail;
const compactPhone = (phone) => {
    if (!phone)
        return undefined;
    const trimmed = phone.trim();
    if (!trimmed)
        return undefined;
    const hasPlus = trimmed.startsWith('+');
    const digits = trimmed.replace(/\D/g, '');
    if (!digits)
        return undefined;
    return hasPlus ? `+${digits}` : digits;
};
exports.compactPhone = compactPhone;
const canonicalPhoneDigits = (phone) => {
    const compact = (0, exports.compactPhone)(phone);
    if (!compact)
        return '';
    let digits = compact.replace(/^\+/, '');
    if (digits.length === 11 && digits.startsWith('0')) {
        digits = digits.slice(1);
    }
    if (digits.length === 12 && digits.startsWith('91')) {
        digits = digits.slice(2);
    }
    return digits;
};
exports.canonicalPhoneDigits = canonicalPhoneDigits;
const phoneDuplicateRegex = (phone) => {
    const digits = (0, exports.canonicalPhoneDigits)(phone);
    if (!digits) {
        return /^$/;
    }
    const digitPattern = digits.split('').join('\\D*');
    return new RegExp(`^\\D*(?:91|0)?\\D*${digitPattern}\\D*$`);
};
exports.phoneDuplicateRegex = phoneDuplicateRegex;
//# sourceMappingURL=normalize.util.js.map