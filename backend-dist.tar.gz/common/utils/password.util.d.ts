export declare class PasswordUtil {
    static hash(password: string, rounds?: number): Promise<string>;
    static compare(password: string, hash: string): Promise<boolean>;
}
