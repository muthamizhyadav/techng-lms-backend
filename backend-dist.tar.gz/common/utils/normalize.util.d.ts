export declare const normalizeEmail: (email?: string) => string;
export declare const compactPhone: (phone?: string) => string | undefined;
export declare const canonicalPhoneDigits: (phone?: string) => string;
export declare const phoneDuplicateRegex: (phone: string) => RegExp;
