import { OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
export interface SendMailOptions {
    to: string;
    subject: string;
    html: string;
    text?: string;
}
export interface PasswordResetEmailOptions {
    to: string;
    firstName: string;
    resetUrl: string;
    expiresInMinutes: number;
}
export declare class MailService implements OnModuleInit {
    private readonly configService;
    private readonly logger;
    private transporter;
    constructor(configService: ConfigService);
    onModuleInit(): void;
    get isEnabled(): boolean;
    sendMail(options: SendMailOptions): Promise<boolean>;
    sendPasswordResetEmail(options: PasswordResetEmailOptions): Promise<boolean>;
    private escapeHtml;
}
