"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DashboardService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const user_entity_1 = require("../users/entities/user.entity");
const course_entity_1 = require("../courses/entities/course.entity");
const enrollment_entity_1 = require("../enrollments/entities/enrollment.entity");
const role_enum_1 = require("../../shared/enums/role.enum");
const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const WEEK_LENGTH = 7;
function utcDateKey(date) {
    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}
function startOfUtcDay(date) {
    return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}
let DashboardService = class DashboardService {
    constructor(userModel, courseModel, enrollmentModel) {
        this.userModel = userModel;
        this.courseModel = courseModel;
        this.enrollmentModel = enrollmentModel;
    }
    async getOverview() {
        const today = startOfUtcDay(new Date());
        const weekDays = [];
        for (let offset = WEEK_LENGTH - 1; offset >= 0; offset -= 1) {
            const date = new Date(today);
            date.setUTCDate(today.getUTCDate() - offset);
            weekDays.push({
                date,
                key: utcDateKey(date),
                label: DAY_LABELS[date.getUTCDay()],
            });
        }
        const weekStart = weekDays[0].date;
        const [totalCourses, activeCourses, publishedCourses, draftCourses, categories, totalStudents, enrolledUserIds, activeStudents, pendingStudents, totalEnrollments, completedEnrollments, completionAgg, enrollmentSeries, completionSeries, courses, recentEnrollments,] = await Promise.all([
            this.courseModel.countDocuments({ deletedAt: null }),
            this.courseModel.countDocuments({
                status: course_entity_1.CourseStatus.ACTIVE,
                deletedAt: null,
            }),
            this.courseModel.countDocuments({
                status: course_entity_1.CourseStatus.PUBLISHED,
                deletedAt: null,
            }),
            this.courseModel.countDocuments({
                status: course_entity_1.CourseStatus.DRAFT,
                deletedAt: null,
            }),
            this.courseModel.distinct('category', { deletedAt: null }),
            this.userModel.countDocuments({ deletedAt: null }),
            this.enrollmentModel.distinct('userId'),
            this.userModel.countDocuments({
                status: role_enum_1.UserStatus.ACTIVE,
                deletedAt: null,
            }),
            this.userModel.countDocuments({
                status: role_enum_1.UserStatus.PENDING,
                deletedAt: null,
            }),
            this.enrollmentModel.countDocuments({}),
            this.enrollmentModel.countDocuments({
                status: enrollment_entity_1.EnrollmentStatus.COMPLETED,
            }),
            this.enrollmentModel.aggregate([
                { $group: { _id: null, avgProgress: { $avg: '$progress' } } },
            ]),
            this.enrollmentModel.aggregate([
                { $match: { enrolledAt: { $gte: weekStart } } },
                {
                    $group: {
                        _id: {
                            $dateToString: { format: '%Y-%m-%d', date: '$enrolledAt' },
                        },
                        count: { $sum: 1 },
                    },
                },
            ]),
            this.enrollmentModel.aggregate([
                {
                    $match: {
                        status: enrollment_entity_1.EnrollmentStatus.COMPLETED,
                        updatedAt: { $gte: weekStart },
                    },
                },
                {
                    $group: {
                        _id: {
                            $dateToString: { format: '%Y-%m-%d', date: '$updatedAt' },
                        },
                        count: { $sum: 1 },
                    },
                },
            ]),
            this.courseModel
                .find({ deletedAt: null })
                .select('title category level students')
                .sort({ students: -1 })
                .limit(4)
                .lean()
                .exec(),
            this.enrollmentModel
                .find({})
                .sort({ enrolledAt: -1 })
                .limit(6)
                .lean()
                .exec(),
        ]);
        const enrollmentByDay = new Map(enrollmentSeries.map((row) => [row._id, row.count]));
        const completionByDay = new Map(completionSeries.map((row) => [row._id, row.count]));
        const weeklyEngagement = weekDays.map((day) => ({
            day: day.label,
            date: day.key,
            enrollments: enrollmentByDay.get(day.key) ?? 0,
            completions: completionByDay.get(day.key) ?? 0,
        }));
        const enrollmentsThisWeek = weeklyEngagement.reduce((sum, point) => sum + point.enrollments, 0);
        const courseIds = courses.map((course) => course._id.toString());
        const progressRows = courseIds.length
            ? await this.enrollmentModel.aggregate([
                { $match: { courseId: { $in: courseIds } } },
                {
                    $group: {
                        _id: '$courseId',
                        avgProgress: { $avg: '$progress' },
                    },
                },
            ])
            : [];
        const progressByCourse = new Map(progressRows.map((row) => [row._id, row.avgProgress]));
        const topCourses = courses.map((course) => ({
            id: course._id.toString(),
            title: course.title,
            category: course.category,
            level: course.level || 'General',
            progress: Math.round(progressByCourse.get(course._id.toString()) ?? 0),
            students: course.students ?? 0,
        }));
        const studentIds = [
            ...new Set(recentEnrollments.map((item) => item.userId)),
        ];
        const relatedCourseIds = [
            ...new Set(recentEnrollments.map((item) => item.courseId)),
        ];
        const [users, relatedCourses] = await Promise.all([
            this.userModel
                .find({ _id: { $in: studentIds } })
                .select('firstName lastName email lastLoginAt')
                .lean()
                .exec(),
            this.courseModel
                .find({ _id: { $in: relatedCourseIds } })
                .select('title')
                .lean()
                .exec(),
        ]);
        const userById = new Map(users.map((user) => [user._id.toString(), user]));
        const courseById = new Map(relatedCourses.map((course) => [course._id.toString(), course]));
        const studentName = (userId) => {
            const user = userById.get(userId);
            if (!user)
                return 'Unknown student';
            return user.lastName
                ? `${user.firstName} ${user.lastName}`
                : user.firstName;
        };
        const recentEnrollmentRows = recentEnrollments
            .slice(0, 5)
            .map((item) => ({
            id: item._id.toString(),
            studentName: studentName(item.userId),
            email: userById.get(item.userId)?.email ?? '',
            courseTitle: courseById.get(item.courseId)?.title ?? 'Unknown course',
            enrolledAt: new Date(item.enrolledAt).toISOString(),
        }));
        const studentReports = recentEnrollments.map((item) => {
            const user = userById.get(item.userId);
            const progress = Math.round(item.progress ?? 0);
            let status = 'In Progress';
            if (item.status === enrollment_entity_1.EnrollmentStatus.COMPLETED || progress >= 100) {
                status = 'Completed';
            }
            else if (progress < 40) {
                status = 'At Risk';
            }
            const lastActiveAt = user?.lastLoginAt ?? item.updatedAt ?? item.enrolledAt;
            return {
                id: item._id.toString(),
                studentName: studentName(item.userId),
                email: user?.email ?? '',
                course: courseById.get(item.courseId)?.title ?? 'Unknown course',
                progress,
                status,
                lastActive: lastActiveAt ? new Date(lastActiveAt).toISOString() : null,
            };
        });
        return {
            stats: {
                totalCourses,
                activeCourses,
                publishedCourses,
                draftCourses,
                totalCategories: categories.length,
                totalStudents,
                enrolledStudents: enrolledUserIds.length,
                activeStudents,
                pendingStudents,
                totalEnrollments,
                completedEnrollments,
                enrollmentsThisWeek,
                avgCompletionRate: Math.round(completionAgg[0]?.avgProgress ?? 0),
            },
            weeklyEngagement,
            topCourses,
            recentEnrollments: recentEnrollmentRows,
            studentReports,
            generatedAt: new Date().toISOString(),
        };
    }
};
exports.DashboardService = DashboardService;
exports.DashboardService = DashboardService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(user_entity_1.User.name)),
    __param(1, (0, mongoose_1.InjectModel)(course_entity_1.Course.name)),
    __param(2, (0, mongoose_1.InjectModel)(enrollment_entity_1.Enrollment.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model,
        mongoose_2.Model])
], DashboardService);
//# sourceMappingURL=dashboard.service.js.map