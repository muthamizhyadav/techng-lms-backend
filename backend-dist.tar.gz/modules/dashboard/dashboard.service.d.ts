import { Model } from 'mongoose';
import { UserDocument } from "../users/entities/user.entity";
import { CourseDocument } from "../courses/entities/course.entity";
import { EnrollmentDocument } from "../enrollments/entities/enrollment.entity";
export type ReportStatus = 'Completed' | 'In Progress' | 'At Risk';
export interface WeeklyEngagementPoint {
    day: string;
    date: string;
    enrollments: number;
    completions: number;
}
export interface TopCourse {
    id: string;
    title: string;
    category: string;
    level: string;
    progress: number;
    students: number;
}
export interface RecentEnrollment {
    id: string;
    studentName: string;
    email: string;
    courseTitle: string;
    enrolledAt: string;
}
export interface StudentReport {
    id: string;
    studentName: string;
    email: string;
    course: string;
    progress: number;
    status: ReportStatus;
    lastActive: string | null;
}
export interface DashboardOverview {
    stats: {
        totalCourses: number;
        activeCourses: number;
        publishedCourses: number;
        draftCourses: number;
        totalCategories: number;
        totalStudents: number;
        enrolledStudents: number;
        activeStudents: number;
        pendingStudents: number;
        totalEnrollments: number;
        completedEnrollments: number;
        enrollmentsThisWeek: number;
        avgCompletionRate: number;
    };
    weeklyEngagement: WeeklyEngagementPoint[];
    topCourses: TopCourse[];
    recentEnrollments: RecentEnrollment[];
    studentReports: StudentReport[];
    generatedAt: string;
}
export declare class DashboardService {
    private readonly userModel;
    private readonly courseModel;
    private readonly enrollmentModel;
    constructor(userModel: Model<UserDocument>, courseModel: Model<CourseDocument>, enrollmentModel: Model<EnrollmentDocument>);
    getOverview(): Promise<DashboardOverview>;
}
