import { CourseCategoriesService } from './course-categories.service';
import { Admin } from "../admins/entities/admin.entity";
import { CreateCourseCategoryDto, UpdateCourseCategoryDto } from './dto/course-category.dto';
export declare class CourseCategoriesController {
    private readonly courseCategoriesService;
    constructor(courseCategoriesService: CourseCategoriesService);
    findAll(page: number, limit: number, isActive?: boolean, search?: string): Promise<{
        data: Array<import("./entities/course-category.entity").CourseCategory & {
            coursesCount: number;
        }>;
        total: number;
        page: number;
        limit: number;
    }>;
    getStats(): Promise<{
        total: number;
        active: number;
        inactive: number;
        parentCategories: number;
        subCategories: number;
        totalCourses: number;
    }>;
    findOne(id: string): Promise<import("./entities/course-category.entity").CourseCategory & {
        coursesCount: number;
        subCategoriesCount: number;
    }>;
    create(dto: CreateCourseCategoryDto, currentAdmin: Admin): Promise<import("./entities/course-category.entity").CourseCategory>;
    update(id: string, dto: UpdateCourseCategoryDto, currentAdmin: Admin): Promise<import("./entities/course-category.entity").CourseCategory>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
