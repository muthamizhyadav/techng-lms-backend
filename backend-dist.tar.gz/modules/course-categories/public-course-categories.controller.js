"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicCourseCategoriesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const course_categories_service_1 = require("./course-categories.service");
const course_category_dto_1 = require("./dto/course-category.dto");
let PublicCourseCategoriesController = class PublicCourseCategoriesController {
    constructor(courseCategoriesService) {
        this.courseCategoriesService = courseCategoriesService;
    }
    async findActive(page, limit, search) {
        return this.courseCategoriesService.findAll({
            page,
            limit,
            isActive: true,
            search,
        });
    }
};
exports.PublicCourseCategoriesController = PublicCourseCategoriesController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({
        summary: 'Browse active course categories (Public)',
        description: 'List active categories ordered by sort order, each with the number of courses in it',
    }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number, example: 1 }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number, example: 50 }),
    (0, swagger_1.ApiQuery)({ name: 'search', required: false, type: String, example: 'web' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'List of active course categories',
        type: [course_category_dto_1.CourseCategoryResponseDto],
    }),
    __param(0, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(1, (0, common_1.Query)('limit', new common_1.DefaultValuePipe(50), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String]),
    __metadata("design:returntype", Promise)
], PublicCourseCategoriesController.prototype, "findActive", null);
exports.PublicCourseCategoriesController = PublicCourseCategoriesController = __decorate([
    (0, swagger_1.ApiTags)('🌐 Public Course Categories'),
    (0, common_1.Controller)('public/course-categories'),
    __metadata("design:paramtypes", [course_categories_service_1.CourseCategoriesService])
], PublicCourseCategoriesController);
//# sourceMappingURL=public-course-categories.controller.js.map