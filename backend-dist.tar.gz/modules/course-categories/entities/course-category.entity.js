"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourseCategorySchema = exports.CourseCategory = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const uuid_util_1 = require("../../../common/utils/uuid.util");
let CourseCategory = class CourseCategory {
};
exports.CourseCategory = CourseCategory;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], CourseCategory.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, unique: true, trim: true }),
    __metadata("design:type", String)
], CourseCategory.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, unique: true, lowercase: true, trim: true }),
    __metadata("design:type", String)
], CourseCategory.prototype, "slug", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], CourseCategory.prototype, "description", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], CourseCategory.prototype, "icon", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], CourseCategory.prototype, "thumbnail", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'CourseCategory', default: null }),
    __metadata("design:type", String)
], CourseCategory.prototype, "parentId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Number, default: 0 }),
    __metadata("design:type", Number)
], CourseCategory.prototype, "sortOrder", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Boolean, default: true }),
    __metadata("design:type", Boolean)
], CourseCategory.prototype, "isActive", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], CourseCategory.prototype, "createdByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], CourseCategory.prototype, "updatedByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], CourseCategory.prototype, "deletedAt", void 0);
exports.CourseCategory = CourseCategory = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'course-categories',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                return ret;
            },
        },
        toObject: {
            virtuals: true,
            versionKey: false,
        },
    })
], CourseCategory);
exports.CourseCategorySchema = mongoose_1.SchemaFactory.createForClass(CourseCategory);
exports.CourseCategorySchema.index({ name: 'text', slug: 'text', description: 'text' });
exports.CourseCategorySchema.index({ sortOrder: 1 });
exports.CourseCategorySchema.index({ parentId: 1 });
//# sourceMappingURL=course-category.entity.js.map