import { HydratedDocument } from 'mongoose';
export type CourseCategoryDocument = HydratedDocument<CourseCategory>;
export declare class CourseCategory {
    _id: string;
    id: string;
    name: string;
    slug: string;
    description: string;
    icon: string;
    thumbnail: string;
    parentId: string;
    sortOrder: number;
    isActive: boolean;
    createdByAdminId: string;
    updatedByAdminId: string;
    deletedAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const CourseCategorySchema: import("mongoose").Schema<CourseCategory, import("mongoose").Model<CourseCategory, any, any, any, any, any, CourseCategory>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    name?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    slug?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    description?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    icon?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    thumbnail?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    parentId?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    sortOrder?: import("mongoose").SchemaDefinitionProperty<number, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isActive?: import("mongoose").SchemaDefinitionProperty<boolean, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdByAdminId?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedByAdminId?: import("mongoose").SchemaDefinitionProperty<string, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    deletedAt?: import("mongoose").SchemaDefinitionProperty<Date, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, CourseCategory, import("mongoose").Document<unknown, {}, CourseCategory, {}, import("mongoose").DefaultSchemaOptions> & CourseCategory & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, CourseCategory>;
