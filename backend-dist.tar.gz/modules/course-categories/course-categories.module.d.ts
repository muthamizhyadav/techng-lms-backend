export declare class CourseCategoriesModule {
}
