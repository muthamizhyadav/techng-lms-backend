"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourseCategoriesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const course_categories_service_1 = require("./course-categories.service");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const current_admin_decorator_1 = require("../../common/decorators/current-admin.decorator");
const admin_entity_1 = require("../admins/entities/admin.entity");
const course_category_dto_1 = require("./dto/course-category.dto");
let CourseCategoriesController = class CourseCategoriesController {
    constructor(courseCategoriesService) {
        this.courseCategoriesService = courseCategoriesService;
    }
    async findAll(page, limit, isActive, search) {
        return this.courseCategoriesService.findAll({
            page,
            limit,
            isActive,
            search,
        });
    }
    async getStats() {
        return this.courseCategoriesService.getStats();
    }
    async findOne(id) {
        return this.courseCategoriesService.findOne(id);
    }
    async create(dto, currentAdmin) {
        return this.courseCategoriesService.create(dto, currentAdmin.id);
    }
    async update(id, dto, currentAdmin) {
        return this.courseCategoriesService.update(id, dto, currentAdmin.id);
    }
    async remove(id) {
        await this.courseCategoriesService.remove(id);
        return { message: 'Course category deleted successfully' };
    }
};
exports.CourseCategoriesController = CourseCategoriesController;
__decorate([
    (0, common_1.Get)(),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'List all course categories (Admin only)',
        description: 'Paginated list of course categories with activity and search filters',
    }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number, example: 1 }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number, example: 10 }),
    (0, swagger_1.ApiQuery)({
        name: 'isActive',
        required: false,
        type: Boolean,
        example: true,
    }),
    (0, swagger_1.ApiQuery)({ name: 'search', required: false, type: String, example: 'web' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'List of course categories retrieved',
        type: [course_category_dto_1.CourseCategoryResponseDto],
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    (0, swagger_1.ApiResponse)({ status: 403, description: 'Admin access required' }),
    __param(0, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(1, (0, common_1.Query)('limit', new common_1.DefaultValuePipe(10), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('isActive', new common_1.ParseBoolPipe({ optional: true }))),
    __param(3, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, Boolean, String]),
    __metadata("design:returntype", Promise)
], CourseCategoriesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats/overview'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get course category statistics (Admin only)',
        description: 'Total, active, inactive, parent/sub-category counts and linked courses for the dashboard',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Course category statistics',
        schema: {
            example: {
                total: 12,
                active: 10,
                inactive: 2,
                parentCategories: 6,
                subCategories: 6,
                totalCourses: 40,
            },
        },
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CourseCategoriesController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Get course category by ID (Admin only)' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Course category UUID',
        example: '0f8fad5b-d9cb-469f-a165-70867728950e',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Course category found',
        type: course_category_dto_1.CourseCategoryResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course category not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CourseCategoriesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new course category (Admin only)' }),
    (0, swagger_1.ApiBody)({ type: course_category_dto_1.CreateCourseCategoryDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Course category created',
        type: course_category_dto_1.CourseCategoryResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    (0, swagger_1.ApiResponse)({
        status: 409,
        description: 'Category name or slug already exists',
    }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [course_category_dto_1.CreateCourseCategoryDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], CourseCategoriesController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Update course category details (Admin only)' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Course category UUID' }),
    (0, swagger_1.ApiBody)({ type: course_category_dto_1.UpdateCourseCategoryDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Course category updated',
        type: course_category_dto_1.CourseCategoryResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course category not found' }),
    (0, swagger_1.ApiResponse)({
        status: 409,
        description: 'Category name or slug already exists',
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, course_category_dto_1.UpdateCourseCategoryDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], CourseCategoriesController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Delete course category (Admin only)',
        description: 'Soft deletes the category. Fails if it still has subcategories or assigned courses',
    }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Course category UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Course category deleted' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course category not found' }),
    (0, swagger_1.ApiResponse)({ status: 409, description: 'Category still in use' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CourseCategoriesController.prototype, "remove", null);
exports.CourseCategoriesController = CourseCategoriesController = __decorate([
    (0, swagger_1.ApiTags)('🏷️ Course Categories'),
    (0, common_1.Controller)('course-categories'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    __metadata("design:paramtypes", [course_categories_service_1.CourseCategoriesService])
], CourseCategoriesController);
//# sourceMappingURL=course-categories.controller.js.map