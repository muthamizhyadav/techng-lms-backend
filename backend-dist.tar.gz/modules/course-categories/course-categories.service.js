"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourseCategoriesService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const course_category_entity_1 = require("./entities/course-category.entity");
const course_entity_1 = require("../courses/entities/course.entity");
const free_course_entity_1 = require("../free-courses/entities/free-course.entity");
const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
let CourseCategoriesService = class CourseCategoriesService {
    constructor(categoryModel, courseModel, freeCourseModel) {
        this.categoryModel = categoryModel;
        this.courseModel = courseModel;
        this.freeCourseModel = freeCourseModel;
    }
    slugify(input) {
        return input
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');
    }
    async ensureUniqueSlug(slug, excludeId) {
        const exclude = excludeId ? { _id: { $ne: excludeId } } : {};
        let candidate = slug;
        let exists = await this.categoryModel.findOne({
            slug: candidate,
            ...exclude,
            deletedAt: null,
        });
        while (exists) {
            candidate = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
            exists = await this.categoryModel.findOne({
                slug: candidate,
                ...exclude,
                deletedAt: null,
            });
        }
        return candidate;
    }
    async assertValidParent(parentId) {
        if (!parentId)
            return;
        const parent = await this.categoryModel.findOne({
            _id: parentId,
            deletedAt: null,
        });
        if (!parent) {
            throw new common_1.BadRequestException(`Parent category with ID "${parentId}" not found`);
        }
    }
    async attachCourseCounts(categories) {
        if (categories.length === 0)
            return [];
        const names = categories.map((category) => category.name);
        const [paidCounts, freeCounts] = await Promise.all([
            this.courseModel.aggregate([
                { $match: { category: { $in: names }, deletedAt: null } },
                { $group: { _id: '$category', count: { $sum: 1 } } },
            ]),
            this.freeCourseModel.aggregate([
                { $match: { category: { $in: names }, deletedAt: null } },
                { $group: { _id: '$category', count: { $sum: 1 } } },
            ]),
        ]);
        const countMap = new Map();
        for (const c of paidCounts) {
            countMap.set(c._id, (countMap.get(c._id) ?? 0) + c.count);
        }
        for (const c of freeCounts) {
            countMap.set(c._id, (countMap.get(c._id) ?? 0) + c.count);
        }
        return categories.map((category) => {
            const json = category.toJSON();
            return {
                ...json,
                coursesCount: countMap.get(category.name) ?? 0,
            };
        });
    }
    async findAll(query) {
        const { page, limit, isActive, search } = query;
        const filter = { deletedAt: null };
        if (typeof isActive === 'boolean') {
            filter.isActive = isActive;
        }
        if (search && search.trim()) {
            const regex = new RegExp(escapeRegex(search.trim()), 'i');
            filter.$or = [{ name: regex }, { slug: regex }, { description: regex }];
        }
        const [data, total] = await Promise.all([
            this.categoryModel
                .find(filter)
                .sort({ sortOrder: 1, createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .exec(),
            this.categoryModel.countDocuments(filter),
        ]);
        const decorated = await this.attachCourseCounts(data);
        return { data: decorated, total, page, limit };
    }
    async findOne(id) {
        const category = await this.categoryModel.findOne({
            _id: id,
            deletedAt: null,
        });
        if (!category) {
            throw new common_1.NotFoundException(`Category with ID "${id}" not found`);
        }
        const [coursesCount, subCategoriesCount] = await Promise.all([
            this.courseModel.countDocuments({
                category: category.name,
                deletedAt: null,
            }),
            this.categoryModel.countDocuments({
                parentId: id,
                deletedAt: null,
            }),
        ]);
        return {
            ...category.toJSON(),
            coursesCount,
            subCategoriesCount,
        };
    }
    async create(dto, adminId) {
        const nameRegex = new RegExp(`^${escapeRegex(dto.name.trim())}$`, 'i');
        const duplicate = await this.categoryModel.findOne({
            name: nameRegex,
            deletedAt: null,
        });
        if (duplicate) {
            throw new common_1.ConflictException(`Category "${dto.name}" already exists`);
        }
        await this.assertValidParent(dto.parentId);
        const baseSlug = dto.slug?.trim().toLowerCase() || this.slugify(dto.name);
        const slug = await this.ensureUniqueSlug(baseSlug);
        const savedCategory = await this.categoryModel.create({
            ...dto,
            name: dto.name.trim(),
            slug,
            createdByAdminId: adminId,
            updatedByAdminId: adminId,
        });
        return savedCategory.toJSON();
    }
    async update(id, dto, adminId) {
        const category = await this.findOne(id);
        if (dto.parentId === id) {
            throw new common_1.BadRequestException('A category cannot be its own parent');
        }
        if (dto.name &&
            dto.name.trim().toLowerCase() !== category.name.trim().toLowerCase()) {
            const nameRegex = new RegExp(`^${escapeRegex(dto.name.trim())}$`, 'i');
            const duplicate = await this.categoryModel.findOne({
                name: nameRegex,
                _id: { $ne: id },
                deletedAt: null,
            });
            if (duplicate) {
                throw new common_1.ConflictException(`Category "${dto.name}" already exists`);
            }
        }
        await this.assertValidParent(dto.parentId);
        const payload = { ...dto, updatedByAdminId: adminId };
        if (dto.name) {
            payload.name = dto.name.trim();
            const nameChanged = dto.name.trim().toLowerCase() !== category.name.trim().toLowerCase();
            const shouldReslug = nameChanged && !dto.slug;
            if (shouldReslug) {
                payload.slug = await this.ensureUniqueSlug(this.slugify(dto.name), id);
            }
        }
        const updatedCategory = await this.categoryModel.findOneAndUpdate({ _id: id, deletedAt: null }, payload, { new: true });
        return updatedCategory.toJSON();
    }
    async remove(id) {
        const category = await this.findOne(id);
        const subCategories = await this.categoryModel.countDocuments({
            parentId: id,
            deletedAt: null,
        });
        if (subCategories > 0) {
            throw new common_1.ConflictException('Cannot delete a category that has subcategories');
        }
        const freeCourseCount = await this.freeCourseModel.countDocuments({
            category: category.name,
            deletedAt: null,
        });
        if (category.coursesCount > 0 || freeCourseCount > 0) {
            throw new common_1.ConflictException('Cannot delete a category that has courses assigned to it. Please reassign the courses first.');
        }
        await this.categoryModel.findOneAndUpdate({ _id: id, deletedAt: null }, { deletedAt: new Date() });
    }
    async getStats() {
        const [total, active, inactive, parentCategories, subCategories, totalCourses,] = await Promise.all([
            this.categoryModel.countDocuments({ deletedAt: null }),
            this.categoryModel.countDocuments({ deletedAt: null, isActive: true }),
            this.categoryModel.countDocuments({ deletedAt: null, isActive: false }),
            this.categoryModel.countDocuments({ deletedAt: null, parentId: null }),
            this.categoryModel.countDocuments({
                deletedAt: null,
                parentId: { $ne: null },
            }),
            this.courseModel.aggregate([
                { $match: { deletedAt: null } },
                { $group: { _id: null, count: { $sum: 1 } } },
            ]),
        ]);
        return {
            total,
            active,
            inactive,
            parentCategories,
            subCategories,
            totalCourses: totalCourses[0]?.count ?? 0,
        };
    }
};
exports.CourseCategoriesService = CourseCategoriesService;
exports.CourseCategoriesService = CourseCategoriesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(course_category_entity_1.CourseCategory.name)),
    __param(1, (0, mongoose_1.InjectModel)(course_entity_1.Course.name)),
    __param(2, (0, mongoose_1.InjectModel)(free_course_entity_1.FreeCourse.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model,
        mongoose_2.Model])
], CourseCategoriesService);
//# sourceMappingURL=course-categories.service.js.map