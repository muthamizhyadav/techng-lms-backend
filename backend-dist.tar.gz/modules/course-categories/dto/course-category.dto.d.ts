export declare class CreateCourseCategoryDto {
    name: string;
    slug?: string;
    description?: string;
    icon?: string;
    thumbnail?: string;
    parentId?: string;
    sortOrder?: number;
    isActive?: boolean;
}
declare const UpdateCourseCategoryDto_base: import("@nestjs/common").Type<Partial<CreateCourseCategoryDto>>;
export declare class UpdateCourseCategoryDto extends UpdateCourseCategoryDto_base {
}
export declare class CourseCategoryResponseDto {
    id: string;
    name: string;
    slug: string;
    description: string;
    icon: string;
    thumbnail: string;
    parentId: string;
    sortOrder: number;
    isActive: boolean;
    coursesCount: number;
    createdAt: Date;
    updatedAt: Date;
}
export {};
