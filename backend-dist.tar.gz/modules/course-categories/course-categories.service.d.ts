import { Model } from 'mongoose';
import { CourseCategory, CourseCategoryDocument } from './entities/course-category.entity';
import { CreateCourseCategoryDto, UpdateCourseCategoryDto } from './dto/course-category.dto';
import { CourseDocument } from "../courses/entities/course.entity";
import { FreeCourseDocument } from '../free-courses/entities/free-course.entity';
export interface CourseCategoryQuery {
    page: number;
    limit: number;
    isActive?: boolean;
    search?: string;
}
export declare class CourseCategoriesService {
    private readonly categoryModel;
    private readonly courseModel;
    private readonly freeCourseModel;
    constructor(categoryModel: Model<CourseCategoryDocument>, courseModel: Model<CourseDocument>, freeCourseModel: Model<FreeCourseDocument>);
    private slugify;
    private ensureUniqueSlug;
    private assertValidParent;
    private attachCourseCounts;
    findAll(query: CourseCategoryQuery): Promise<{
        data: Array<CourseCategory & {
            coursesCount: number;
        }>;
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<CourseCategory & {
        coursesCount: number;
        subCategoriesCount: number;
    }>;
    create(dto: CreateCourseCategoryDto, adminId: string): Promise<CourseCategory>;
    update(id: string, dto: UpdateCourseCategoryDto, adminId: string): Promise<CourseCategory>;
    remove(id: string): Promise<void>;
    getStats(): Promise<{
        total: number;
        active: number;
        inactive: number;
        parentCategories: number;
        subCategories: number;
        totalCourses: number;
    }>;
}
