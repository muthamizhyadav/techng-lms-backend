import { CourseCategoriesService } from './course-categories.service';
export declare class PublicCourseCategoriesController {
    private readonly courseCategoriesService;
    constructor(courseCategoriesService: CourseCategoriesService);
    findActive(page: number, limit: number, search?: string): Promise<{
        data: Array<import("./entities/course-category.entity").CourseCategory & {
            coursesCount: number;
        }>;
        total: number;
        page: number;
        limit: number;
    }>;
}
