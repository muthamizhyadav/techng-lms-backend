"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var FirebaseService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FirebaseService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const app_1 = require("firebase-admin/app");
const messaging_1 = require("firebase-admin/messaging");
const INVALID_TOKEN_CODES = new Set([
    'messaging/registration-token-not-registered',
    'messaging/invalid-registration-token',
    'messaging/invalid-argument',
]);
let FirebaseService = FirebaseService_1 = class FirebaseService {
    constructor(configService) {
        this.configService = configService;
        this.logger = new common_1.Logger(FirebaseService_1.name);
        this.messaging = null;
    }
    onModuleInit() {
        const projectId = this.configService.get('firebase.projectId');
        const clientEmail = this.configService.get('firebase.clientEmail');
        const privateKey = this.configService.get('firebase.privateKey');
        this.adminPanelUrl = this.configService.get('firebase.adminPanelUrl');
        if (!projectId || !clientEmail || !privateKey) {
            this.logger.warn('Firebase credentials are not configured (FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY). Push notifications are disabled.');
            return;
        }
        try {
            const app = (0, app_1.getApps)().length
                ? (0, app_1.getApps)()[0]
                : (0, app_1.initializeApp)({
                    credential: (0, app_1.cert)({ projectId, clientEmail, privateKey }),
                });
            this.messaging = (0, messaging_1.getMessaging)(app);
            this.logger.log('Firebase Cloud Messaging initialised.');
        }
        catch (error) {
            this.logger.error(`Failed to initialise Firebase Cloud Messaging: ${error.message}`);
        }
    }
    get isEnabled() {
        return this.messaging !== null;
    }
    async sendToTokens(tokens, payload) {
        const messaging = this.messaging;
        const uniqueTokens = [...new Set(tokens.filter(Boolean))];
        if (!messaging || uniqueTokens.length === 0) {
            return [];
        }
        const data = {};
        for (const [key, value] of Object.entries(payload.data ?? {})) {
            if (value !== undefined && value !== null) {
                data[key] = String(value);
            }
        }
        if (payload.link) {
            data.link = payload.link;
        }
        const absoluteLink = this.resolveLink(payload.link);
        try {
            const response = await messaging.sendEachForMulticast({
                tokens: uniqueTokens,
                notification: {
                    title: payload.title,
                    body: payload.body,
                },
                data,
                webpush: {
                    notification: {
                        title: payload.title,
                        body: payload.body,
                        icon: '/favicon.svg',
                    },
                    fcmOptions: absoluteLink ? { link: absoluteLink } : undefined,
                },
            });
            const invalidTokens = [];
            response.responses.forEach((result, index) => {
                if (!result.success &&
                    result.error &&
                    INVALID_TOKEN_CODES.has(result.error.code)) {
                    invalidTokens.push(uniqueTokens[index]);
                }
            });
            if (invalidTokens.length > 0) {
                this.logger.warn(`Pruning ${invalidTokens.length} stale push token(s).`);
            }
            return invalidTokens;
        }
        catch (error) {
            this.logger.error(`Failed to send push notification: ${error.message}`);
            return [];
        }
    }
    resolveLink(link) {
        if (!link) {
            return undefined;
        }
        try {
            const url = new URL(link, this.adminPanelUrl);
            return url.protocol === 'https:' ? url.href : undefined;
        }
        catch {
            return undefined;
        }
    }
};
exports.FirebaseService = FirebaseService;
exports.FirebaseService = FirebaseService = FirebaseService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], FirebaseService);
//# sourceMappingURL=firebase.service.js.map