"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var NotificationsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const admin_entity_1 = require("../admins/entities/admin.entity");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const firebase_service_1 = require("./firebase.service");
const notification_entity_1 = require("./entities/notification.entity");
let NotificationsService = NotificationsService_1 = class NotificationsService {
    constructor(adminModel, notificationModel, firebaseService) {
        this.adminModel = adminModel;
        this.notificationModel = notificationModel;
        this.firebaseService = firebaseService;
        this.logger = new common_1.Logger(NotificationsService_1.name);
    }
    async registerToken(adminId, token) {
        const normalized = token.trim();
        await this.adminModel.updateMany({ _id: { $ne: adminId } }, { $pull: { fcmTokens: normalized } });
        await this.adminModel.updateOne({ _id: adminId }, { $addToSet: { fcmTokens: normalized } });
    }
    async unregisterToken(adminId, token) {
        await this.adminModel.updateOne({ _id: adminId }, { $pull: { fcmTokens: token.trim() } });
    }
    async sendTestNotification(adminId) {
        if (!this.firebaseService.isEnabled) {
            throw new common_1.ServiceUnavailableException('Push notifications are not configured on the server.');
        }
        const admin = await this.adminModel.findById(adminId);
        if (!admin) {
            throw new common_1.NotFoundException('Admin not found');
        }
        const payload = {
            title: 'TechNG LMS notifications enabled',
            body: 'You will now receive alerts for new students and course purchases.',
            type: notification_entity_1.AdminNotificationType.TEST,
            data: { type: 'test' },
            link: '/settings#notifications',
        };
        await this.createRecord(payload, [adminId]);
        const sent = await this.dispatch(admin.fcmTokens ?? [], payload);
        return { sent };
    }
    async listForAdmin(adminId, page = 1, limit = 20) {
        const scope = this.scopeFor(adminId);
        const safePage = Math.max(1, page);
        const safeLimit = Math.min(100, Math.max(1, limit));
        const [documents, total, unreadCount] = await Promise.all([
            this.notificationModel
                .find(scope)
                .sort({ createdAt: -1 })
                .skip((safePage - 1) * safeLimit)
                .limit(safeLimit)
                .lean(),
            this.notificationModel.countDocuments(scope),
            this.notificationModel.countDocuments({
                ...scope,
                readByAdminIds: { $ne: adminId },
            }),
        ]);
        return {
            items: documents.map((document) => this.toResponse(document, adminId)),
            total,
            page: safePage,
            limit: safeLimit,
            unreadCount,
        };
    }
    async markRead(adminId, id) {
        const result = await this.notificationModel.updateOne({ _id: id, ...this.scopeFor(adminId) }, { $addToSet: { readByAdminIds: adminId } });
        if (result.matchedCount === 0) {
            throw new common_1.NotFoundException('Notification not found');
        }
        return { success: true };
    }
    async markAllRead(adminId) {
        const result = await this.notificationModel.updateMany({ ...this.scopeFor(adminId), readByAdminIds: { $ne: adminId } }, { $addToSet: { readByAdminIds: adminId } });
        return { updated: result.modifiedCount };
    }
    async notifyAdmins(payload, recipientAdminIds = []) {
        let notificationId = null;
        try {
            const notification = await this.createRecord(payload, recipientAdminIds);
            notificationId = notification.id;
        }
        catch (error) {
            this.logger.error(`Failed to store notification: ${error.message}`);
        }
        const sent = await this.pushToAdmins(payload, recipientAdminIds);
        return { sent, notificationId };
    }
    async createRecord(payload, recipientAdminIds) {
        const data = {};
        for (const [key, value] of Object.entries(payload.data ?? {})) {
            if (value !== undefined && value !== null) {
                data[key] = String(value);
            }
        }
        return this.notificationModel.create({
            title: payload.title,
            body: payload.body,
            type: payload.type ?? notification_entity_1.AdminNotificationType.SYSTEM,
            link: payload.link ?? null,
            data,
            recipientAdminIds,
            readByAdminIds: [],
        });
    }
    async pushToAdmins(payload, recipientAdminIds) {
        try {
            if (!this.firebaseService.isEnabled) {
                return 0;
            }
            const query = {
                deletedAt: null,
                status: user_status_enum_1.AdminStatus.ACTIVE,
            };
            if (recipientAdminIds.length > 0) {
                query._id = { $in: recipientAdminIds };
            }
            const admins = await this.adminModel
                .find(query)
                .select('fcmTokens')
                .lean();
            const tokens = admins.flatMap((admin) => admin.fcmTokens ?? []);
            return this.dispatch(tokens, payload);
        }
        catch (error) {
            this.logger.error(`Failed to notify admins: ${error.message}`);
            return 0;
        }
    }
    async dispatch(tokens, payload) {
        const uniqueTokens = [...new Set(tokens.filter(Boolean))];
        if (uniqueTokens.length === 0) {
            return 0;
        }
        const invalidTokens = await this.firebaseService.sendToTokens(uniqueTokens, payload);
        if (invalidTokens.length > 0) {
            await this.adminModel.updateMany({ fcmTokens: { $in: invalidTokens } }, { $pull: { fcmTokens: { $in: invalidTokens } } });
        }
        return uniqueTokens.length - invalidTokens.length;
    }
    scopeFor(adminId) {
        return {
            $or: [
                { recipientAdminIds: { $size: 0 } },
                { recipientAdminIds: adminId },
            ],
        };
    }
    toResponse(document, adminId) {
        return {
            id: document._id.toString(),
            title: document.title,
            body: document.body,
            type: document.type,
            link: document.link ?? null,
            data: document.data ?? {},
            isRead: (document.readByAdminIds ?? []).includes(adminId),
            createdAt: document.createdAt,
        };
    }
};
exports.NotificationsService = NotificationsService;
exports.NotificationsService = NotificationsService = NotificationsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(admin_entity_1.Admin.name)),
    __param(1, (0, mongoose_1.InjectModel)(notification_entity_1.AdminNotification.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model,
        firebase_service_1.FirebaseService])
], NotificationsService);
//# sourceMappingURL=notifications.service.js.map