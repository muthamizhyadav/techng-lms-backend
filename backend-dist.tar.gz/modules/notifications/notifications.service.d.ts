import { Model } from 'mongoose';
import { AdminDocument } from "../admins/entities/admin.entity";
import { FirebaseService } from './firebase.service';
import { AdminNotificationDocument, AdminNotificationType } from './entities/notification.entity';
export interface AdminNotificationInput {
    title: string;
    body: string;
    type?: AdminNotificationType;
    link?: string;
    data?: Record<string, string | number | boolean | null | undefined>;
}
export interface AdminNotificationResponse {
    id: string;
    title: string;
    body: string;
    type: AdminNotificationType;
    link: string | null;
    data: Record<string, string>;
    isRead: boolean;
    createdAt: Date;
}
export interface AdminNotificationList {
    items: AdminNotificationResponse[];
    total: number;
    page: number;
    limit: number;
    unreadCount: number;
}
export declare class NotificationsService {
    private readonly adminModel;
    private readonly notificationModel;
    private readonly firebaseService;
    private readonly logger;
    constructor(adminModel: Model<AdminDocument>, notificationModel: Model<AdminNotificationDocument>, firebaseService: FirebaseService);
    registerToken(adminId: string, token: string): Promise<void>;
    unregisterToken(adminId: string, token: string): Promise<void>;
    sendTestNotification(adminId: string): Promise<{
        sent: number;
    }>;
    listForAdmin(adminId: string, page?: number, limit?: number): Promise<AdminNotificationList>;
    markRead(adminId: string, id: string): Promise<{
        success: boolean;
    }>;
    markAllRead(adminId: string): Promise<{
        updated: number;
    }>;
    notifyAdmins(payload: AdminNotificationInput, recipientAdminIds?: string[]): Promise<{
        sent: number;
        notificationId: string | null;
    }>;
    private createRecord;
    private pushToAdmins;
    private dispatch;
    private scopeFor;
    private toResponse;
}
