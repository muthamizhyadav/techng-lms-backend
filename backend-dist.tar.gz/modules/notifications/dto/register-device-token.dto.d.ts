export declare class RegisterDeviceTokenDto {
    token: string;
}
