"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminNotificationSchema = exports.AdminNotification = exports.AdminNotificationType = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const uuid_util_1 = require("../../../common/utils/uuid.util");
var AdminNotificationType;
(function (AdminNotificationType) {
    AdminNotificationType["STUDENT_REGISTERED"] = "student_registered";
    AdminNotificationType["COURSE_PURCHASED"] = "course_purchased";
    AdminNotificationType["TEST"] = "test";
    AdminNotificationType["SYSTEM"] = "system";
})(AdminNotificationType || (exports.AdminNotificationType = AdminNotificationType = {}));
let AdminNotification = class AdminNotification {
};
exports.AdminNotification = AdminNotification;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], AdminNotification.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    __metadata("design:type", String)
], AdminNotification.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    __metadata("design:type", String)
], AdminNotification.prototype, "body", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: String,
        enum: AdminNotificationType,
        default: AdminNotificationType.SYSTEM,
    }),
    __metadata("design:type", String)
], AdminNotification.prototype, "type", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: null }),
    __metadata("design:type", String)
], AdminNotification.prototype, "link", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: mongoose_2.SchemaTypes.Mixed, default: {} }),
    __metadata("design:type", Object)
], AdminNotification.prototype, "data", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [String], default: [] }),
    __metadata("design:type", Array)
], AdminNotification.prototype, "recipientAdminIds", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [String], default: [] }),
    __metadata("design:type", Array)
], AdminNotification.prototype, "readByAdminIds", void 0);
exports.AdminNotification = AdminNotification = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'notifications',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                delete ret.recipientAdminIds;
                delete ret.readByAdminIds;
                return ret;
            },
        },
    })
], AdminNotification);
exports.AdminNotificationSchema = mongoose_1.SchemaFactory.createForClass(AdminNotification);
exports.AdminNotificationSchema.index({ createdAt: -1 });
//# sourceMappingURL=notification.entity.js.map