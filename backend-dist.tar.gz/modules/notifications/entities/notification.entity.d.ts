import { HydratedDocument } from 'mongoose';
export type AdminNotificationDocument = HydratedDocument<AdminNotification>;
export declare enum AdminNotificationType {
    STUDENT_REGISTERED = "student_registered",
    COURSE_PURCHASED = "course_purchased",
    TEST = "test",
    SYSTEM = "system"
}
export declare class AdminNotification {
    _id: string;
    id: string;
    title: string;
    body: string;
    type: AdminNotificationType;
    link: string;
    data: Record<string, string>;
    recipientAdminIds: string[];
    readByAdminIds: string[];
    createdAt: Date;
    updatedAt: Date;
}
export declare const AdminNotificationSchema: import("mongoose").Schema<AdminNotification, import("mongoose").Model<AdminNotification, any, any, any, any, any, AdminNotification>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    title?: import("mongoose").SchemaDefinitionProperty<string, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    body?: import("mongoose").SchemaDefinitionProperty<string, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    type?: import("mongoose").SchemaDefinitionProperty<AdminNotificationType, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    link?: import("mongoose").SchemaDefinitionProperty<string, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    data?: import("mongoose").SchemaDefinitionProperty<Record<string, string>, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    recipientAdminIds?: import("mongoose").SchemaDefinitionProperty<string[], AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    readByAdminIds?: import("mongoose").SchemaDefinitionProperty<string[], AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, AdminNotification, import("mongoose").Document<unknown, {}, AdminNotification, {}, import("mongoose").DefaultSchemaOptions> & AdminNotification & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, AdminNotification>;
