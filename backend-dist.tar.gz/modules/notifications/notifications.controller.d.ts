import { Admin } from "../admins/entities/admin.entity";
import { AdminNotificationList, NotificationsService } from './notifications.service';
import { RegisterDeviceTokenDto } from './dto/register-device-token.dto';
import { QueryNotificationsDto } from './dto/query-notifications.dto';
export declare class NotificationsController {
    private readonly notificationsService;
    constructor(notificationsService: NotificationsService);
    list(admin: Admin, query: QueryNotificationsDto): Promise<AdminNotificationList>;
    markAllRead(admin: Admin): Promise<{
        updated: number;
    }>;
    markRead(admin: Admin, id: string): Promise<{
        success: boolean;
    }>;
    subscribe(admin: Admin, dto: RegisterDeviceTokenDto): Promise<{
        success: boolean;
    }>;
    unsubscribe(admin: Admin, dto: RegisterDeviceTokenDto): Promise<{
        success: boolean;
    }>;
    test(admin: Admin): Promise<{
        sent: number;
    }>;
}
