import { OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
export interface PushNotificationPayload {
    title: string;
    body: string;
    data?: Record<string, string | number | boolean | null | undefined>;
    link?: string;
}
export declare class FirebaseService implements OnModuleInit {
    private readonly configService;
    private readonly logger;
    private messaging;
    private adminPanelUrl;
    constructor(configService: ConfigService);
    onModuleInit(): void;
    get isEnabled(): boolean;
    sendToTokens(tokens: string[], payload: PushNotificationPayload): Promise<string[]>;
    private resolveLink;
}
