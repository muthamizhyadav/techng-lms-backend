"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const current_admin_decorator_1 = require("../../common/decorators/current-admin.decorator");
const admin_entity_1 = require("../admins/entities/admin.entity");
const notifications_service_1 = require("./notifications.service");
const register_device_token_dto_1 = require("./dto/register-device-token.dto");
const query_notifications_dto_1 = require("./dto/query-notifications.dto");
let NotificationsController = class NotificationsController {
    constructor(notificationsService) {
        this.notificationsService = notificationsService;
    }
    async list(admin, query) {
        return this.notificationsService.listForAdmin(admin.id, query.page, query.limit);
    }
    async markAllRead(admin) {
        return this.notificationsService.markAllRead(admin.id);
    }
    async markRead(admin, id) {
        return this.notificationsService.markRead(admin.id, id);
    }
    async subscribe(admin, dto) {
        await this.notificationsService.registerToken(admin.id, dto.token);
        return { success: true };
    }
    async unsubscribe(admin, dto) {
        await this.notificationsService.unregisterToken(admin.id, dto.token);
        return { success: true };
    }
    async test(admin) {
        return this.notificationsService.sendTestNotification(admin.id);
    }
};
exports.NotificationsController = NotificationsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List notifications for the signed-in admin' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Paginated notification feed.' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin,
        query_notifications_dto_1.QueryNotificationsDto]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "list", null);
__decorate([
    (0, common_1.Patch)('read-all'),
    (0, swagger_1.ApiOperation)({ summary: 'Mark every notification as read' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Notifications marked as read.' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "markAllRead", null);
__decorate([
    (0, common_1.Patch)(':id/read'),
    (0, swagger_1.ApiOperation)({ summary: 'Mark one notification as read' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Notification marked as read.' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin, String]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "markRead", null);
__decorate([
    (0, common_1.Post)('subscribe'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Register this browser for admin push notifications',
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Device token registered.' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin,
        register_device_token_dto_1.RegisterDeviceTokenDto]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "subscribe", null);
__decorate([
    (0, common_1.Delete)('subscribe'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Unregister this browser from admin push notifications',
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Device token removed.' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin,
        register_device_token_dto_1.RegisterDeviceTokenDto]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "unsubscribe", null);
__decorate([
    (0, common_1.Post)('test'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Send a test push notification to this admin' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Test notification dispatched.' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "test", null);
exports.NotificationsController = NotificationsController = __decorate([
    (0, swagger_1.ApiTags)('Admin Notifications'),
    (0, swagger_1.ApiBearerAuth)(),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, common_1.Controller)('admin/notifications'),
    __metadata("design:paramtypes", [notifications_service_1.NotificationsService])
], NotificationsController);
//# sourceMappingURL=notifications.controller.js.map