import { HydratedDocument } from 'mongoose';
export type CartDocument = HydratedDocument<Cart>;
export declare class CartItem {
    courseId: string;
    addedAt: Date;
}
export declare const CartItemSchema: import("mongoose").Schema<CartItem, import("mongoose").Model<CartItem, any, any, any, any, any, CartItem>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, CartItem, import("mongoose").Document<unknown, {}, CartItem, {
    id: string;
}, import("mongoose").DefaultSchemaOptions> & Omit<CartItem & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, "id"> & import("mongoose").HydratedDocumentOverrides<{
    id: string;
}>, {
    courseId?: import("mongoose").SchemaDefinitionProperty<string, CartItem, import("mongoose").Document<unknown, {}, CartItem, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<CartItem & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    addedAt?: import("mongoose").SchemaDefinitionProperty<Date, CartItem, import("mongoose").Document<unknown, {}, CartItem, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<CartItem & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
}, CartItem>;
export declare class Cart {
    _id: string;
    id: string;
    userId: string;
    items: CartItem[];
    createdAt: Date;
    updatedAt: Date;
}
export declare const CartSchema: import("mongoose").Schema<Cart, import("mongoose").Model<Cart, any, any, any, any, any, Cart>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Cart, import("mongoose").Document<unknown, {}, Cart, {}, import("mongoose").DefaultSchemaOptions> & Cart & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, Cart, import("mongoose").Document<unknown, {}, Cart, {}, import("mongoose").DefaultSchemaOptions> & Cart & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, Cart, import("mongoose").Document<unknown, {}, Cart, {}, import("mongoose").DefaultSchemaOptions> & Cart & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    userId?: import("mongoose").SchemaDefinitionProperty<string, Cart, import("mongoose").Document<unknown, {}, Cart, {}, import("mongoose").DefaultSchemaOptions> & Cart & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    items?: import("mongoose").SchemaDefinitionProperty<CartItem[], Cart, import("mongoose").Document<unknown, {}, Cart, {}, import("mongoose").DefaultSchemaOptions> & Cart & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, Cart, import("mongoose").Document<unknown, {}, Cart, {}, import("mongoose").DefaultSchemaOptions> & Cart & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, Cart, import("mongoose").Document<unknown, {}, Cart, {}, import("mongoose").DefaultSchemaOptions> & Cart & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, Cart>;
