import { Model } from 'mongoose';
import { CartDocument } from './entities/cart.entity';
import { CourseDocument } from '../courses/entities/course.entity';
import { CartResponseDto } from './dto/cart.dto';
export declare class CartService {
    private readonly cartModel;
    private readonly courseModel;
    constructor(cartModel: Model<CartDocument>, courseModel: Model<CourseDocument>);
    getCart(userId: string): Promise<CartResponseDto>;
    addItem(userId: string, courseId: string): Promise<CartResponseDto>;
    removeItem(userId: string, courseId: string): Promise<CartResponseDto>;
    clearCart(userId: string): Promise<void>;
}
