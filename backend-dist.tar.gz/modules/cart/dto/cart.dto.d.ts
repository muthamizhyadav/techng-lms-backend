export declare class AddToCartDto {
    courseId: string;
}
export declare class CartCourseItemDto {
    courseId: string;
    title: string;
    category: string;
    price: number;
    thumbnail: string;
    instructor: string;
    duration: string;
    addedAt: Date;
}
export declare class CartResponseDto {
    id: string;
    userId: string;
    items: CartCourseItemDto[];
    totalAmount: number;
    totalItems: number;
}
