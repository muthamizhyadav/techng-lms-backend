"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CartResponseDto = exports.CartCourseItemDto = exports.AddToCartDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class AddToCartDto {
}
exports.AddToCartDto = AddToCartDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: '0f8fad5b-d9cb-469f-a165-70867728950e',
        description: 'Course UUID to add to cart',
    }),
    (0, class_validator_1.IsUUID)('4', { message: 'Invalid course ID format' }),
    (0, class_validator_1.IsNotEmpty)({ message: 'courseId is required' }),
    __metadata("design:type", String)
], AddToCartDto.prototype, "courseId", void 0);
class CartCourseItemDto {
}
exports.CartCourseItemDto = CartCourseItemDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: '0f8fad5b-d9cb-469f-a165-70867728950e' }),
    __metadata("design:type", String)
], CartCourseItemDto.prototype, "courseId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Full Stack Web Development' }),
    __metadata("design:type", String)
], CartCourseItemDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Web Development' }),
    __metadata("design:type", String)
], CartCourseItemDto.prototype, "category", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 4999 }),
    __metadata("design:type", Number)
], CartCourseItemDto.prototype, "price", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'https://cdn.example.com/thumb.jpg', required: false }),
    __metadata("design:type", String)
], CartCourseItemDto.prototype, "thumbnail", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Bola Johnson', required: false }),
    __metadata("design:type", String)
], CartCourseItemDto.prototype, "instructor", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: '6 Weeks', required: false }),
    __metadata("design:type", String)
], CartCourseItemDto.prototype, "duration", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: '2026-08-25T10:00:00Z' }),
    __metadata("design:type", Date)
], CartCourseItemDto.prototype, "addedAt", void 0);
class CartResponseDto {
}
exports.CartResponseDto = CartResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'c878fbfa-2713-4412-a16a-73d76e7372cf' }),
    __metadata("design:type", String)
], CartResponseDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: '0f8fad5b-d9cb-469f-a165-70867728950e' }),
    __metadata("design:type", String)
], CartResponseDto.prototype, "userId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [CartCourseItemDto] }),
    __metadata("design:type", Array)
], CartResponseDto.prototype, "items", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 4999 }),
    __metadata("design:type", Number)
], CartResponseDto.prototype, "totalAmount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1 }),
    __metadata("design:type", Number)
], CartResponseDto.prototype, "totalItems", void 0);
//# sourceMappingURL=cart.dto.js.map