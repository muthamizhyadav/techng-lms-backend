import { CartService } from './cart.service';
import { User } from "../users/entities/user.entity";
import { AddToCartDto, CartResponseDto } from './dto/cart.dto';
export declare class CartController {
    private readonly cartService;
    constructor(cartService: CartService);
    getCart(user: User): Promise<CartResponseDto>;
    addToCart(user: User, dto: AddToCartDto): Promise<CartResponseDto>;
    removeFromCart(user: User, courseId: string): Promise<CartResponseDto>;
    clearCart(user: User): Promise<{
        message: string;
    }>;
}
