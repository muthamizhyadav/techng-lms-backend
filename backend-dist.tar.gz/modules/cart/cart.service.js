"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CartService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const cart_entity_1 = require("./entities/cart.entity");
const course_entity_1 = require("../courses/entities/course.entity");
let CartService = class CartService {
    constructor(cartModel, courseModel) {
        this.cartModel = cartModel;
        this.courseModel = courseModel;
    }
    async getCart(userId) {
        let cart = await this.cartModel.findOne({ userId });
        if (!cart) {
            cart = await this.cartModel.create({ userId, items: [] });
        }
        const courseIds = cart.items.map((i) => i.courseId);
        const courses = await this.courseModel.find({
            _id: { $in: courseIds },
            deletedAt: null,
        });
        const courseMap = new Map();
        courses.forEach((c) => {
            courseMap.set(c._id.toString(), c);
        });
        const populatedItems = [];
        let totalAmount = 0;
        for (const item of cart.items) {
            const course = courseMap.get(item.courseId);
            if (course) {
                const itemDto = {
                    courseId: course._id.toString(),
                    title: course.title,
                    category: course.category,
                    price: course.price || 0,
                    thumbnail: course.thumbnail || '',
                    instructor: course.instructor || '',
                    duration: course.duration || '',
                    addedAt: item.addedAt,
                };
                populatedItems.push(itemDto);
                totalAmount += course.price || 0;
            }
        }
        return {
            id: cart._id.toString(),
            userId: cart.userId,
            items: populatedItems,
            totalAmount,
            totalItems: populatedItems.length,
        };
    }
    async addItem(userId, courseId) {
        const course = await this.courseModel.findOne({ _id: courseId, deletedAt: null });
        if (!course) {
            throw new common_1.NotFoundException(`Course with ID "${courseId}" not found`);
        }
        let cart = await this.cartModel.findOne({ userId });
        if (!cart) {
            cart = await this.cartModel.create({
                userId,
                items: [{ courseId, addedAt: new Date() }],
            });
        }
        else {
            const alreadyInCart = cart.items.some((i) => i.courseId === courseId);
            if (alreadyInCart) {
                throw new common_1.ConflictException('Course is already in your cart');
            }
            cart.items.push({ courseId, addedAt: new Date() });
            await cart.save();
        }
        return this.getCart(userId);
    }
    async removeItem(userId, courseId) {
        const cart = await this.cartModel.findOne({ userId });
        if (!cart) {
            throw new common_1.NotFoundException('Cart not found');
        }
        cart.items = cart.items.filter((i) => i.courseId !== courseId);
        await cart.save();
        return this.getCart(userId);
    }
    async clearCart(userId) {
        await this.cartModel.findOneAndUpdate({ userId }, { $set: { items: [] } }, { upsert: true });
    }
};
exports.CartService = CartService;
exports.CartService = CartService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(cart_entity_1.Cart.name)),
    __param(1, (0, mongoose_1.InjectModel)(course_entity_1.Course.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model])
], CartService);
//# sourceMappingURL=cart.service.js.map