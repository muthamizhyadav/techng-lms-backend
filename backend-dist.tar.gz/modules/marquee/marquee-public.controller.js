"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarqueePublicController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const marquee_service_1 = require("./marquee.service");
let MarqueePublicController = class MarqueePublicController {
    constructor(marqueeService) {
        this.marqueeService = marqueeService;
    }
    async getActive() {
        return this.marqueeService.findActive();
    }
};
exports.MarqueePublicController = MarqueePublicController;
__decorate([
    (0, common_1.Get)('active'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get currently active marquee announcements (Public)',
        description: 'Returns active, currently scheduled announcements for the LMS header.',
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of active announcements' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MarqueePublicController.prototype, "getActive", null);
exports.MarqueePublicController = MarqueePublicController = __decorate([
    (0, swagger_1.ApiTags)('🌐 Public Marquee'),
    (0, common_1.Controller)('public/marquees'),
    __metadata("design:paramtypes", [marquee_service_1.MarqueeService])
], MarqueePublicController);
//# sourceMappingURL=marquee-public.controller.js.map