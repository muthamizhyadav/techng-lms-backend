import { HydratedDocument } from 'mongoose';
export type MarqueeAnnouncementDocument = HydratedDocument<MarqueeAnnouncement>;
export declare class MarqueeAnnouncement {
    _id: string;
    id: string;
    text: string;
    linkUrl: string;
    linkText: string;
    badgeText: string;
    icon: string;
    priority: number;
    order: number;
    isActive: boolean;
    startDate?: Date | null;
    endDate?: Date | null;
    createdByAdminId?: string;
    updatedByAdminId?: string;
    deletedAt?: Date | null;
}
export declare const MarqueeAnnouncementSchema: import("mongoose").Schema<MarqueeAnnouncement, import("mongoose").Model<MarqueeAnnouncement, any, any, any, any, any, MarqueeAnnouncement>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    text?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    linkUrl?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    linkText?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    badgeText?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    icon?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    priority?: import("mongoose").SchemaDefinitionProperty<number, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    order?: import("mongoose").SchemaDefinitionProperty<number, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isActive?: import("mongoose").SchemaDefinitionProperty<boolean, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    startDate?: import("mongoose").SchemaDefinitionProperty<Date, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    endDate?: import("mongoose").SchemaDefinitionProperty<Date, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdByAdminId?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedByAdminId?: import("mongoose").SchemaDefinitionProperty<string, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    deletedAt?: import("mongoose").SchemaDefinitionProperty<Date, MarqueeAnnouncement, import("mongoose").Document<unknown, {}, MarqueeAnnouncement, {}, import("mongoose").DefaultSchemaOptions> & MarqueeAnnouncement & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, MarqueeAnnouncement>;
