"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarqueeAnnouncementSchema = exports.MarqueeAnnouncement = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const uuid_util_1 = require("../../../common/utils/uuid.util");
let MarqueeAnnouncement = class MarqueeAnnouncement {
};
exports.MarqueeAnnouncement = MarqueeAnnouncement;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "text", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "linkUrl", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "linkText", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "badgeText", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: 'zap' }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "icon", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Number, default: 1 }),
    __metadata("design:type", Number)
], MarqueeAnnouncement.prototype, "priority", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Number, default: 1 }),
    __metadata("design:type", Number)
], MarqueeAnnouncement.prototype, "order", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Boolean, default: true }),
    __metadata("design:type", Boolean)
], MarqueeAnnouncement.prototype, "isActive", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], MarqueeAnnouncement.prototype, "startDate", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], MarqueeAnnouncement.prototype, "endDate", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "createdByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], MarqueeAnnouncement.prototype, "updatedByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], MarqueeAnnouncement.prototype, "deletedAt", void 0);
exports.MarqueeAnnouncement = MarqueeAnnouncement = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'marquee_announcements',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                return ret;
            },
        },
        toObject: {
            virtuals: true,
            versionKey: false,
        },
    })
], MarqueeAnnouncement);
exports.MarqueeAnnouncementSchema = mongoose_1.SchemaFactory.createForClass(MarqueeAnnouncement);
exports.MarqueeAnnouncementSchema.index({ isActive: 1, order: 1, priority: -1, deletedAt: 1 });
//# sourceMappingURL=marquee.entity.js.map