export declare class MarqueeModule {
}
