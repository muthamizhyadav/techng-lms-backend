import { Model } from 'mongoose';
import { MarqueeAnnouncement, MarqueeAnnouncementDocument } from './entities/marquee.entity';
import { CreateMarqueeDto, UpdateMarqueeDto, QueryMarqueeDto } from './dto/marquee.dto';
export declare class MarqueeService {
    private readonly marqueeModel;
    constructor(marqueeModel: Model<MarqueeAnnouncementDocument>);
    create(dto: CreateMarqueeDto, adminId?: string): Promise<MarqueeAnnouncement>;
    findAll(query: QueryMarqueeDto): Promise<{
        data: MarqueeAnnouncement[];
        total: number;
        page: number;
        limit: number;
    }>;
    findActive(): Promise<MarqueeAnnouncement[]>;
    findOne(id: string): Promise<MarqueeAnnouncement>;
    update(id: string, dto: UpdateMarqueeDto, adminId?: string): Promise<MarqueeAnnouncement>;
    updateStatus(id: string, isActive: boolean, adminId?: string): Promise<MarqueeAnnouncement>;
    remove(id: string): Promise<void>;
}
