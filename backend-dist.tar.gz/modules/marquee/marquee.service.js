"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarqueeService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const marquee_entity_1 = require("./entities/marquee.entity");
const uuid_util_1 = require("../../common/utils/uuid.util");
let MarqueeService = class MarqueeService {
    constructor(marqueeModel) {
        this.marqueeModel = marqueeModel;
    }
    async create(dto, adminId) {
        const created = await this.marqueeModel.create({
            _id: (0, uuid_util_1.generateUuid)(),
            ...dto,
            startDate: dto.startDate ? new Date(dto.startDate) : null,
            endDate: dto.endDate ? new Date(dto.endDate) : null,
            createdByAdminId: adminId || null,
            updatedByAdminId: adminId || null,
            deletedAt: null,
        });
        return created.toJSON();
    }
    async findAll(query) {
        const page = Math.max(1, Number(query.page) || 1);
        const limit = Math.max(1, Math.min(100, Number(query.limit) || 20));
        const skip = (page - 1) * limit;
        const filter = { deletedAt: null };
        if (typeof query.isActive === 'boolean') {
            filter.isActive = query.isActive;
        }
        if (query.search && query.search.trim()) {
            filter.text = { $regex: query.search.trim(), $options: 'i' };
        }
        const [data, total] = await Promise.all([
            this.marqueeModel
                .find(filter)
                .sort({ order: 1, priority: -1, createdAt: -1 })
                .skip(skip)
                .limit(limit)
                .exec(),
            this.marqueeModel.countDocuments(filter),
        ]);
        return {
            data: data.map((item) => item.toJSON()),
            total,
            page,
            limit,
        };
    }
    async findActive() {
        const now = new Date();
        const items = await this.marqueeModel
            .find({
            deletedAt: null,
            isActive: true,
            $and: [
                {
                    $or: [{ startDate: null }, { startDate: { $lte: now } }],
                },
                {
                    $or: [{ endDate: null }, { endDate: { $gte: now } }],
                },
            ],
        })
            .sort({ order: 1, priority: -1, createdAt: -1 })
            .exec();
        if (items.length === 0) {
            return [
                {
                    _id: 'default_1',
                    id: 'default_1',
                    text: '🔥 SPECIAL OFFER: Flat 50% OFF on all Full Stack Bootcamps! Use Code: TECH50',
                    linkUrl: '/free-courses',
                    linkText: 'Explore',
                    badgeText: '50% OFF',
                    icon: 'zap',
                    priority: 1,
                    order: 1,
                    isActive: true,
                },
                {
                    _id: 'default_2',
                    id: 'default_2',
                    text: '⚡ New Batch Starting This Monday for Playwright & Automation Testing!',
                    linkUrl: '/free-courses',
                    linkText: 'Join Now',
                    badgeText: 'NEW',
                    icon: 'sparkles',
                    priority: 2,
                    order: 2,
                    isActive: true,
                },
                {
                    _id: 'default_3',
                    id: 'default_3',
                    text: '🎓 Get 1-on-1 Free Mentorship Session on Every Course Enrollment',
                    linkUrl: '/free-courses',
                    linkText: 'Claim Free Session',
                    badgeText: 'FREE',
                    icon: 'award',
                    priority: 3,
                    order: 3,
                    isActive: true,
                },
                {
                    _id: 'default_4',
                    id: 'default_4',
                    text: '🚀 Certified Cloud Architect & DevOps Course – Extra 20% Instant Discount',
                    linkUrl: '/free-courses',
                    linkText: 'View Details',
                    badgeText: '20% OFF',
                    icon: 'flame',
                    priority: 4,
                    order: 4,
                    isActive: true,
                },
            ];
        }
        return items.map((i) => i.toJSON());
    }
    async findOne(id) {
        const item = await this.marqueeModel.findOne({ _id: id, deletedAt: null });
        if (!item) {
            throw new common_1.NotFoundException(`Marquee announcement with ID "${id}" not found`);
        }
        return item.toJSON();
    }
    async update(id, dto, adminId) {
        await this.findOne(id);
        const updatePayload = {
            ...dto,
            updatedByAdminId: adminId || null,
        };
        if (dto.startDate !== undefined) {
            updatePayload.startDate = dto.startDate ? new Date(dto.startDate) : null;
        }
        if (dto.endDate !== undefined) {
            updatePayload.endDate = dto.endDate ? new Date(dto.endDate) : null;
        }
        const updated = await this.marqueeModel.findOneAndUpdate({ _id: id, deletedAt: null }, { $set: updatePayload }, { new: true });
        return updated.toJSON();
    }
    async updateStatus(id, isActive, adminId) {
        await this.findOne(id);
        const updated = await this.marqueeModel.findOneAndUpdate({ _id: id, deletedAt: null }, { $set: { isActive, updatedByAdminId: adminId || null } }, { new: true });
        return updated.toJSON();
    }
    async remove(id) {
        await this.findOne(id);
        await this.marqueeModel.findOneAndUpdate({ _id: id, deletedAt: null }, { $set: { deletedAt: new Date(), isActive: false } });
    }
};
exports.MarqueeService = MarqueeService;
exports.MarqueeService = MarqueeService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(marquee_entity_1.MarqueeAnnouncement.name)),
    __metadata("design:paramtypes", [mongoose_2.Model])
], MarqueeService);
//# sourceMappingURL=marquee.service.js.map