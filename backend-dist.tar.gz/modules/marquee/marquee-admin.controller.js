"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarqueeAdminController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const marquee_service_1 = require("./marquee.service");
const marquee_dto_1 = require("./dto/marquee.dto");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const current_admin_decorator_1 = require("../../common/decorators/current-admin.decorator");
let MarqueeAdminController = class MarqueeAdminController {
    constructor(marqueeService) {
        this.marqueeService = marqueeService;
    }
    async create(dto, admin) {
        return this.marqueeService.create(dto, admin.sub);
    }
    async findAll(query) {
        return this.marqueeService.findAll(query);
    }
    async findOne(id) {
        return this.marqueeService.findOne(id);
    }
    async update(id, dto, admin) {
        return this.marqueeService.update(id, dto, admin.sub);
    }
    async updateStatus(id, dto, admin) {
        return this.marqueeService.updateStatus(id, dto.isActive, admin.sub);
    }
    async remove(id) {
        return this.marqueeService.remove(id);
    }
};
exports.MarqueeAdminController = MarqueeAdminController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new marquee announcement' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [marquee_dto_1.CreateMarqueeDto, Object]),
    __metadata("design:returntype", Promise)
], MarqueeAdminController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'List all marquee announcements' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [marquee_dto_1.QueryMarqueeDto]),
    __metadata("design:returntype", Promise)
], MarqueeAdminController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get marquee announcement details' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MarqueeAdminController.prototype, "findOne", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update marquee announcement' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, marquee_dto_1.UpdateMarqueeDto, Object]),
    __metadata("design:returntype", Promise)
], MarqueeAdminController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, swagger_1.ApiOperation)({ summary: 'Toggle marquee announcement active status' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, marquee_dto_1.UpdateMarqueeStatusDto, Object]),
    __metadata("design:returntype", Promise)
], MarqueeAdminController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a marquee announcement' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MarqueeAdminController.prototype, "remove", null);
exports.MarqueeAdminController = MarqueeAdminController = __decorate([
    (0, swagger_1.ApiTags)('📢 Marquee Management (Admin)'),
    (0, common_1.Controller)('admin/marquees'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    __metadata("design:paramtypes", [marquee_service_1.MarqueeService])
], MarqueeAdminController);
//# sourceMappingURL=marquee-admin.controller.js.map