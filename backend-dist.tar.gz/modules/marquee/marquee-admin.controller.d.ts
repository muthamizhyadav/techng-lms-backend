import { MarqueeService } from './marquee.service';
import { CreateMarqueeDto, UpdateMarqueeDto, UpdateMarqueeStatusDto, QueryMarqueeDto } from './dto/marquee.dto';
import type { AdminJwtPayload } from "../../shared/interfaces/jwt-payload.interface";
export declare class MarqueeAdminController {
    private readonly marqueeService;
    constructor(marqueeService: MarqueeService);
    create(dto: CreateMarqueeDto, admin: AdminJwtPayload): Promise<import("./entities/marquee.entity").MarqueeAnnouncement>;
    findAll(query: QueryMarqueeDto): Promise<{
        data: import("./entities/marquee.entity").MarqueeAnnouncement[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<import("./entities/marquee.entity").MarqueeAnnouncement>;
    update(id: string, dto: UpdateMarqueeDto, admin: AdminJwtPayload): Promise<import("./entities/marquee.entity").MarqueeAnnouncement>;
    updateStatus(id: string, dto: UpdateMarqueeStatusDto, admin: AdminJwtPayload): Promise<import("./entities/marquee.entity").MarqueeAnnouncement>;
    remove(id: string): Promise<void>;
}
