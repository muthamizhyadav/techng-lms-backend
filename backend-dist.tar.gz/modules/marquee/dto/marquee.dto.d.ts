export declare class CreateMarqueeDto {
    text: string;
    linkUrl?: string;
    linkText?: string;
    badgeText?: string;
    icon?: string;
    priority?: number;
    order?: number;
    isActive?: boolean;
    startDate?: string;
    endDate?: string;
}
declare const UpdateMarqueeDto_base: import("@nestjs/common").Type<Partial<CreateMarqueeDto>>;
export declare class UpdateMarqueeDto extends UpdateMarqueeDto_base {
}
export declare class UpdateMarqueeStatusDto {
    isActive: boolean;
}
export declare class QueryMarqueeDto {
    page?: number;
    limit?: number;
    search?: string;
    isActive?: boolean;
}
export {};
