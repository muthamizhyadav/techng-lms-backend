import { MarqueeService } from './marquee.service';
export declare class MarqueePublicController {
    private readonly marqueeService;
    constructor(marqueeService: MarqueeService);
    getActive(): Promise<import("./entities/marquee.entity").MarqueeAnnouncement[]>;
}
