"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCoursesStudentService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const free_course_entity_1 = require("./entities/free-course.entity");
const free_course_enrollment_entity_1 = require("./entities/free-course-enrollment.entity");
let FreeCoursesStudentService = class FreeCoursesStudentService {
    constructor(freeCourseModel, freeCourseEnrollmentModel) {
        this.freeCourseModel = freeCourseModel;
        this.freeCourseEnrollmentModel = freeCourseEnrollmentModel;
    }
    async getMyCourses(studentId) {
        const enrollments = await this.freeCourseEnrollmentModel
            .find({ studentId })
            .sort({ updatedAt: -1 })
            .exec();
        if (enrollments.length === 0) {
            return [];
        }
        const courseIds = enrollments.map((e) => e.courseId);
        const courses = await this.freeCourseModel
            .find({
            _id: { $in: courseIds },
            deletedAt: null,
        })
            .exec();
        const courseMap = new Map(courses.map((c) => [c.id || c._id, c]));
        return enrollments
            .map((enrollment) => {
            const course = courseMap.get(enrollment.courseId);
            if (!course)
                return null;
            let totalChapters = 0;
            let firstChapterId = null;
            for (const mod of course.modules || []) {
                for (const chap of mod.chapters || []) {
                    totalChapters++;
                    if (!firstChapterId) {
                        firstChapterId = chap._id;
                    }
                }
            }
            const completedCount = (enrollment.completedChapters || []).length;
            const pendingCount = Math.max(0, totalChapters - completedCount);
            return {
                enrollmentId: enrollment._id,
                courseId: course._id,
                title: course.title,
                description: course.description,
                instructor: course.instructor,
                category: course.category,
                level: course.level,
                duration: course.duration,
                videoDuration: course.videoDuration,
                thumbnail: course.thumbnail,
                banner: course.banner,
                progress: enrollment.progress || 0,
                status: enrollment.status,
                totalChapters,
                completedChaptersCount: completedCount,
                pendingChaptersCount: pendingCount,
                currentChapterId: enrollment.currentChapterId || firstChapterId || null,
                attachmentsCount: (course.attachments || []).length,
                attachments: course.attachments || [],
                enrolledAt: enrollment.enrolledAt,
                updatedAt: enrollment.updatedAt,
            };
        })
            .filter((item) => item !== null);
    }
    async getAvailableCourses(studentId) {
        const enrollments = await this.freeCourseEnrollmentModel
            .find({ studentId })
            .select('courseId status progress')
            .exec();
        if (enrollments.length === 0) {
            return [];
        }
        const assignedCourseIds = enrollments.map((e) => e.courseId);
        const courses = await this.freeCourseModel
            .find({
            _id: { $in: assignedCourseIds },
            status: { $in: [free_course_entity_1.FreeCourseStatus.PUBLISHED, free_course_entity_1.FreeCourseStatus.ACTIVE] },
            deletedAt: null,
        })
            .sort({ createdAt: -1 })
            .exec();
        const enrollmentMap = new Map(enrollments.map((e) => [e.courseId, e]));
        return courses.map((course) => {
            const enrollment = enrollmentMap.get(course.id || course._id);
            let totalChapters = 0;
            for (const mod of course.modules || []) {
                totalChapters += (mod.chapters || []).length;
            }
            return {
                id: course._id,
                title: course.title,
                description: course.description,
                instructor: course.instructor,
                trainerId: course.trainerId || null,
                trainerName: course.trainerName || course.instructor,
                trainerDesignation: course.trainerDesignation || null,
                trainerAvatar: course.trainerAvatar || null,
                trainerBio: course.trainerBio || null,
                category: course.category,
                level: course.level,
                duration: course.duration,
                videoDuration: course.videoDuration,
                skills: course.skills,
                thumbnail: course.thumbnail,
                banner: course.banner,
                totalChapters,
                attachmentsCount: (course.attachments || []).length,
                isEnrolled: !!enrollment,
                enrollmentId: enrollment?._id || null,
                progress: enrollment?.progress || 0,
            };
        });
    }
    async getCourseDetails(studentId, courseId) {
        const course = await this.freeCourseModel.findOne({
            _id: courseId,
            deletedAt: null,
        });
        if (!course) {
            throw new common_1.NotFoundException(`Free Course with ID "${courseId}" not found`);
        }
        const enrollment = await this.freeCourseEnrollmentModel.findOne({
            studentId,
            courseId,
        });
        if (!enrollment) {
            throw new common_1.ForbiddenException('Access Denied: You do not have access to this free course. Free courses are restricted and must be specifically assigned to your account by TechNG Administration.');
        }
        const chapterProgressMap = enrollment
            ? enrollment.chapterProgress || new Map()
            : new Map();
        const completedSet = new Set(enrollment?.completedChapters || []);
        let totalChapters = 0;
        const modulesWithProgress = (course.modules || []).map((mod) => {
            const chapters = (mod.chapters || []).map((chap) => {
                totalChapters++;
                const prog = chapterProgressMap instanceof Map
                    ? chapterProgressMap.get(chap._id)
                    : chapterProgressMap?.[chap._id];
                const isCompleted = completedSet.has(chap._id) || !!prog?.completed;
                return {
                    _id: chap._id,
                    title: chap.title,
                    videoUrl: chap.videoUrl,
                    duration: chap.duration || 0,
                    order: chap.order,
                    type: chap.type || 'video',
                    documentUrl: chap.documentUrl,
                    attachments: chap.attachments || [],
                    completed: isCompleted,
                    watchTime: prog?.watchTime || 0,
                    lastPosition: prog?.lastPosition || 0,
                };
            });
            return {
                _id: mod._id,
                title: mod.title,
                order: mod.order,
                thumbnail: mod.thumbnail,
                chapters,
            };
        });
        return {
            course: {
                id: course._id,
                title: course.title,
                description: course.description,
                instructor: course.instructor,
                category: course.category,
                level: course.level,
                duration: course.duration,
                videoDuration: course.videoDuration,
                skills: course.skills,
                thumbnail: course.thumbnail,
                banner: course.banner,
                attachments: course.attachments || [],
                modules: modulesWithProgress,
            },
            enrollment: enrollment
                ? {
                    id: enrollment._id,
                    progress: enrollment.progress,
                    status: enrollment.status,
                    completedChapters: enrollment.completedChapters,
                    currentChapterId: enrollment.currentChapterId,
                    enrolledAt: enrollment.enrolledAt,
                }
                : null,
            totalChapters,
            completedChaptersCount: completedSet.size,
            pendingChaptersCount: Math.max(0, totalChapters - completedSet.size),
        };
    }
    async updateProgress(studentId, courseId, dto) {
        const enrollment = await this.freeCourseEnrollmentModel.findOne({
            studentId,
            courseId,
        });
        if (!enrollment) {
            throw new common_1.ForbiddenException('Access Denied: You do not have access to this free course. Free courses require admin assignment.');
        }
        const { chapterId, watchTime, lastPosition } = dto;
        const existingProgress = enrollment.chapterProgress instanceof Map
            ? enrollment.chapterProgress.get(chapterId)
            : enrollment.chapterProgress?.[chapterId];
        const isCompleted = existingProgress?.completed ||
            (enrollment.completedChapters || []).includes(chapterId);
        const updatedData = {
            completed: isCompleted,
            watchTime: Math.max(watchTime || 0, existingProgress?.watchTime || 0),
            lastPosition: lastPosition || 0,
            completedAt: existingProgress?.completedAt || null,
        };
        if (enrollment.chapterProgress instanceof Map) {
            enrollment.chapterProgress.set(chapterId, updatedData);
        }
        else {
            enrollment.chapterProgress[chapterId] = updatedData;
        }
        enrollment.currentChapterId = chapterId;
        enrollment.markModified('chapterProgress');
        await enrollment.save();
        return {
            success: true,
            chapterId,
            watchTime: updatedData.watchTime,
            lastPosition: updatedData.lastPosition,
            completed: updatedData.completed,
        };
    }
    async completeChapter(studentId, courseId, chapterId) {
        const course = await this.freeCourseModel.findOne({
            _id: courseId,
            deletedAt: null,
        });
        if (!course) {
            throw new common_1.NotFoundException(`Free Course with ID "${courseId}" not found`);
        }
        const enrollment = await this.freeCourseEnrollmentModel.findOne({
            studentId,
            courseId,
        });
        if (!enrollment) {
            throw new common_1.ForbiddenException('Access Denied: You do not have access to this free course. Free courses require admin assignment.');
        }
        const completedSet = new Set(enrollment.completedChapters || []);
        completedSet.add(chapterId);
        enrollment.completedChapters = Array.from(completedSet);
        const existingProgress = enrollment.chapterProgress instanceof Map
            ? enrollment.chapterProgress.get(chapterId)
            : enrollment.chapterProgress?.[chapterId];
        const updatedData = {
            completed: true,
            watchTime: existingProgress?.watchTime || 0,
            lastPosition: existingProgress?.lastPosition || 0,
            completedAt: existingProgress?.completedAt || new Date(),
        };
        if (enrollment.chapterProgress instanceof Map) {
            enrollment.chapterProgress.set(chapterId, updatedData);
        }
        else {
            enrollment.chapterProgress[chapterId] = updatedData;
        }
        let totalChapters = 0;
        for (const mod of course.modules || []) {
            totalChapters += (mod.chapters || []).length;
        }
        const completedCount = enrollment.completedChapters.length;
        const progress = totalChapters > 0
            ? Math.min(100, Math.round((completedCount / totalChapters) * 100))
            : 100;
        enrollment.progress = progress;
        if (progress >= 100) {
            enrollment.status = free_course_enrollment_entity_1.FreeCourseEnrollmentStatus.COMPLETED;
        }
        enrollment.currentChapterId = chapterId;
        enrollment.markModified('chapterProgress');
        await enrollment.save();
        return {
            success: true,
            chapterId,
            completed: true,
            progress,
            completedChaptersCount: completedCount,
            totalChapters,
            status: enrollment.status,
        };
    }
};
exports.FreeCoursesStudentService = FreeCoursesStudentService;
exports.FreeCoursesStudentService = FreeCoursesStudentService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(free_course_entity_1.FreeCourse.name)),
    __param(1, (0, mongoose_1.InjectModel)(free_course_enrollment_entity_1.FreeCourseEnrollment.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model])
], FreeCoursesStudentService);
//# sourceMappingURL=free-courses-student.service.js.map