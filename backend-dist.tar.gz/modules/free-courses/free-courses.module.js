"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCoursesModule = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const free_course_entity_1 = require("./entities/free-course.entity");
const free_course_trainer_entity_1 = require("./entities/free-course-trainer.entity");
const free_course_enrollment_entity_1 = require("./entities/free-course-enrollment.entity");
const user_entity_1 = require("../users/entities/user.entity");
const admin_entity_1 = require("../admins/entities/admin.entity");
const free_courses_admin_service_1 = require("./free-courses-admin.service");
const free_courses_student_service_1 = require("./free-courses-student.service");
const free_course_storage_service_1 = require("./storage/free-course-storage.service");
const free_courses_admin_controller_1 = require("./free-courses-admin.controller");
const free_courses_student_controller_1 = require("./free-courses-student.controller");
let FreeCoursesModule = class FreeCoursesModule {
};
exports.FreeCoursesModule = FreeCoursesModule;
exports.FreeCoursesModule = FreeCoursesModule = __decorate([
    (0, common_1.Module)({
        imports: [
            mongoose_1.MongooseModule.forFeature([
                { name: free_course_entity_1.FreeCourse.name, schema: free_course_entity_1.FreeCourseSchema },
                { name: free_course_trainer_entity_1.FreeCourseTrainer.name, schema: free_course_trainer_entity_1.FreeCourseTrainerSchema },
                {
                    name: free_course_enrollment_entity_1.FreeCourseEnrollment.name,
                    schema: free_course_enrollment_entity_1.FreeCourseEnrollmentSchema,
                },
                { name: user_entity_1.User.name, schema: user_entity_1.UserSchema },
                { name: admin_entity_1.Admin.name, schema: admin_entity_1.AdminSchema },
            ]),
        ],
        controllers: [
            free_courses_admin_controller_1.FreeCoursesAdminController,
            free_courses_student_controller_1.FreeCoursesStudentController,
        ],
        providers: [
            free_courses_admin_service_1.FreeCoursesAdminService,
            free_courses_student_service_1.FreeCoursesStudentService,
            free_course_storage_service_1.FreeCourseStorageService,
        ],
        exports: [
            free_courses_admin_service_1.FreeCoursesAdminService,
            free_courses_student_service_1.FreeCoursesStudentService,
            free_course_storage_service_1.FreeCourseStorageService,
        ],
    })
], FreeCoursesModule);
//# sourceMappingURL=free-courses.module.js.map