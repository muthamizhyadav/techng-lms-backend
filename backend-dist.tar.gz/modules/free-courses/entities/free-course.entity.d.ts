import { HydratedDocument } from 'mongoose';
export declare enum FreeCourseStatus {
    DRAFT = "draft",
    PUBLISHED = "published",
    ACTIVE = "active",
    ARCHIVED = "archived"
}
export type FreeCourseDocument = HydratedDocument<FreeCourse>;
export interface FreeCourseAttachment {
    _id?: string;
    title: string;
    fileUrl: string;
    fileType?: string;
    fileSize?: number;
}
export interface FreeCourseChapter {
    _id: string;
    title: string;
    description?: string;
    videoUrl?: string;
    videoThumbnail?: string | null;
    duration?: number;
    videoDuration?: string;
    order: number;
    type?: 'video' | 'document' | 'quiz';
    documentUrl?: string;
    trainerName?: string;
    uploadDate?: string;
    attachments?: FreeCourseAttachment[];
}
export interface FreeCourseModuleItem {
    _id: string;
    title: string;
    order: number;
    thumbnail?: string | null;
    chapters: FreeCourseChapter[];
}
export declare class FreeCourse {
    _id: string;
    id: string;
    title: string;
    description: string;
    instructor: string;
    trainerId: string;
    trainerName: string;
    trainerDesignation: string;
    trainerAvatar: string;
    trainerBio: string;
    promotionalVideoUrl: string;
    promotionalVideoDuration: string;
    category: string;
    status: FreeCourseStatus;
    level: string;
    duration: string;
    videoDuration: string;
    skills: string[];
    thumbnail: string;
    banner: string;
    attachments: FreeCourseAttachment[];
    modules: FreeCourseModuleItem[];
    students: number;
    createdByAdminId: string;
    updatedByAdminId: string;
    deletedAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const FreeCourseSchema: import("mongoose").Schema<FreeCourse, import("mongoose").Model<FreeCourse, any, any, any, any, any, FreeCourse>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    title?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    description?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    instructor?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    trainerId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    trainerName?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    trainerDesignation?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    trainerAvatar?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    trainerBio?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    promotionalVideoUrl?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    promotionalVideoDuration?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    category?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<FreeCourseStatus, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    level?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    duration?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    videoDuration?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    skills?: import("mongoose").SchemaDefinitionProperty<string[], FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    thumbnail?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    banner?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    attachments?: import("mongoose").SchemaDefinitionProperty<FreeCourseAttachment[], FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    modules?: import("mongoose").SchemaDefinitionProperty<FreeCourseModuleItem[], FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    students?: import("mongoose").SchemaDefinitionProperty<number, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdByAdminId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedByAdminId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    deletedAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourse, import("mongoose").Document<unknown, {}, FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, FreeCourse>;
