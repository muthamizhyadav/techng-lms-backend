"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCourseSchema = exports.FreeCourse = exports.FreeCourseStatus = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const uuid_util_1 = require("../../../common/utils/uuid.util");
var FreeCourseStatus;
(function (FreeCourseStatus) {
    FreeCourseStatus["DRAFT"] = "draft";
    FreeCourseStatus["PUBLISHED"] = "published";
    FreeCourseStatus["ACTIVE"] = "active";
    FreeCourseStatus["ARCHIVED"] = "archived";
})(FreeCourseStatus || (exports.FreeCourseStatus = FreeCourseStatus = {}));
let FreeCourse = class FreeCourse {
};
exports.FreeCourse = FreeCourse;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], FreeCourse.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    __metadata("design:type", String)
], FreeCourse.prototype, "title", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "description", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "instructor", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'FreeCourseTrainer', default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "trainerId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "trainerName", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: 'Lead Trainer' }),
    __metadata("design:type", String)
], FreeCourse.prototype, "trainerDesignation", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "trainerAvatar", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: '' }),
    __metadata("design:type", String)
], FreeCourse.prototype, "trainerBio", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "promotionalVideoUrl", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "promotionalVideoDuration", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    __metadata("design:type", String)
], FreeCourse.prototype, "category", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: String,
        enum: FreeCourseStatus,
        default: FreeCourseStatus.DRAFT,
    }),
    __metadata("design:type", String)
], FreeCourse.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: 'All Levels' }),
    __metadata("design:type", String)
], FreeCourse.prototype, "level", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "duration", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "videoDuration", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [String], default: [] }),
    __metadata("design:type", Array)
], FreeCourse.prototype, "skills", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "thumbnail", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "banner", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                _id: { type: String, default: uuid_util_1.generateUuid },
                title: { type: String, required: true },
                fileUrl: { type: String, required: true },
                fileType: { type: String, default: 'application/pdf' },
                fileSize: { type: Number, default: 0 },
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], FreeCourse.prototype, "attachments", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: [
            {
                _id: { type: String, default: uuid_util_1.generateUuid },
                title: { type: String, required: true },
                order: { type: Number, required: true },
                thumbnail: { type: String, default: null },
                chapters: [
                    {
                        _id: { type: String, default: uuid_util_1.generateUuid },
                        title: { type: String, required: true },
                        description: { type: String, default: '' },
                        videoUrl: { type: String, default: '' },
                        videoThumbnail: { type: String, default: null },
                        duration: { type: Number, default: 0 },
                        videoDuration: { type: String, default: null },
                        order: { type: Number, required: true },
                        type: {
                            type: String,
                            enum: ['video', 'quiz', 'document'],
                            default: 'video',
                        },
                        documentUrl: { type: String, default: null },
                        trainerName: { type: String, default: null },
                        uploadDate: { type: String, default: null },
                        attachments: [
                            {
                                _id: { type: String, default: uuid_util_1.generateUuid },
                                title: { type: String, required: true },
                                fileUrl: { type: String, required: true },
                                fileType: { type: String, default: 'application/pdf' },
                                fileSize: { type: Number, default: 0 },
                            },
                        ],
                    },
                ],
            },
        ],
        default: [],
    }),
    __metadata("design:type", Array)
], FreeCourse.prototype, "modules", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Number, default: 0, min: 0 }),
    __metadata("design:type", Number)
], FreeCourse.prototype, "students", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "createdByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], FreeCourse.prototype, "updatedByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], FreeCourse.prototype, "deletedAt", void 0);
exports.FreeCourse = FreeCourse = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'free_courses',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                return ret;
            },
        },
        toObject: {
            virtuals: true,
            versionKey: false,
        },
    })
], FreeCourse);
exports.FreeCourseSchema = mongoose_1.SchemaFactory.createForClass(FreeCourse);
exports.FreeCourseSchema.index({ title: 'text', category: 'text', instructor: 'text', trainerName: 'text' });
exports.FreeCourseSchema.index({ trainerId: 1 });
exports.FreeCourseSchema.index({ status: 1, deletedAt: 1 });
//# sourceMappingURL=free-course.entity.js.map