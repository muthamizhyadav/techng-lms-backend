import { HydratedDocument } from 'mongoose';
export type FreeCourseEnrollmentDocument = HydratedDocument<FreeCourseEnrollment>;
export declare enum FreeCourseEnrollmentStatus {
    ACTIVE = "active",
    COMPLETED = "completed",
    DROPPED = "dropped"
}
export declare class FreeCourseEnrollment {
    _id: string;
    id: string;
    studentId: string;
    courseId: string;
    status: FreeCourseEnrollmentStatus;
    progress: number;
    completedChapters: string[];
    chapterProgress: Map<string, {
        completed: boolean;
        watchTime: number;
        lastPosition: number;
        completedAt: Date | null;
    }>;
    currentChapterId: string;
    enrolledAt: Date;
    assignedByAdminId: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare const FreeCourseEnrollmentSchema: import("mongoose").Schema<FreeCourseEnrollment, import("mongoose").Model<FreeCourseEnrollment, any, any, any, any, any, FreeCourseEnrollment>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    studentId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    courseId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<FreeCourseEnrollmentStatus, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    progress?: import("mongoose").SchemaDefinitionProperty<number, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    completedChapters?: import("mongoose").SchemaDefinitionProperty<string[], FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    chapterProgress?: import("mongoose").SchemaDefinitionProperty<Map<string, {
        completed: boolean;
        watchTime: number;
        lastPosition: number;
        completedAt: Date | null;
    }>, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    currentChapterId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    enrolledAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    assignedByAdminId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourseEnrollment, import("mongoose").Document<unknown, {}, FreeCourseEnrollment, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseEnrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, FreeCourseEnrollment>;
