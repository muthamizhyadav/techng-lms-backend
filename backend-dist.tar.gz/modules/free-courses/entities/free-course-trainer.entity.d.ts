import { HydratedDocument } from 'mongoose';
export type FreeCourseTrainerDocument = HydratedDocument<FreeCourseTrainer>;
export declare class FreeCourseTrainer {
    _id: string;
    id: string;
    name: string;
    username: string;
    adminId: string;
    email: string;
    phone: string;
    designation: string;
    avatar: string;
    bio: string;
    expertise: string[];
    isActive: boolean;
    order: number;
    deletedAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const FreeCourseTrainerSchema: import("mongoose").Schema<FreeCourseTrainer, import("mongoose").Model<FreeCourseTrainer, any, any, any, any, any, FreeCourseTrainer>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    name?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    username?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    adminId?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    email?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    phone?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    designation?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    avatar?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    bio?: import("mongoose").SchemaDefinitionProperty<string, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    expertise?: import("mongoose").SchemaDefinitionProperty<string[], FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isActive?: import("mongoose").SchemaDefinitionProperty<boolean, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    order?: import("mongoose").SchemaDefinitionProperty<number, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    deletedAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, FreeCourseTrainer, import("mongoose").Document<unknown, {}, FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, FreeCourseTrainer>;
