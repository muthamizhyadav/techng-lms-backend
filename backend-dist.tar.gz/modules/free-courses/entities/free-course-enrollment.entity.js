"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCourseEnrollmentSchema = exports.FreeCourseEnrollment = exports.FreeCourseEnrollmentStatus = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const uuid_util_1 = require("../../../common/utils/uuid.util");
var FreeCourseEnrollmentStatus;
(function (FreeCourseEnrollmentStatus) {
    FreeCourseEnrollmentStatus["ACTIVE"] = "active";
    FreeCourseEnrollmentStatus["COMPLETED"] = "completed";
    FreeCourseEnrollmentStatus["DROPPED"] = "dropped";
})(FreeCourseEnrollmentStatus || (exports.FreeCourseEnrollmentStatus = FreeCourseEnrollmentStatus = {}));
let FreeCourseEnrollment = class FreeCourseEnrollment {
};
exports.FreeCourseEnrollment = FreeCourseEnrollment;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], FreeCourseEnrollment.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, required: true, index: true }),
    __metadata("design:type", String)
], FreeCourseEnrollment.prototype, "studentId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, required: true, index: true }),
    __metadata("design:type", String)
], FreeCourseEnrollment.prototype, "courseId", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: String,
        enum: FreeCourseEnrollmentStatus,
        default: FreeCourseEnrollmentStatus.ACTIVE,
    }),
    __metadata("design:type", String)
], FreeCourseEnrollment.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Number, default: 0, min: 0, max: 100 }),
    __metadata("design:type", Number)
], FreeCourseEnrollment.prototype, "progress", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [String], default: [] }),
    __metadata("design:type", Array)
], FreeCourseEnrollment.prototype, "completedChapters", void 0);
__decorate([
    (0, mongoose_1.Prop)({
        type: Map,
        of: {
            completed: { type: Boolean, default: false },
            watchTime: { type: Number, default: 0 },
            lastPosition: { type: Number, default: 0 },
            completedAt: { type: Date, default: null },
        },
        default: {},
    }),
    __metadata("design:type", Map)
], FreeCourseEnrollment.prototype, "chapterProgress", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: null }),
    __metadata("design:type", String)
], FreeCourseEnrollment.prototype, "currentChapterId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: () => new Date() }),
    __metadata("design:type", Date)
], FreeCourseEnrollment.prototype, "enrolledAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], FreeCourseEnrollment.prototype, "assignedByAdminId", void 0);
exports.FreeCourseEnrollment = FreeCourseEnrollment = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'free_course_enrollments',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                return ret;
            },
        },
        toObject: {
            virtuals: true,
            versionKey: false,
        },
    })
], FreeCourseEnrollment);
exports.FreeCourseEnrollmentSchema = mongoose_1.SchemaFactory.createForClass(FreeCourseEnrollment);
exports.FreeCourseEnrollmentSchema.index({ studentId: 1, courseId: 1 }, { unique: true });
//# sourceMappingURL=free-course-enrollment.entity.js.map