"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCourseTrainerSchema = exports.FreeCourseTrainer = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const uuid_util_1 = require("../../../common/utils/uuid.util");
let FreeCourseTrainer = class FreeCourseTrainer {
};
exports.FreeCourseTrainer = FreeCourseTrainer;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, sparse: true, default: null }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "username", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: null }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "adminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "email", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "phone", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: 'Lead Trainer' }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "designation", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "avatar", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: '' }),
    __metadata("design:type", String)
], FreeCourseTrainer.prototype, "bio", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [String], default: [] }),
    __metadata("design:type", Array)
], FreeCourseTrainer.prototype, "expertise", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Boolean, default: true }),
    __metadata("design:type", Boolean)
], FreeCourseTrainer.prototype, "isActive", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Number, default: 0 }),
    __metadata("design:type", Number)
], FreeCourseTrainer.prototype, "order", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], FreeCourseTrainer.prototype, "deletedAt", void 0);
exports.FreeCourseTrainer = FreeCourseTrainer = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'free_course_trainers',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                return ret;
            },
        },
        toObject: {
            virtuals: true,
            versionKey: false,
        },
    })
], FreeCourseTrainer);
exports.FreeCourseTrainerSchema = mongoose_1.SchemaFactory.createForClass(FreeCourseTrainer);
exports.FreeCourseTrainerSchema.index({ name: 'text', designation: 'text' });
exports.FreeCourseTrainerSchema.index({ isActive: 1, deletedAt: 1 });
//# sourceMappingURL=free-course-trainer.entity.js.map