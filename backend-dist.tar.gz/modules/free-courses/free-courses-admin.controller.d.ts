import { Admin } from "../admins/entities/admin.entity";
import { FreeCoursesAdminService } from './free-courses-admin.service';
import { FreeCourseStorageService } from './storage/free-course-storage.service';
import { CreateFreeCourseDto, UpdateFreeCourseDto } from './dto/create-free-course.dto';
import { QueryFreeCourseDto } from './dto/query-free-course.dto';
import { CreateFreeStudentDto, QueryFreeStudentDto, UpdateFreeStudentDto, AssignFreeCoursesDto, ResetFreeStudentPasswordDto } from './dto/free-student.dto';
import { PresignFreeCourseUploadDto, CompleteFreeCourseMultipartDto, AbortFreeCourseMultipartDto } from './dto/free-upload.dto';
import { CreateFreeTrainerDto, UpdateFreeTrainerDto, ResetTrainerCredentialsDto, UpdateTrainerStatusDto } from './dto/create-free-trainer.dto';
import { FreeCourseStatus } from './entities/free-course.entity';
import { UserStatus } from "../../shared/enums/role.enum";
export declare class FreeCoursesAdminController {
    private readonly adminService;
    private readonly storageService;
    constructor(adminService: FreeCoursesAdminService, storageService: FreeCourseStorageService);
    findAll(query: QueryFreeCourseDto): Promise<{
        data: import("./entities/free-course.entity").FreeCourse[];
        total: number;
        page: number;
        limit: number;
    }>;
    getStats(): Promise<{
        total: number;
        active: number;
        published: number;
        draft: number;
        archived: number;
        totalStudents: number;
        categories: number;
        trainers: number;
    }>;
    findAllTrainers(): Promise<any[]>;
    findTrainerById(trainerId: string): Promise<import("mongoose").Document<unknown, {}, import("./entities/free-course-trainer.entity").FreeCourseTrainer, {}, import("mongoose").DefaultSchemaOptions> & import("./entities/free-course-trainer.entity").FreeCourseTrainer & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createTrainer(dto: CreateFreeTrainerDto): Promise<any>;
    updateTrainer(trainerId: string, dto: UpdateFreeTrainerDto): Promise<any>;
    resetTrainerCredentials(trainerId: string, dto: ResetTrainerCredentialsDto): Promise<{
        success: boolean;
        message: string;
    }>;
    updateTrainerStatus(trainerId: string, dto: UpdateTrainerStatusDto): Promise<{
        success: boolean;
        message: string;
    }>;
    deleteTrainer(trainerId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    terminateTrainerSession(trainerId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    findAllStudents(query: QueryFreeStudentDto): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
    }>;
    createStudent(dto: CreateFreeStudentDto, admin: Admin): Promise<{
        student: any;
        assignedCourses: string[];
        credentials: {
            email: string;
            temporaryPassword?: string;
        };
    }>;
    findStudentById(studentId: string): Promise<any>;
    updateStudent(studentId: string, dto: UpdateFreeStudentDto): Promise<any>;
    updateStudentStatus(studentId: string, status: UserStatus): Promise<{
        success: boolean;
        message: string;
    }>;
    resetStudentPassword(studentId: string, dto: ResetFreeStudentPasswordDto): Promise<{
        success: boolean;
        message: string;
    }>;
    assignCoursesToStudent(studentId: string, dto: AssignFreeCoursesDto, admin: Admin): Promise<{
        success: boolean;
        message: string;
    }>;
    unassignCourseFromStudent(studentId: string, courseId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    findOne(id: string): Promise<import("mongoose").Document<unknown, {}, import("./entities/free-course.entity").FreeCourse, {}, import("mongoose").DefaultSchemaOptions> & import("./entities/free-course.entity").FreeCourse & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    create(dto: CreateFreeCourseDto, admin: Admin): Promise<import("./entities/free-course.entity").FreeCourse>;
    update(id: string, dto: UpdateFreeCourseDto, admin: Admin): Promise<import("./entities/free-course.entity").FreeCourse>;
    updateStatus(id: string, status: FreeCourseStatus, admin: Admin): Promise<{
        success: boolean;
        message: string;
    }>;
    remove(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getCourseStudents(id: string): Promise<any[]>;
    presignUpload(dto: PresignFreeCourseUploadDto): Promise<{
        uploadUrl: string;
        publicUrl: string;
        key: string;
        expiresIn: number;
    }>;
    initMultipart(dto: PresignFreeCourseUploadDto): Promise<{
        key: string;
        uploadId: string;
        publicUrl: string;
        expiresIn: number;
    }>;
    getPartUrl(uploadId: string, partNumber: number, key: string): Promise<{
        uploadUrl: string;
        partNumber: number;
    }>;
    completeMultipart(dto: CompleteFreeCourseMultipartDto): Promise<{
        success: boolean;
        publicUrl: string;
        key: string;
    }>;
    abortMultipart(dto: AbortFreeCourseMultipartDto): Promise<{
        success: boolean;
    }>;
}
