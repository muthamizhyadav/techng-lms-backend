"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCoursesStudentController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const user_entity_1 = require("../users/entities/user.entity");
const free_courses_student_service_1 = require("./free-courses-student.service");
const free_progress_dto_1 = require("./dto/free-progress.dto");
let FreeCoursesStudentController = class FreeCoursesStudentController {
    constructor(studentService) {
        this.studentService = studentService;
    }
    async getMyCourses(user) {
        return this.studentService.getMyCourses(user.id);
    }
    async getAvailableCourses(user) {
        return this.studentService.getAvailableCourses(user.id);
    }
    async getCourseDetails(user, courseId) {
        return this.studentService.getCourseDetails(user.id, courseId);
    }
    async updateProgress(user, courseId, dto) {
        return this.studentService.updateProgress(user.id, courseId, dto);
    }
    async completeChapter(user, courseId, chapterId) {
        return this.studentService.completeChapter(user.id, courseId, chapterId);
    }
};
exports.FreeCoursesStudentController = FreeCoursesStudentController;
__decorate([
    (0, common_1.Get)('my-courses'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all enrolled free courses with progress for logged-in student' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User]),
    __metadata("design:returntype", Promise)
], FreeCoursesStudentController.prototype, "getMyCourses", null);
__decorate([
    (0, common_1.Get)('available'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all available public free courses' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User]),
    __metadata("design:returntype", Promise)
], FreeCoursesStudentController.prototype, "getAvailableCourses", null);
__decorate([
    (0, common_1.Get)('courses/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get free course details, curriculum, and player progress' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String]),
    __metadata("design:returntype", Promise)
], FreeCoursesStudentController.prototype, "getCourseDetails", null);
__decorate([
    (0, common_1.Patch)('courses/:id/progress'),
    (0, swagger_1.ApiOperation)({ summary: 'Update playback progress for a chapter in a free course' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String, free_progress_dto_1.UpdateFreeProgressDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesStudentController.prototype, "updateProgress", null);
__decorate([
    (0, common_1.Post)('courses/:id/chapters/:chapterId/complete'),
    (0, swagger_1.ApiOperation)({ summary: 'Mark a chapter as completed in a free course' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    (0, swagger_1.ApiParam)({ name: 'chapterId' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Param)('chapterId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String, String]),
    __metadata("design:returntype", Promise)
], FreeCoursesStudentController.prototype, "completeChapter", null);
exports.FreeCoursesStudentController = FreeCoursesStudentController = __decorate([
    (0, swagger_1.ApiTags)('🎓 Free Courses (Student)'),
    (0, common_1.Controller)('free-courses/student'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    __metadata("design:paramtypes", [free_courses_student_service_1.FreeCoursesStudentService])
], FreeCoursesStudentController);
//# sourceMappingURL=free-courses-student.controller.js.map