export declare class FreeCoursesModule {
}
