import { FreeCourseStatus } from '../entities/free-course.entity';
export declare class FreeCourseAttachmentDto {
    id?: string;
    _id?: string;
    title: string;
    fileUrl: string;
    fileType?: string;
    fileSize?: number;
}
export declare class FreeCourseChapterDto {
    id?: string;
    _id?: string;
    title: string;
    description?: string;
    videoUrl?: string;
    videoThumbnail?: string | null;
    duration?: number;
    videoDuration?: string;
    order: number;
    type?: 'video' | 'quiz' | 'document';
    documentUrl?: string;
    trainerName?: string;
    uploadDate?: string;
    attachments?: FreeCourseAttachmentDto[];
}
export declare class FreeCourseModuleDto {
    id?: string;
    _id?: string;
    title: string;
    order: number;
    thumbnail?: string | null;
    chapters: FreeCourseChapterDto[];
}
export declare class CreateFreeCourseDto {
    title: string;
    description?: string;
    instructor?: string;
    trainerId?: string;
    trainerName?: string;
    trainerDesignation?: string;
    trainerAvatar?: string;
    trainerBio?: string;
    promotionalVideoUrl?: string;
    promotionalVideoDuration?: string;
    category: string;
    status?: FreeCourseStatus;
    level?: string;
    duration?: string;
    videoDuration?: string;
    skills?: string[];
    thumbnail?: string | null;
    banner?: string | null;
    attachments?: FreeCourseAttachmentDto[];
    modules?: FreeCourseModuleDto[];
    id?: string;
    _id?: string;
    createdAt?: any;
    updatedAt?: any;
    __v?: any;
}
declare const UpdateFreeCourseDto_base: import("@nestjs/common").Type<Partial<CreateFreeCourseDto>>;
export declare class UpdateFreeCourseDto extends UpdateFreeCourseDto_base {
}
export {};
