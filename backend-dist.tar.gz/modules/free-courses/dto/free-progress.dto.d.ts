export declare class UpdateFreeProgressDto {
    chapterId: string;
    watchTime: number;
    lastPosition: number;
}
