import { FreeCourseStatus } from '../entities/free-course.entity';
export declare class QueryFreeCourseDto {
    page?: number;
    limit?: number;
    status?: FreeCourseStatus;
    category?: string;
    trainerId?: string;
    trainerName?: string;
    search?: string;
}
