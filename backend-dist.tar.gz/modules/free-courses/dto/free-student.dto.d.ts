import { UserStatus } from "../../../shared/enums/role.enum";
export declare class CreateFreeStudentDto {
    firstName: string;
    lastName?: string;
    email: string;
    password: string;
    phone?: string;
    courseIds?: string[];
}
export declare class AssignFreeCoursesDto {
    courseIds: string[];
}
export declare class ResetFreeStudentPasswordDto {
    newPassword: string;
}
export declare class UpdateFreeStudentDto {
    firstName?: string;
    lastName?: string;
    phone?: string;
    status?: UserStatus;
}
export declare class QueryFreeStudentDto {
    page?: number;
    limit?: number;
    status?: UserStatus;
    courseId?: string;
    search?: string;
}
