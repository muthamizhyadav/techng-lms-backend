export declare class CreateFreeTrainerDto {
    name: string;
    username?: string;
    password?: string;
    email?: string;
    phone?: string;
    designation?: string;
    avatar?: string;
    bio?: string;
    expertise?: string[];
    isActive?: boolean;
    order?: number;
}
export declare class UpdateFreeTrainerDto {
    name?: string;
    username?: string;
    email?: string;
    phone?: string;
    designation?: string;
    avatar?: string;
    bio?: string;
    expertise?: string[];
    isActive?: boolean;
    order?: number;
}
export declare class ResetTrainerCredentialsDto {
    username?: string;
    password?: string;
}
export declare class UpdateTrainerStatusDto {
    isActive: boolean;
}
