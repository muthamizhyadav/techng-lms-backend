"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbortFreeCourseMultipartDto = exports.CompleteFreeCourseMultipartDto = exports.UploadedPartDto = exports.PresignFreeCourseUploadDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
class PresignFreeCourseUploadDto {
}
exports.PresignFreeCourseUploadDto = PresignFreeCourseUploadDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        enum: ['thumbnail', 'banner', 'video', 'document', 'attachment'],
        description: 'Purpose of upload in free courses',
    }),
    (0, class_validator_1.IsEnum)(['thumbnail', 'banner', 'video', 'document', 'attachment']),
    __metadata("design:type", String)
], PresignFreeCourseUploadDto.prototype, "purpose", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'intro-video.mp4' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PresignFreeCourseUploadDto.prototype, "fileName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'video/mp4' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PresignFreeCourseUploadDto.prototype, "contentType", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 10485760 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], PresignFreeCourseUploadDto.prototype, "fileSize", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Free course ID for scoped directory' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PresignFreeCourseUploadDto.prototype, "courseId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ description: 'Module ID for scoped video directory' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PresignFreeCourseUploadDto.prototype, "moduleId", void 0);
class UploadedPartDto {
}
exports.UploadedPartDto = UploadedPartDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1 }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UploadedPartDto.prototype, "partNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: '"etag-string"' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UploadedPartDto.prototype, "eTag", void 0);
class CompleteFreeCourseMultipartDto {
}
exports.CompleteFreeCourseMultipartDto = CompleteFreeCourseMultipartDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'S3 object key' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CompleteFreeCourseMultipartDto.prototype, "key", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Multipart upload ID' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CompleteFreeCourseMultipartDto.prototype, "uploadId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [UploadedPartDto] }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => UploadedPartDto),
    __metadata("design:type", Array)
], CompleteFreeCourseMultipartDto.prototype, "parts", void 0);
class AbortFreeCourseMultipartDto {
}
exports.AbortFreeCourseMultipartDto = AbortFreeCourseMultipartDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'S3 object key' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AbortFreeCourseMultipartDto.prototype, "key", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Multipart upload ID' }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AbortFreeCourseMultipartDto.prototype, "uploadId", void 0);
//# sourceMappingURL=free-upload.dto.js.map