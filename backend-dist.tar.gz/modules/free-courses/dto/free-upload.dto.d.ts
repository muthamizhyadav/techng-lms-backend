import { FreeCourseUploadPurpose } from '../storage/free-course-storage.service';
export declare class PresignFreeCourseUploadDto {
    purpose: FreeCourseUploadPurpose;
    fileName: string;
    contentType: string;
    fileSize?: number;
    courseId?: string;
    moduleId?: string;
}
export declare class UploadedPartDto {
    partNumber: number;
    eTag: string;
}
export declare class CompleteFreeCourseMultipartDto {
    key: string;
    uploadId: string;
    parts: UploadedPartDto[];
}
export declare class AbortFreeCourseMultipartDto {
    key: string;
    uploadId: string;
}
