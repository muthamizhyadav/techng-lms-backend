"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var FreeCourseStorageService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCourseStorageService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const uuid_util_1 = require("../../../common/utils/uuid.util");
const ALLOWED_MIME_TYPES = {
    thumbnail: [
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/svg+xml',
        'image/gif',
    ],
    banner: [
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/svg+xml',
        'image/gif',
    ],
    video: [
        'video/mp4',
        'video/webm',
        'video/ogg',
        'video/quicktime',
        'video/x-matroska',
        'video/x-msvideo',
    ],
    document: [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'application/zip',
        'application/x-zip-compressed',
    ],
    attachment: [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'application/zip',
        'application/x-zip-compressed',
        'image/jpeg',
        'image/png',
        'image/webp',
    ],
};
let FreeCourseStorageService = FreeCourseStorageService_1 = class FreeCourseStorageService {
    constructor(configService) {
        this.configService = configService;
        this.logger = new common_1.Logger(FreeCourseStorageService_1.name);
        const endpoint = this.configService.get('storage.endpoint');
        const accessKeyId = this.configService.get('storage.accessKeyId');
        const secretAccessKey = this.configService.get('storage.secretAccessKey');
        const region = this.configService.get('storage.region') || 'auto';
        if (!endpoint || !accessKeyId || !secretAccessKey) {
            this.logger.warn('Storage is not fully configured. Using fallback client configuration.');
        }
        this.client = new client_s3_1.S3Client({
            region,
            endpoint: endpoint || undefined,
            forcePathStyle: true,
            credentials: accessKeyId && secretAccessKey
                ? {
                    accessKeyId,
                    secretAccessKey,
                }
                : undefined,
        });
        this.bucketName =
            this.configService.get('storage.bucketName') || 'techng-lms';
        this.publicBaseUrl = (this.configService.get('storage.publicBaseUrl') || '').replace(/\/+$/, '');
        this.defaultExpiresIn =
            this.configService.get('storage.uploadExpiresIn') || 900;
        this.maxVideoSizeMb =
            this.configService.get('storage.maxVideoSizeMb') || 4096;
        this.maxImageSizeMb =
            this.configService.get('storage.maxThumbnailSizeMb') || 15;
        this.maxDocumentSizeMb = 100;
    }
    encodePathSegment(segment) {
        return encodeURIComponent(segment);
    }
    validateFile(purpose, contentType, fileSize) {
        const allowed = ALLOWED_MIME_TYPES[purpose];
        if (allowed && !allowed.includes(contentType.toLowerCase())) {
            throw new common_1.BadRequestException(`Invalid content type "${contentType}" for purpose "${purpose}". Allowed types: ${allowed.join(', ')}`);
        }
        if (fileSize !== undefined && fileSize > 0) {
            let maxBytes = 0;
            if (purpose === 'video') {
                maxBytes = this.maxVideoSizeMb * 1024 * 1024;
            }
            else if (purpose === 'thumbnail' || purpose === 'banner') {
                maxBytes = this.maxImageSizeMb * 1024 * 1024;
            }
            else {
                maxBytes = this.maxDocumentSizeMb * 1024 * 1024;
            }
            if (fileSize > maxBytes) {
                throw new common_1.BadRequestException(`File size exceeds maximum allowed size (${Math.round(maxBytes / (1024 * 1024))} MB) for ${purpose}`);
            }
        }
    }
    buildKey(purpose, originalName, courseId, moduleId) {
        const extMatch = /\.([a-zA-Z0-9]+)$/.exec(originalName || '');
        const ext = extMatch ? extMatch[1].toLowerCase() : 'bin';
        const safeBase = (originalName || 'file')
            .replace(/\.[a-zA-Z0-9]+$/, '')
            .replace(/[^a-zA-Z0-9-_]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 80) || 'file';
        const safeCourseId = courseId
            ? courseId.replace(/[^a-zA-Z0-9-_]/g, '')
            : 'general';
        const safeModuleId = moduleId
            ? moduleId.replace(/[^a-zA-Z0-9-_]/g, '')
            : 'general';
        const uniqueFileName = `${(0, uuid_util_1.generateUuid)()}-${safeBase}.${ext}`;
        switch (purpose) {
            case 'thumbnail':
                return `free-courses/thumbnails/${uniqueFileName}`;
            case 'banner':
                return `free-courses/banners/${uniqueFileName}`;
            case 'video':
                return `free-courses/videos/${safeCourseId}/${safeModuleId}/${uniqueFileName}`;
            case 'document':
                return `free-courses/documents/${safeCourseId}/${uniqueFileName}`;
            case 'attachment':
                return `free-courses/attachments/${safeCourseId}/${uniqueFileName}`;
            default:
                return `free-courses/attachments/${safeCourseId}/${uniqueFileName}`;
        }
    }
    getPublicUrl(key) {
        if (this.publicBaseUrl &&
            this.publicBaseUrl.startsWith('http') &&
            !this.publicBaseUrl.includes('<HASH>')) {
            const encodedKey = key
                .split('/')
                .map((segment) => this.encodePathSegment(segment))
                .join('/');
            return `${this.publicBaseUrl}/${encodedKey}`;
        }
        return `/api/v1/uploads/stream?key=${encodeURIComponent(key)}`;
    }
    async getSignedGetUrl(key, expiresIn = 86400) {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: this.bucketName,
            Key: key,
        });
        return (0, s3_request_presigner_1.getSignedUrl)(this.client, command, { expiresIn });
    }
    async getObjectStream(key, range) {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: this.bucketName,
            Key: key,
            Range: range,
        });
        const response = await this.client.send(command);
        return {
            stream: response.Body,
            contentLength: response.ContentLength,
            contentRange: response.ContentRange,
            contentType: response.ContentType || 'video/mp4',
            acceptRanges: response.AcceptRanges || 'bytes',
            statusCode: range ? 206 : 200,
        };
    }
    async getPresignedPutUrl(key, contentType, expiresIn = this.defaultExpiresIn) {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: this.bucketName,
            Key: key,
            ContentType: contentType,
        });
        return (0, s3_request_presigner_1.getSignedUrl)(this.client, command, { expiresIn });
    }
    async createMultipartUpload(key, contentType) {
        const command = new client_s3_1.CreateMultipartUploadCommand({
            Bucket: this.bucketName,
            Key: key,
            ContentType: contentType,
        });
        const result = await this.client.send(command);
        return { uploadId: result.UploadId };
    }
    async getPresignedPartUrl(key, uploadId, partNumber, expiresIn = this.defaultExpiresIn) {
        const command = new client_s3_1.UploadPartCommand({
            Bucket: this.bucketName,
            Key: key,
            UploadId: uploadId,
            PartNumber: partNumber,
        });
        return (0, s3_request_presigner_1.getSignedUrl)(this.client, command, { expiresIn });
    }
    async completeMultipartUpload(key, uploadId, parts) {
        const command = new client_s3_1.CompleteMultipartUploadCommand({
            Bucket: this.bucketName,
            Key: key,
            UploadId: uploadId,
            MultipartUpload: {
                Parts: parts.map((part) => ({
                    PartNumber: part.partNumber,
                    ETag: part.eTag,
                })),
            },
        });
        await this.client.send(command);
    }
    async abortMultipartUpload(key, uploadId) {
        const command = new client_s3_1.AbortMultipartUploadCommand({
            Bucket: this.bucketName,
            Key: key,
            UploadId: uploadId,
        });
        await this.client.send(command).catch((err) => {
            this.logger.warn(`Failed to abort multipart upload "${uploadId}": ${err?.message}`);
        });
    }
    async deleteObject(key) {
        const command = new client_s3_1.DeleteObjectCommand({
            Bucket: this.bucketName,
            Key: key,
        });
        await this.client.send(command).catch((err) => {
            this.logger.warn(`Failed to delete object "${key}": ${err?.message}`);
        });
    }
};
exports.FreeCourseStorageService = FreeCourseStorageService;
exports.FreeCourseStorageService = FreeCourseStorageService = FreeCourseStorageService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], FreeCourseStorageService);
//# sourceMappingURL=free-course-storage.service.js.map