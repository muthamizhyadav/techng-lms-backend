import { ConfigService } from '@nestjs/config';
export type FreeCourseUploadPurpose = 'thumbnail' | 'banner' | 'video' | 'document' | 'attachment';
export interface UploadedPart {
    partNumber: number;
    eTag: string;
}
export interface PresignFreeCourseUploadParams {
    purpose: FreeCourseUploadPurpose;
    fileName: string;
    contentType: string;
    fileSize?: number;
    courseId?: string;
    moduleId?: string;
}
export declare class FreeCourseStorageService {
    private readonly configService;
    private readonly logger;
    private readonly client;
    private readonly bucketName;
    private readonly publicBaseUrl;
    private readonly defaultExpiresIn;
    private readonly maxVideoSizeMb;
    private readonly maxImageSizeMb;
    private readonly maxDocumentSizeMb;
    constructor(configService: ConfigService);
    private encodePathSegment;
    validateFile(purpose: FreeCourseUploadPurpose, contentType: string, fileSize?: number): void;
    buildKey(purpose: FreeCourseUploadPurpose, originalName: string, courseId?: string, moduleId?: string): string;
    getPublicUrl(key: string): string;
    getSignedGetUrl(key: string, expiresIn?: number): Promise<string>;
    getObjectStream(key: string, range?: string): Promise<{
        stream: NodeJS.ReadableStream;
        contentLength?: number;
        contentRange?: string;
        contentType?: string;
        acceptRanges?: string;
        statusCode: number;
    }>;
    getPresignedPutUrl(key: string, contentType: string, expiresIn?: number): Promise<string>;
    createMultipartUpload(key: string, contentType: string): Promise<{
        uploadId: string;
    }>;
    getPresignedPartUrl(key: string, uploadId: string, partNumber: number, expiresIn?: number): Promise<string>;
    completeMultipartUpload(key: string, uploadId: string, parts: UploadedPart[]): Promise<void>;
    abortMultipartUpload(key: string, uploadId: string): Promise<void>;
    deleteObject(key: string): Promise<void>;
}
