import { Model } from 'mongoose';
import { FreeCourseDocument } from './entities/free-course.entity';
import { FreeCourseEnrollmentDocument } from './entities/free-course-enrollment.entity';
import { UpdateFreeProgressDto } from './dto/free-progress.dto';
export declare class FreeCoursesStudentService {
    private readonly freeCourseModel;
    private readonly freeCourseEnrollmentModel;
    constructor(freeCourseModel: Model<FreeCourseDocument>, freeCourseEnrollmentModel: Model<FreeCourseEnrollmentDocument>);
    getMyCourses(studentId: string): Promise<any[]>;
    getAvailableCourses(studentId: string): Promise<any[]>;
    getCourseDetails(studentId: string, courseId: string): Promise<any>;
    updateProgress(studentId: string, courseId: string, dto: UpdateFreeProgressDto): Promise<any>;
    completeChapter(studentId: string, courseId: string, chapterId: string): Promise<any>;
}
