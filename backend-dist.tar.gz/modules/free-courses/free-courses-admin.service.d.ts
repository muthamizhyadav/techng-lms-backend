import { Model } from 'mongoose';
import { FreeCourse, FreeCourseDocument, FreeCourseStatus } from './entities/free-course.entity';
import { FreeCourseTrainerDocument } from './entities/free-course-trainer.entity';
import { FreeCourseEnrollmentDocument } from './entities/free-course-enrollment.entity';
import { UserDocument } from "../users/entities/user.entity";
import { AdminDocument } from "../admins/entities/admin.entity";
import { UserStatus } from "../../shared/enums/role.enum";
import { CreateFreeCourseDto, UpdateFreeCourseDto } from './dto/create-free-course.dto';
import { QueryFreeCourseDto } from './dto/query-free-course.dto';
import { CreateFreeStudentDto, QueryFreeStudentDto, UpdateFreeStudentDto } from './dto/free-student.dto';
import { CreateFreeTrainerDto, UpdateFreeTrainerDto, ResetTrainerCredentialsDto } from './dto/create-free-trainer.dto';
export declare class FreeCoursesAdminService {
    private readonly freeCourseModel;
    private readonly freeCourseTrainerModel;
    private readonly freeCourseEnrollmentModel;
    private readonly userModel;
    private readonly adminModel;
    constructor(freeCourseModel: Model<FreeCourseDocument>, freeCourseTrainerModel: Model<FreeCourseTrainerDocument>, freeCourseEnrollmentModel: Model<FreeCourseEnrollmentDocument>, userModel: Model<UserDocument>, adminModel: Model<AdminDocument>);
    findAll(query: QueryFreeCourseDto): Promise<{
        data: FreeCourse[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<FreeCourseDocument>;
    create(dto: CreateFreeCourseDto, adminId: string): Promise<FreeCourse>;
    update(id: string, dto: UpdateFreeCourseDto, adminId: string): Promise<FreeCourse>;
    updateStatus(id: string, status: FreeCourseStatus, adminId: string): Promise<void>;
    remove(id: string): Promise<void>;
    getStats(): Promise<{
        total: number;
        active: number;
        published: number;
        draft: number;
        archived: number;
        totalStudents: number;
        categories: number;
        trainers: number;
    }>;
    findAllTrainers(): Promise<any[]>;
    findTrainerById(id: string): Promise<FreeCourseTrainerDocument>;
    createTrainer(dto: CreateFreeTrainerDto): Promise<any>;
    updateTrainer(id: string, dto: UpdateFreeTrainerDto): Promise<any>;
    resetTrainerCredentials(id: string, dto: ResetTrainerCredentialsDto): Promise<{
        success: boolean;
        message: string;
    }>;
    updateTrainerStatus(id: string, isActive: boolean): Promise<{
        success: boolean;
        message: string;
    }>;
    deleteTrainer(id: string): Promise<void>;
    terminateTrainerSession(id: string): Promise<{
        success: boolean;
        message: string;
    }>;
    getCourseStudents(courseId: string): Promise<any[]>;
    createStudent(dto: CreateFreeStudentDto, adminId: string): Promise<{
        student: any;
        assignedCourses: string[];
        credentials: {
            email: string;
            temporaryPassword?: string;
        };
    }>;
    findAllStudents(query: QueryFreeStudentDto): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
    }>;
    findStudentById(studentId: string): Promise<any>;
    updateStudent(studentId: string, dto: UpdateFreeStudentDto): Promise<any>;
    updateStudentStatus(studentId: string, status: UserStatus): Promise<void>;
    resetStudentPassword(studentId: string, newPassword: string): Promise<void>;
    assignCoursesToStudent(studentId: string, courseIds: string[], adminId: string): Promise<void>;
    unassignCourseFromStudent(studentId: string, courseId: string): Promise<void>;
}
