"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FreeCoursesAdminController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const current_admin_decorator_1 = require("../../common/decorators/current-admin.decorator");
const admin_entity_1 = require("../admins/entities/admin.entity");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const free_courses_admin_service_1 = require("./free-courses-admin.service");
const free_course_storage_service_1 = require("./storage/free-course-storage.service");
const create_free_course_dto_1 = require("./dto/create-free-course.dto");
const query_free_course_dto_1 = require("./dto/query-free-course.dto");
const free_student_dto_1 = require("./dto/free-student.dto");
const free_upload_dto_1 = require("./dto/free-upload.dto");
const create_free_trainer_dto_1 = require("./dto/create-free-trainer.dto");
const free_course_entity_1 = require("./entities/free-course.entity");
const role_enum_1 = require("../../shared/enums/role.enum");
let FreeCoursesAdminController = class FreeCoursesAdminController {
    constructor(adminService, storageService) {
        this.adminService = adminService;
        this.storageService = storageService;
    }
    async findAll(query) {
        return this.adminService.findAll(query);
    }
    async getStats() {
        return this.adminService.getStats();
    }
    async findAllTrainers() {
        return this.adminService.findAllTrainers();
    }
    async findTrainerById(trainerId) {
        return this.adminService.findTrainerById(trainerId);
    }
    async createTrainer(dto) {
        return this.adminService.createTrainer(dto);
    }
    async updateTrainer(trainerId, dto) {
        return this.adminService.updateTrainer(trainerId, dto);
    }
    async resetTrainerCredentials(trainerId, dto) {
        return this.adminService.resetTrainerCredentials(trainerId, dto);
    }
    async updateTrainerStatus(trainerId, dto) {
        return this.adminService.updateTrainerStatus(trainerId, dto.isActive);
    }
    async deleteTrainer(trainerId) {
        await this.adminService.deleteTrainer(trainerId);
        return { success: true, message: 'Trainer deleted successfully' };
    }
    async terminateTrainerSession(trainerId) {
        return this.adminService.terminateTrainerSession(trainerId);
    }
    async findAllStudents(query) {
        return this.adminService.findAllStudents(query);
    }
    async createStudent(dto, admin) {
        return this.adminService.createStudent(dto, admin?.id || 'admin');
    }
    async findStudentById(studentId) {
        return this.adminService.findStudentById(studentId);
    }
    async updateStudent(studentId, dto) {
        return this.adminService.updateStudent(studentId, dto);
    }
    async updateStudentStatus(studentId, status) {
        await this.adminService.updateStudentStatus(studentId, status);
        return { success: true, message: `Student status updated to ${status}` };
    }
    async resetStudentPassword(studentId, dto) {
        await this.adminService.resetStudentPassword(studentId, dto.newPassword);
        return { success: true, message: 'Password reset successfully' };
    }
    async assignCoursesToStudent(studentId, dto, admin) {
        await this.adminService.assignCoursesToStudent(studentId, dto.courseIds, admin?.id || 'admin');
        return { success: true, message: 'Courses assigned successfully' };
    }
    async unassignCourseFromStudent(studentId, courseId) {
        await this.adminService.unassignCourseFromStudent(studentId, courseId);
        return { success: true, message: 'Course unassigned successfully' };
    }
    async findOne(id) {
        return this.adminService.findOne(id);
    }
    async create(dto, admin) {
        if (admin?.role === user_status_enum_1.AdminRole.TRAINER) {
            if (!dto.trainerId && admin.trainerProfileId) {
                dto.trainerId = admin.trainerProfileId;
            }
            if (!dto.trainerName) {
                dto.trainerName = admin.fullName || `${admin.firstName} ${admin.lastName || ''}`.trim();
            }
        }
        return this.adminService.create(dto, admin?.id || 'admin');
    }
    async update(id, dto, admin) {
        return this.adminService.update(id, dto, admin?.id || 'admin');
    }
    async updateStatus(id, status, admin) {
        await this.adminService.updateStatus(id, status, admin?.id || 'admin');
        return { success: true, message: `Course status updated to ${status}` };
    }
    async remove(id) {
        await this.adminService.remove(id);
        return { success: true, message: 'Course deleted successfully' };
    }
    async getCourseStudents(id) {
        return this.adminService.getCourseStudents(id);
    }
    async presignUpload(dto) {
        this.storageService.validateFile(dto.purpose, dto.contentType, dto.fileSize);
        const key = this.storageService.buildKey(dto.purpose, dto.fileName, dto.courseId, dto.moduleId);
        const uploadUrl = await this.storageService.getPresignedPutUrl(key, dto.contentType);
        const publicUrl = this.storageService.getPublicUrl(key);
        return {
            uploadUrl,
            publicUrl,
            key,
            expiresIn: 900,
        };
    }
    async initMultipart(dto) {
        this.storageService.validateFile(dto.purpose, dto.contentType, dto.fileSize);
        const key = this.storageService.buildKey(dto.purpose, dto.fileName, dto.courseId, dto.moduleId);
        const { uploadId } = await this.storageService.createMultipartUpload(key, dto.contentType);
        const publicUrl = this.storageService.getPublicUrl(key);
        return {
            key,
            uploadId,
            publicUrl,
            expiresIn: 900,
        };
    }
    async getPartUrl(uploadId, partNumber, key) {
        const uploadUrl = await this.storageService.getPresignedPartUrl(key, uploadId, partNumber);
        return { uploadUrl, partNumber };
    }
    async completeMultipart(dto) {
        await this.storageService.completeMultipartUpload(dto.key, dto.uploadId, dto.parts);
        return {
            success: true,
            publicUrl: this.storageService.getPublicUrl(dto.key),
            key: dto.key,
        };
    }
    async abortMultipart(dto) {
        await this.storageService.abortMultipartUpload(dto.key, dto.uploadId);
        return { success: true };
    }
};
exports.FreeCoursesAdminController = FreeCoursesAdminController;
__decorate([
    (0, common_1.Get)(),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'List all free courses with filtering & pagination' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [query_free_course_dto_1.QueryFreeCourseDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Get summary stats for free courses and students' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('trainers'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'List all active free course trainers' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "findAllTrainers", null);
__decorate([
    (0, common_1.Get)('trainers/:trainerId'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Get trainer details by ID' }),
    (0, swagger_1.ApiParam)({ name: 'trainerId' }),
    __param(0, (0, common_1.Param)('trainerId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "findTrainerById", null);
__decorate([
    (0, common_1.Post)('trainers'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new trainer profile and login account' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_free_trainer_dto_1.CreateFreeTrainerDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "createTrainer", null);
__decorate([
    (0, common_1.Put)('trainers/:trainerId'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Update an existing trainer profile' }),
    (0, swagger_1.ApiParam)({ name: 'trainerId' }),
    __param(0, (0, common_1.Param)('trainerId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_free_trainer_dto_1.UpdateFreeTrainerDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "updateTrainer", null);
__decorate([
    (0, common_1.Patch)('trainers/:trainerId/credentials'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Update or reset trainer login credentials (username / password)' }),
    (0, swagger_1.ApiParam)({ name: 'trainerId' }),
    __param(0, (0, common_1.Param)('trainerId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_free_trainer_dto_1.ResetTrainerCredentialsDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "resetTrainerCredentials", null);
__decorate([
    (0, common_1.Patch)('trainers/:trainerId/status'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Activate or deactivate trainer account' }),
    (0, swagger_1.ApiParam)({ name: 'trainerId' }),
    __param(0, (0, common_1.Param)('trainerId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_free_trainer_dto_1.UpdateTrainerStatusDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "updateTrainerStatus", null);
__decorate([
    (0, common_1.Delete)('trainers/:trainerId'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a trainer profile and deactivate account' }),
    (0, swagger_1.ApiParam)({ name: 'trainerId' }),
    __param(0, (0, common_1.Param)('trainerId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "deleteTrainer", null);
__decorate([
    (0, common_1.Post)('trainers/:trainerId/terminate-session'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Terminate active single-device login session for a trainer' }),
    (0, swagger_1.ApiParam)({ name: 'trainerId' }),
    __param(0, (0, common_1.Param)('trainerId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "terminateTrainerSession", null);
__decorate([
    (0, common_1.Get)('students'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'List all free course students' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [free_student_dto_1.QueryFreeStudentDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "findAllStudents", null);
__decorate([
    (0, common_1.Post)('students'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Create a student login account for free courses' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [free_student_dto_1.CreateFreeStudentDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "createStudent", null);
__decorate([
    (0, common_1.Get)('students/:studentId'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Get free course student details and course progress' }),
    (0, swagger_1.ApiParam)({ name: 'studentId' }),
    __param(0, (0, common_1.Param)('studentId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "findStudentById", null);
__decorate([
    (0, common_1.Patch)('students/:studentId'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Update free course student details' }),
    (0, swagger_1.ApiParam)({ name: 'studentId' }),
    __param(0, (0, common_1.Param)('studentId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, free_student_dto_1.UpdateFreeStudentDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "updateStudent", null);
__decorate([
    (0, common_1.Patch)('students/:studentId/status'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Update free course student status (active/suspended/inactive)' }),
    (0, swagger_1.ApiParam)({ name: 'studentId' }),
    __param(0, (0, common_1.Param)('studentId')),
    __param(1, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "updateStudentStatus", null);
__decorate([
    (0, common_1.Post)('students/:studentId/reset-password'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Reset password for a free course student' }),
    (0, swagger_1.ApiParam)({ name: 'studentId' }),
    __param(0, (0, common_1.Param)('studentId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, free_student_dto_1.ResetFreeStudentPasswordDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "resetStudentPassword", null);
__decorate([
    (0, common_1.Post)('students/:studentId/assign-courses'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Assign free courses to a student' }),
    (0, swagger_1.ApiParam)({ name: 'studentId' }),
    __param(0, (0, common_1.Param)('studentId')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, free_student_dto_1.AssignFreeCoursesDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "assignCoursesToStudent", null);
__decorate([
    (0, common_1.Delete)('students/:studentId/courses/:courseId'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiOperation)({ summary: 'Unassign a free course from a student' }),
    (0, swagger_1.ApiParam)({ name: 'studentId' }),
    (0, swagger_1.ApiParam)({ name: 'courseId' }),
    __param(0, (0, common_1.Param)('studentId')),
    __param(1, (0, common_1.Param)('courseId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "unassignCourseFromStudent", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Get a single free course by ID' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new free course' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_free_course_dto_1.CreateFreeCourseDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Update an existing free course' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, create_free_course_dto_1.UpdateFreeCourseDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Update status of free course (draft, published, active, archived)' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)('status')),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Delete (soft delete) a free course' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)(':id/students'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Get list of students enrolled in this free course with their progress' }),
    (0, swagger_1.ApiParam)({ name: 'id' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "getCourseStudents", null);
__decorate([
    (0, common_1.Post)('uploads/presign'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({
        summary: 'Get S3 presigned PUT URL for free course asset',
        description: 'Stores assets in dedicated free-courses/ folder per requirement: thumbnails, banners, videos, documents, attachments',
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [free_upload_dto_1.PresignFreeCourseUploadDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "presignUpload", null);
__decorate([
    (0, common_1.Post)('uploads/multipart'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({
        summary: 'Initialize multipart upload on S3 for large free course videos',
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [free_upload_dto_1.PresignFreeCourseUploadDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "initMultipart", null);
__decorate([
    (0, common_1.Get)('uploads/multipart/:uploadId/parts/:partNumber/presign'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({
        summary: 'Get presigned URL for a multipart part for free courses',
    }),
    (0, swagger_1.ApiParam)({ name: 'uploadId' }),
    (0, swagger_1.ApiParam)({ name: 'partNumber' }),
    (0, swagger_1.ApiQuery)({ name: 'key' }),
    __param(0, (0, common_1.Param)('uploadId')),
    __param(1, (0, common_1.Param)('partNumber', common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, String]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "getPartUrl", null);
__decorate([
    (0, common_1.Post)('uploads/multipart/complete'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Complete multipart upload for free course video' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [free_upload_dto_1.CompleteFreeCourseMultipartDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "completeMultipart", null);
__decorate([
    (0, common_1.Post)('uploads/multipart/abort'),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.TRAINER),
    (0, swagger_1.ApiOperation)({ summary: 'Abort multipart upload for free course video' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [free_upload_dto_1.AbortFreeCourseMultipartDto]),
    __metadata("design:returntype", Promise)
], FreeCoursesAdminController.prototype, "abortMultipart", null);
exports.FreeCoursesAdminController = FreeCoursesAdminController = __decorate([
    (0, swagger_1.ApiTags)('🎁 Free Courses (Admin)'),
    (0, common_1.Controller)('free-courses/admin'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    __metadata("design:paramtypes", [free_courses_admin_service_1.FreeCoursesAdminService,
        free_course_storage_service_1.FreeCourseStorageService])
], FreeCoursesAdminController);
//# sourceMappingURL=free-courses-admin.controller.js.map