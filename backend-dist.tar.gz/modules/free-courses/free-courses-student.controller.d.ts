import { User } from "../users/entities/user.entity";
import { FreeCoursesStudentService } from './free-courses-student.service';
import { UpdateFreeProgressDto } from './dto/free-progress.dto';
export declare class FreeCoursesStudentController {
    private readonly studentService;
    constructor(studentService: FreeCoursesStudentService);
    getMyCourses(user: User): Promise<any[]>;
    getAvailableCourses(user: User): Promise<any[]>;
    getCourseDetails(user: User, courseId: string): Promise<any>;
    updateProgress(user: User, courseId: string, dto: UpdateFreeProgressDto): Promise<any>;
    completeChapter(user: User, courseId: string, chapterId: string): Promise<any>;
}
