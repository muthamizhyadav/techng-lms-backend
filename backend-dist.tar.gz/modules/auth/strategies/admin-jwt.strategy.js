"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminJwtStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const passport_jwt_1 = require("passport-jwt");
const config_1 = require("@nestjs/config");
const admins_service_1 = require("../../admins/admins.service");
const user_status_enum_1 = require("../../../shared/enums/user-status.enum");
let AdminJwtStrategy = class AdminJwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy, 'admin-jwt') {
    constructor(configService, adminsService) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: configService.get('jwt.admin.secret'),
        });
        this.configService = configService;
        this.adminsService = adminsService;
    }
    async validate(payload) {
        if (payload.type !== 'admin') {
            throw new common_1.UnauthorizedException('Invalid token type for admin access');
        }
        const admin = await this.adminsService.findOne(payload.sub);
        if (!admin.isActive()) {
            throw new common_1.UnauthorizedException('Your admin account has been suspended');
        }
        if (admin.role === user_status_enum_1.AdminRole.TRAINER) {
            if (admin.activeSessionId &&
                payload.sessionId &&
                admin.activeSessionId !== payload.sessionId) {
                throw new common_1.UnauthorizedException('Your trainer session has expired or was terminated because you logged in from another device.');
            }
        }
        return admin;
    }
};
exports.AdminJwtStrategy = AdminJwtStrategy;
exports.AdminJwtStrategy = AdminJwtStrategy = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        admins_service_1.AdminsService])
], AdminJwtStrategy);
//# sourceMappingURL=admin-jwt.strategy.js.map