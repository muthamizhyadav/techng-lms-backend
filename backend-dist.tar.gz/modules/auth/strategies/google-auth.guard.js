"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GoogleAuthGuard = exports.OAUTH_NONCE_COOKIE = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const crypto_1 = require("crypto");
const auth_service_1 = require("../auth.service");
exports.OAUTH_NONCE_COOKIE = 'techng_oauth_nonce';
let GoogleAuthGuard = class GoogleAuthGuard extends (0, passport_1.AuthGuard)('google') {
    constructor(authService) {
        super();
        this.authService = authService;
    }
    getAuthenticateOptions(context) {
        const http = context.switchToHttp();
        const req = http.getRequest();
        const res = http.getResponse();
        const pick = (value) => {
            if (Array.isArray(value)) {
                return typeof value[0] === 'string' ? value[0] : undefined;
            }
            return typeof value === 'string' ? value : undefined;
        };
        const forwardedProto = req.headers['x-forwarded-proto'];
        const isHttps = req.secure ||
            forwardedProto === 'https' ||
            (Array.isArray(forwardedProto) && forwardedProto[0] === 'https');
        const nonce = (0, crypto_1.randomBytes)(24).toString('hex');
        res.cookie(exports.OAUTH_NONCE_COOKIE, nonce, {
            httpOnly: true,
            sameSite: 'lax',
            secure: isHttps,
            maxAge: 10 * 60 * 1000,
            path: '/',
        });
        const state = this.authService.createGoogleOAuthState({
            deviceId: pick(req.query?.deviceId),
            deviceName: pick(req.query?.deviceName),
            platform: pick(req.query?.platform),
        }, nonce);
        return { state };
    }
};
exports.GoogleAuthGuard = GoogleAuthGuard;
exports.GoogleAuthGuard = GoogleAuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], GoogleAuthGuard);
//# sourceMappingURL=google-auth.guard.js.map