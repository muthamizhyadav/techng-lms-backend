import { ExecutionContext } from '@nestjs/common';
import { AuthService } from '../auth.service';
export declare const OAUTH_NONCE_COOKIE = "techng_oauth_nonce";
declare const GoogleAuthGuard_base: import("@nestjs/passport").Type<import("@nestjs/passport").IAuthGuard>;
export declare class GoogleAuthGuard extends GoogleAuthGuard_base {
    private readonly authService;
    constructor(authService: AuthService);
    getAuthenticateOptions(context: ExecutionContext): {
        state: string;
    };
}
export {};
