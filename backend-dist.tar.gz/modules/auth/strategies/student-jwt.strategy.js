"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StudentJwtStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const passport_jwt_1 = require("passport-jwt");
const config_1 = require("@nestjs/config");
const users_service_1 = require("../../users/users.service");
let StudentJwtStrategy = class StudentJwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy, 'student-jwt') {
    constructor(configService, usersService) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: configService.get('jwt.student.secret'),
        });
        this.configService = configService;
        this.usersService = usersService;
    }
    async validate(payload) {
        if (payload.type !== 'student') {
            throw new common_1.UnauthorizedException('Invalid token type for student access');
        }
        if (!payload.sid) {
            throw new common_1.UnauthorizedException('Session expired. Please log in again.');
        }
        const user = await this.usersService.findOne(payload.sub);
        if (!user.isActive()) {
            throw new common_1.UnauthorizedException('Your account has been suspended or deactivated');
        }
        const now = Date.now();
        const session = (user.activeSessions ?? []).find((current) => current.sessionId === payload.sid &&
            current.expiresAt &&
            new Date(current.expiresAt).getTime() > now);
        if (!session) {
            throw new common_1.UnauthorizedException('Your session has ended. Please log in again.');
        }
        user.currentSessionId =
            payload.sid;
        return user;
    }
};
exports.StudentJwtStrategy = StudentJwtStrategy;
exports.StudentJwtStrategy = StudentJwtStrategy = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        users_service_1.UsersService])
], StudentJwtStrategy);
//# sourceMappingURL=student-jwt.strategy.js.map