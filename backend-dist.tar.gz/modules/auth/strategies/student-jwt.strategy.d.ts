import { Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { UsersService } from "../../users/users.service";
import { StudentJwtPayload } from "../../../shared/interfaces/jwt-payload.interface";
import { User } from "../../users/entities/user.entity";
declare const StudentJwtStrategy_base: new (...args: [opt: import("passport-jwt").StrategyOptionsWithRequest] | [opt: import("passport-jwt").StrategyOptionsWithoutRequest]) => Strategy & {
    validate(...args: any[]): unknown;
};
export declare class StudentJwtStrategy extends StudentJwtStrategy_base {
    private readonly configService;
    private readonly usersService;
    constructor(configService: ConfigService, usersService: UsersService);
    validate(payload: StudentJwtPayload): Promise<User>;
}
export {};
