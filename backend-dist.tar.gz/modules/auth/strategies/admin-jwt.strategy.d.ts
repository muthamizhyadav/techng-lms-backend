import { Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { AdminsService } from "../../admins/admins.service";
import { AdminJwtPayload } from "../../../shared/interfaces/jwt-payload.interface";
import { Admin } from "../../admins/entities/admin.entity";
declare const AdminJwtStrategy_base: new (...args: [opt: import("passport-jwt").StrategyOptionsWithRequest] | [opt: import("passport-jwt").StrategyOptionsWithoutRequest]) => Strategy & {
    validate(...args: any[]): unknown;
};
export declare class AdminJwtStrategy extends AdminJwtStrategy_base {
    private readonly configService;
    private readonly adminsService;
    constructor(configService: ConfigService, adminsService: AdminsService);
    validate(payload: AdminJwtPayload): Promise<Admin>;
}
export {};
