"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthAdminController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const auth_service_1 = require("./auth.service");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const current_admin_decorator_1 = require("../../common/decorators/current-admin.decorator");
const admin_entity_1 = require("../admins/entities/admin.entity");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const admin_dto_1 = require("../admins/dto/admin.dto");
const auth_dto_1 = require("./dto/auth.dto");
let AuthAdminController = class AuthAdminController {
    constructor(authService) {
        this.authService = authService;
    }
    async setup(dto) {
        return this.authService.adminRegister(dto, null);
    }
    async register(dto, currentAdmin) {
        return this.authService.adminRegister(dto, currentAdmin?.id);
    }
    async forgotPassword(dto) {
        return this.authService.adminForgotPassword(dto);
    }
    async resetPassword(dto) {
        return this.authService.adminResetPassword(dto);
    }
    async login(dto, ipAddress, userAgent) {
        return this.authService.adminLogin(dto, ipAddress, userAgent);
    }
    async refresh(dto) {
        return this.authService.adminRefresh(dto);
    }
    async logout(adminId) {
        await this.authService.adminLogout(adminId);
        return { message: 'Logged out successfully' };
    }
    async getProfile(admin) {
        return this.authService.getAdminProfile(admin.id);
    }
};
exports.AuthAdminController = AuthAdminController;
__decorate([
    (0, common_1.Post)('setup'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({
        summary: 'First-time Super Admin setup',
        description: 'Creates the first Super Admin without authentication. Only works when zero admins exist. Remove/disable after initial setup.',
    }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.AdminRegisterDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'First Super Admin created successfully',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
                admin: {
                    id: '0f8fad5b-d9cb-469f-a165-70867728950e',
                    email: 'super@techng.in',
                    firstName: 'Super',
                    lastName: 'Admin',
                    role: 'super_admin',
                },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Setup already completed — admins already exist',
    }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_dto_1.AdminRegisterDto]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "setup", null);
__decorate([
    (0, common_1.Post)('register'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Create new admin account (Super Admin only)',
        description: 'Only existing Super Admin can create new admin accounts.',
    }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.AdminRegisterDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Admin created successfully',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
                admin: {
                    id: '0f8fad5b-d9cb-469f-a165-70867728950e',
                    email: 'admin@techng.in',
                    firstName: 'Vikram',
                    lastName: 'Rao',
                    role: 'admin',
                },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({
        status: 401,
        description: 'Unauthorized — invalid or missing token',
    }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Only Super Admin can create admins',
    }),
    (0, swagger_1.ApiResponse)({ status: 409, description: 'Email already registered' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_dto_1.AdminRegisterDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "register", null);
__decorate([
    (0, common_1.Post)('forgot-password'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Request an admin password reset email',
        description: 'Sends a single-use reset link when the email belongs to an admin account. Always responds with the same message to prevent account enumeration.',
    }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.ForgotPasswordDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Reset email requested.' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.ForgotPasswordDto]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "forgotPassword", null);
__decorate([
    (0, common_1.Post)('reset-password'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Reset an admin password with an emailed token',
    }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.ResetPasswordDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Password reset successfully.' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Invalid or expired reset token' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.ResetPasswordDto]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "resetPassword", null);
__decorate([
    (0, common_1.Post)('login'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Admin login' }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.AdminLoginDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Admin login successful',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
                admin: {
                    id: '0f8fad5b-d9cb-469f-a165-70867728950e',
                    email: 'admin@techng.in',
                    firstName: 'Vikram',
                    lastName: 'Rao',
                    role: 'super_admin',
                },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Invalid email or password' }),
    (0, swagger_1.ApiResponse)({ status: 403, description: 'Admin account suspended' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Ip)()),
    __param(2, (0, common_1.Headers)('user-agent')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_dto_1.AdminLoginDto, String, String]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "login", null);
__decorate([
    (0, common_1.Post)('refresh'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Refresh admin access token' }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.RefreshTokenDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'New tokens generated',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Invalid or expired refresh token' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.RefreshTokenDto]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "refresh", null);
__decorate([
    (0, common_1.Post)('logout'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Logout admin (revokes refresh token)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Logged out successfully' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "logout", null);
__decorate([
    (0, common_1.Get)('me'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Get current admin profile' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Admin profile retrieved',
        type: admin_dto_1.AdminResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AuthAdminController.prototype, "getProfile", null);
exports.AuthAdminController = AuthAdminController = __decorate([
    (0, swagger_1.ApiTags)('🛡️ Admin Auth'),
    (0, common_1.Controller)('auth/admin'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthAdminController);
//# sourceMappingURL=auth-admin.controller.js.map