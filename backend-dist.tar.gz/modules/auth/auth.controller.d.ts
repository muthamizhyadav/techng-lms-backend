import { AuthService } from './auth.service';
import { ApproveDeviceLoginDto, ForgotPasswordDto, RefreshTokenDto, StudentLoginDto, StudentRegisterDto, StudentResetPasswordDto } from './dto/auth.dto';
import { User } from "../users/entities/user.entity";
import { ConfigService } from '@nestjs/config';
import { Request, Response } from 'express';
export declare class AuthController {
    private readonly authService;
    private readonly configService;
    constructor(authService: AuthService, configService: ConfigService);
    register(dto: StudentRegisterDto, req: Request): Promise<{
        accessToken: string;
        refreshToken: string;
        user: User;
    }>;
    login(dto: StudentLoginDto, req: Request): Promise<{
        accessToken: string;
        refreshToken: string;
        user: User;
    }>;
    approveDeviceLogin(dto: ApproveDeviceLoginDto, req: Request): Promise<{
        accessToken: string;
        refreshToken: string;
        user: User;
    }>;
    forgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    resetPassword(dto: StudentResetPasswordDto): Promise<{
        message: string;
    }>;
    refresh(dto: RefreshTokenDto): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    logout(userId: string, req: Request): Promise<{
        message: string;
    }>;
    listSessions(userId: string, req: Request): Promise<import("./auth.service").StudentSessionResponse[]>;
    logoutAll(userId: string): Promise<{
        message: string;
    }>;
    logoutDevice(userId: string, sessionId: string, req: Request): Promise<{
        message: string;
        sessionId: string;
        wasCurrentSession: boolean;
    }>;
    getProfile(user: User): Promise<User>;
    googleAuth(): Promise<void>;
    googleAuthCallback(req: Request, res: Response): Promise<void>;
    private currentSessionId;
    private loginContext;
}
