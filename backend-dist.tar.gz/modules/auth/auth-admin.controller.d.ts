import { AuthService } from './auth.service';
import { Admin } from "../admins/entities/admin.entity";
import { AdminLoginDto, AdminRegisterDto } from "../admins/dto/admin.dto";
import { ForgotPasswordDto, RefreshTokenDto, ResetPasswordDto } from './dto/auth.dto';
export declare class AuthAdminController {
    private readonly authService;
    constructor(authService: AuthService);
    setup(dto: AdminRegisterDto): Promise<{
        accessToken: string;
        refreshToken: string;
        admin: Admin;
    }>;
    register(dto: AdminRegisterDto, currentAdmin: Admin): Promise<{
        accessToken: string;
        refreshToken: string;
        admin: Admin;
    }>;
    forgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    resetPassword(dto: ResetPasswordDto): Promise<{
        message: string;
    }>;
    login(dto: AdminLoginDto, ipAddress: string, userAgent?: string): Promise<{
        accessToken: string;
        refreshToken: string;
        admin: Admin;
    }>;
    refresh(dto: RefreshTokenDto): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    logout(adminId: string): Promise<{
        message: string;
    }>;
    getProfile(admin: Admin): Promise<Admin>;
}
