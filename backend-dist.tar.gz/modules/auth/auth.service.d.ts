import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { UsersService } from "../users/users.service";
import { AdminsService } from "../admins/admins.service";
import { User } from "../users/entities/user.entity";
import { Admin } from "../admins/entities/admin.entity";
import { NotificationsService } from "../notifications/notifications.service";
import { MailService } from "../mail/mail.service";
import { LoginActivityService } from "../login-activity/login-activity.service";
import { ApproveDeviceLoginDto, ForgotPasswordDto, RefreshTokenDto, ResetPasswordDto, StudentLoginDto, StudentRegisterDto, StudentResetPasswordDto } from './dto/auth.dto';
import { AdminLoginDto, AdminRegisterDto } from '../admins/dto/admin.dto';
export interface StudentLoginContext {
    ipAddress?: string;
    userAgent?: string;
    deviceId?: string;
}
export interface StudentSessionResponse {
    sessionId: string;
    deviceId: string;
    deviceName: string;
    platform: string;
    ipAddress: string;
    loggedInAt: Date;
    lastActiveAt: Date;
    expiresAt: Date;
    isCurrent: boolean;
}
export interface DeviceSummary {
    deviceName: string;
    platform: string;
    ipAddress: string;
    loggedInAt: Date;
    lastActiveAt: Date;
    expiresAt: Date;
}
export interface GoogleDeviceHint {
    deviceId?: string;
    deviceName?: string;
    platform?: string;
    nonce?: string;
}
export interface GoogleLoginConflict {
    approvalToken: string;
    approvalExpiresInSeconds: number;
    activeSessions: DeviceSummary[];
    deviceId: string;
}
export type GoogleLoginResult = {
    status: 'success';
    accessToken: string;
    refreshToken: string;
    user: User;
} | {
    status: 'conflict';
    conflict: GoogleLoginConflict;
};
export declare class AuthService {
    private readonly jwtService;
    private readonly configService;
    private readonly usersService;
    private readonly adminsService;
    private readonly notificationsService;
    private readonly mailService;
    private readonly loginActivityService;
    constructor(jwtService: JwtService, configService: ConfigService, usersService: UsersService, adminsService: AdminsService, notificationsService: NotificationsService, mailService: MailService, loginActivityService: LoginActivityService);
    studentRegister(dto: StudentRegisterDto, context?: StudentLoginContext): Promise<{
        accessToken: string;
        refreshToken: string;
        user: User;
    }>;
    studentLogin(dto: StudentLoginDto, context?: StudentLoginContext): Promise<{
        accessToken: string;
        refreshToken: string;
        user: User;
    }>;
    approveDeviceLogin(dto: ApproveDeviceLoginDto, context?: StudentLoginContext): Promise<{
        accessToken: string;
        refreshToken: string;
        user: User;
    }>;
    studentRefresh(dto: RefreshTokenDto): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    studentLogout(userId: string, sessionId?: string): Promise<void>;
    getStudentSessions(userId: string, currentSessionId?: string): Promise<StudentSessionResponse[]>;
    revokeStudentSession(userId: string, sessionId: string, currentSessionId?: string): Promise<{
        message: string;
        sessionId: string;
        wasCurrentSession: boolean;
    }>;
    studentLogoutAll(userId: string): Promise<{
        message: string;
    }>;
    getStudentProfile(userId: string): Promise<User>;
    googleLogin(profile: {
        googleId: string;
        email: string;
        firstName: string;
        lastName: string;
        avatar?: string;
    }, context?: StudentLoginContext, deviceHint?: GoogleDeviceHint): Promise<GoogleLoginResult>;
    createGoogleOAuthState(hint: GoogleDeviceHint, nonce: string): string;
    verifyGoogleOAuthState(state?: string): GoogleDeviceHint | null;
    studentForgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    studentResetPassword(dto: StudentResetPasswordDto): Promise<{
        message: string;
    }>;
    adminRegister(dto: AdminRegisterDto, createdByAdminId?: string): Promise<{
        accessToken: string;
        refreshToken: string;
        admin: Admin;
    }>;
    adminForgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    adminResetPassword(dto: ResetPasswordDto): Promise<{
        message: string;
    }>;
    adminLogin(dto: AdminLoginDto, ipAddress?: string, userAgent?: string): Promise<{
        accessToken: string;
        refreshToken: string;
        admin: Admin;
    }>;
    adminRefresh(dto: RefreshTokenDto): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    adminLogout(adminId: string): Promise<void>;
    getAdminProfile(adminId: string): Promise<Admin>;
    private createStudentSession;
    private resolveDevice;
    private toDeviceSummary;
    private createDeviceApprovalToken;
    private toSessionResponse;
    private resolveRefreshExpiry;
    private describeDevice;
    private detectPlatform;
    private notifyAdminsOfNewStudent;
    private generateStudentTokens;
    private generateAdminTokens;
}
