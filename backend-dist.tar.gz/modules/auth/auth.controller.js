"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const auth_service_1 = require("./auth.service");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const auth_dto_1 = require("./dto/auth.dto");
const user_entity_1 = require("../users/entities/user.entity");
const user_dto_1 = require("../users/dto/user.dto");
const passport_1 = require("@nestjs/passport");
const config_1 = require("@nestjs/config");
const google_auth_guard_1 = require("./strategies/google-auth.guard");
let AuthController = class AuthController {
    constructor(authService, configService) {
        this.authService = authService;
        this.configService = configService;
    }
    async register(dto, req) {
        return this.authService.studentRegister(dto, this.loginContext(req));
    }
    async login(dto, req) {
        return this.authService.studentLogin(dto, this.loginContext(req));
    }
    async approveDeviceLogin(dto, req) {
        return this.authService.approveDeviceLogin(dto, this.loginContext(req));
    }
    async forgotPassword(dto) {
        return this.authService.studentForgotPassword(dto);
    }
    async resetPassword(dto) {
        return this.authService.studentResetPassword(dto);
    }
    async refresh(dto) {
        return this.authService.studentRefresh(dto);
    }
    async logout(userId, req) {
        await this.authService.studentLogout(userId, this.currentSessionId(req));
        return { message: 'Logged out successfully' };
    }
    async listSessions(userId, req) {
        return this.authService.getStudentSessions(userId, this.currentSessionId(req));
    }
    async logoutAll(userId) {
        return this.authService.studentLogoutAll(userId);
    }
    async logoutDevice(userId, sessionId, req) {
        return this.authService.revokeStudentSession(userId, sessionId, this.currentSessionId(req));
    }
    async getProfile(user) {
        return this.authService.getStudentProfile(user.id);
    }
    async googleAuth() {
    }
    async googleAuthCallback(req, res) {
        const user = req.user;
        const frontendUrl = (this.configService.get('google.frontendUrl') ?? '').replace(/\/+$/, '');
        const state = typeof req.query.state === 'string' ? req.query.state : undefined;
        const deviceHint = this.authService.verifyGoogleOAuthState(state);
        const nonceCookie = req.cookies?.[google_auth_guard_1.OAUTH_NONCE_COOKIE];
        res.clearCookie(google_auth_guard_1.OAUTH_NONCE_COOKIE, { path: '/' });
        if (!deviceHint ||
            !deviceHint.nonce ||
            typeof nonceCookie !== 'string' ||
            nonceCookie !== deviceHint.nonce) {
            return res.redirect(`${frontendUrl}/auth/callback?error=${encodeURIComponent('Sign-in could not be verified. Please try again.')}`);
        }
        const result = await this.authService.googleLogin(user, this.loginContext(req), deviceHint);
        if (result.status === 'conflict') {
            const payload = Buffer.from(JSON.stringify(result.conflict), 'utf8').toString('base64url');
            return res.redirect(`${frontendUrl}/auth/callback#deviceConflict=${payload}`);
        }
        const params = new URLSearchParams({
            accessToken: result.accessToken,
            refreshToken: result.refreshToken,
        });
        return res.redirect(`${frontendUrl}/auth/callback?${params.toString()}`);
    }
    currentSessionId(req) {
        const user = req.user;
        return user?.currentSessionId;
    }
    loginContext(req) {
        const headerDeviceId = req.headers['x-device-id'];
        return {
            ipAddress: req.ip,
            userAgent: req.headers['user-agent'],
            deviceId: Array.isArray(headerDeviceId)
                ? headerDeviceId[0]
                : headerDeviceId,
        };
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, common_1.Post)('register'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Register a new student account' }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.StudentRegisterDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Student registered successfully',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
                user: {
                    id: '0f8fad5b-d9cb-469f-a165-70867728950e',
                    email: 'rahul@email.com',
                    firstName: 'Rahul',
                    lastName: 'Kumar',
                    status: 'pending',
                },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 409, description: 'Email already registered' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.StudentRegisterDto, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "register", null);
__decorate([
    (0, common_1.Post)('login'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Student login' }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.StudentLoginDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Login successful',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
                user: {
                    id: '0f8fad5b-d9cb-469f-a165-70867728950e',
                    email: 'rahul@email.com',
                    firstName: 'Rahul',
                    lastName: 'Kumar',
                },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Invalid email or password' }),
    (0, swagger_1.ApiResponse)({ status: 403, description: 'Account not active' }),
    (0, swagger_1.ApiResponse)({
        status: 409,
        description: 'Account is already logged in on another device. Show the active device, then call POST /auth/student/login/approve with the approvalToken to sign the other device out and continue. Clients that cannot show a prompt may resend the login with logoutOtherDevices=true.',
        schema: {
            example: {
                statusCode: 409,
                code: 'ALREADY_LOGGED_IN',
                message: 'Your account is already active on another device. Sign out of that device to continue here.',
                error: 'Conflict',
                activeSessions: [
                    {
                        deviceName: 'Chrome on Windows',
                        platform: 'web',
                        ipAddress: '203.0.113.24',
                        loggedInAt: '2026-10-21T08:55:12.000Z',
                        lastActiveAt: '2026-10-21T09:12:44.000Z',
                        expiresAt: '2026-10-28T08:55:12.000Z',
                    },
                ],
                approvalToken: 'eyJhbGciOiJIUzI1NiIs...',
                approvalExpiresInSeconds: 300,
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.StudentLoginDto, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "login", null);
__decorate([
    (0, common_1.Post)('login/approve'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Approve signing out the other device and finish logging in on this one',
    }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.ApproveDeviceLoginDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Other device signed out; this device is now logged in',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
                user: {
                    id: '0f8fad5b-d9cb-469f-a165-70867728950e',
                    email: 'rahul@email.com',
                    firstName: 'Rahul',
                    lastName: 'Kumar',
                },
            },
        },
    }),
    (0, swagger_1.ApiResponse)({
        status: 401,
        description: 'Approval token missing, expired or issued for another device',
    }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.ApproveDeviceLoginDto, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "approveDeviceLogin", null);
__decorate([
    (0, common_1.Post)('forgot-password'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Request a student password reset email',
        description: 'Sends a single-use reset link when the email belongs to a student account. Always responds with the same message to prevent account enumeration.',
    }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.ForgotPasswordDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Reset email requested.' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.ForgotPasswordDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "forgotPassword", null);
__decorate([
    (0, common_1.Post)('reset-password'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Reset a student password with an emailed token',
    }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.StudentResetPasswordDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Password reset successfully.' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Invalid or expired reset token' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.StudentResetPasswordDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "resetPassword", null);
__decorate([
    (0, common_1.Post)('refresh'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({ summary: 'Refresh access token using refresh token' }),
    (0, swagger_1.ApiBody)({ type: auth_dto_1.RefreshTokenDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'New tokens generated',
        schema: {
            example: {
                accessToken: 'eyJhbGciOiJIUzI1NiIs...',
                refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Invalid or expired refresh token' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [auth_dto_1.RefreshTokenDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "refresh", null);
__decorate([
    (0, common_1.Post)('logout'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Logout student (revokes the current device session)',
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Logged out successfully' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "logout", null);
__decorate([
    (0, common_1.Get)('sessions'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'List active device sessions for this student' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Active sessions retrieved' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "listSessions", null);
__decorate([
    (0, common_1.Delete)('sessions'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Logout student from all devices' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Logged out from all devices' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "logoutAll", null);
__decorate([
    (0, common_1.Delete)('sessions/:sessionId'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Logout one device session by id' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Device logged out successfully' }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Session not found' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)('id')),
    __param(1, (0, common_1.Param)('sessionId')),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "logoutDevice", null);
__decorate([
    (0, common_1.Get)('me'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Get current student profile' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Student profile retrieved',
        type: user_dto_1.UserResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "getProfile", null);
__decorate([
    (0, common_1.Get)('google'),
    (0, common_1.UseGuards)(google_auth_guard_1.GoogleAuthGuard),
    (0, swagger_1.ApiOperation)({ summary: 'Initiate Google OAuth login' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "googleAuth", null);
__decorate([
    (0, common_1.Get)('google/callback'),
    (0, common_1.UseGuards)((0, passport_1.AuthGuard)('google')),
    (0, swagger_1.ApiOperation)({ summary: 'Google OAuth callback' }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "googleAuthCallback", null);
exports.AuthController = AuthController = __decorate([
    (0, swagger_1.ApiTags)('🎓 Student Auth'),
    (0, common_1.Controller)('auth/student'),
    __metadata("design:paramtypes", [auth_service_1.AuthService,
        config_1.ConfigService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map