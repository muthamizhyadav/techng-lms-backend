"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
const users_service_1 = require("../users/users.service");
const admins_service_1 = require("../admins/admins.service");
const password_util_1 = require("../../common/utils/password.util");
const uuid_util_1 = require("../../common/utils/uuid.util");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const notifications_service_1 = require("../notifications/notifications.service");
const notification_entity_1 = require("../notifications/entities/notification.entity");
const mail_service_1 = require("../mail/mail.service");
const login_activity_service_1 = require("../login-activity/login-activity.service");
const DEVICE_APPROVAL_TTL = '5m';
const DEVICE_APPROVAL_TTL_SECONDS = 5 * 60;
let AuthService = class AuthService {
    constructor(jwtService, configService, usersService, adminsService, notificationsService, mailService, loginActivityService) {
        this.jwtService = jwtService;
        this.configService = configService;
        this.usersService = usersService;
        this.adminsService = adminsService;
        this.notificationsService = notificationsService;
        this.mailService = mailService;
        this.loginActivityService = loginActivityService;
    }
    async studentRegister(dto, context = {}) {
        const user = await this.usersService.create(dto);
        const tokens = await this.createStudentSession(user, this.resolveDevice(dto, context), context);
        delete user.password;
        delete user.refreshTokenHash;
        void this.notifyAdminsOfNewStudent(user);
        return { ...tokens, user };
    }
    async studentLogin(dto, context = {}) {
        const user = await this.usersService.findByEmailWithPassword(dto.email);
        if (!user) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        if (!user.isActive()) {
            throw new common_1.ForbiddenException('Your account is not active. Please verify your email or contact support.');
        }
        const isPasswordValid = await password_util_1.PasswordUtil.compare(dto.password, user.password);
        if (!isPasswordValid) {
            throw new common_1.UnauthorizedException('Invalid email or password');
        }
        const device = this.resolveDevice(dto, context);
        const activeSessions = await this.usersService.getActiveSessions(user.id);
        const otherDeviceSessions = activeSessions.filter((session) => session.deviceId !== device.deviceId);
        if (otherDeviceSessions.length > 0 && !dto.logoutOtherDevices) {
            throw new common_1.ConflictException({
                error: 'Conflict',
                code: 'ALREADY_LOGGED_IN',
                message: 'Your account is already active on another device. Sign out of that device to continue here.',
                activeSessions: otherDeviceSessions.map((session) => this.toDeviceSummary(session)),
                approvalToken: await this.createDeviceApprovalToken(user, device),
                approvalExpiresInSeconds: DEVICE_APPROVAL_TTL_SECONDS,
            });
        }
        const tokens = await this.createStudentSession(user, device, context);
        await this.usersService.updateLastLogin(user.id);
        void this.loginActivityService.recordLogin({
            userId: user.id,
            userRole: 'student',
            email: user.email,
            name: `${user.firstName} ${user.lastName || ''}`.trim(),
            ipAddress: context.ipAddress,
            userAgent: context.userAgent,
            device: device.deviceName,
            status: 'success',
        });
        delete user.password;
        delete user.refreshTokenHash;
        return { ...tokens, user };
    }
    async approveDeviceLogin(dto, context = {}) {
        let payload;
        try {
            payload = this.jwtService.verify(dto.approvalToken, {
                secret: this.configService.get('jwt.student.secret'),
            });
        }
        catch {
            throw new common_1.UnauthorizedException('This sign-in approval has expired. Please sign in again.');
        }
        if (payload.type !== 'device-approval') {
            throw new common_1.UnauthorizedException('Invalid approval token');
        }
        const device = this.resolveDevice(dto, context);
        if (payload.did && payload.did !== device.deviceId) {
            throw new common_1.UnauthorizedException('This approval was requested from a different device. Please sign in again.');
        }
        const user = await this.usersService.findOne(payload.sub);
        if (!user.isActive()) {
            throw new common_1.ForbiddenException('Your account is not active. Please verify your email or contact support.');
        }
        const tokens = await this.createStudentSession(user, device, context);
        await this.usersService.updateLastLogin(user.id);
        void this.loginActivityService.recordLogin({
            userId: user.id,
            userRole: 'student',
            email: user.email,
            name: `${user.firstName} ${user.lastName || ''}`.trim(),
            ipAddress: context.ipAddress,
            userAgent: context.userAgent,
            device: device.deviceName,
            status: 'success',
        });
        delete user.password;
        delete user.refreshTokenHash;
        return { ...tokens, user };
    }
    async studentRefresh(dto) {
        let payload;
        try {
            payload = this.jwtService.verify(dto.refreshToken, {
                secret: this.configService.get('jwt.student.refreshSecret'),
            });
        }
        catch {
            throw new common_1.UnauthorizedException('Invalid or expired refresh token');
        }
        if (payload.type !== 'student') {
            throw new common_1.UnauthorizedException('Invalid token type');
        }
        if (!payload.sid) {
            throw new common_1.UnauthorizedException('Session expired. Please log in again.');
        }
        const sessionActive = await this.usersService.isSessionActive(payload.sub, payload.sid);
        if (!sessionActive) {
            await this.usersService.updateRefreshToken(payload.sub, null);
            throw new common_1.UnauthorizedException('Your session has ended. Please log in again.');
        }
        const isValid = await this.usersService.verifyRefreshToken(payload.sub, dto.refreshToken);
        if (!isValid) {
            throw new common_1.UnauthorizedException('Refresh token revoked or expired');
        }
        const tokens = await this.generateStudentTokens({
            sub: payload.sub,
            email: payload.email,
            role: payload.role,
            type: 'student',
            sid: payload.sid,
        });
        await this.usersService.updateRefreshToken(payload.sub, tokens.refreshToken);
        await this.usersService.touchSession(payload.sub, payload.sid, this.resolveRefreshExpiry());
        return tokens;
    }
    async studentLogout(userId, sessionId) {
        if (sessionId) {
            await this.usersService.revokeSession(userId, sessionId);
        }
        else {
            await this.usersService.revokeAllSessions(userId);
        }
        const remainingSessions = await this.usersService.getActiveSessions(userId);
        if (remainingSessions.length === 0) {
            await this.usersService.updateRefreshToken(userId, null);
        }
    }
    async getStudentSessions(userId, currentSessionId) {
        const sessions = await this.usersService.getActiveSessions(userId);
        return sessions.map((session) => this.toSessionResponse(session, currentSessionId));
    }
    async revokeStudentSession(userId, sessionId, currentSessionId) {
        const revoked = await this.usersService.revokeSession(userId, sessionId);
        if (!revoked) {
            throw new common_1.NotFoundException('Session not found or already logged out');
        }
        const remainingSessions = await this.usersService.getActiveSessions(userId);
        if (remainingSessions.length === 0) {
            await this.usersService.updateRefreshToken(userId, null);
        }
        return {
            message: 'Device logged out successfully',
            sessionId,
            wasCurrentSession: sessionId === currentSessionId,
        };
    }
    async studentLogoutAll(userId) {
        await this.studentLogout(userId);
        return { message: 'Logged out from all devices successfully' };
    }
    async getStudentProfile(userId) {
        return this.usersService.findOne(userId);
    }
    async googleLogin(profile, context = {}, deviceHint = {}) {
        let user = await this.usersService.findByGoogleId(profile.googleId);
        if (!user) {
            const existingByEmail = await this.usersService.findByEmail(profile.email);
            user = (await this.usersService.createGoogleUser(profile));
            if (!existingByEmail) {
                void this.notifyAdminsOfNewStudent(user);
            }
        }
        const device = this.resolveDevice(deviceHint, context);
        const activeSessions = await this.usersService.getActiveSessions(user.id);
        const otherDeviceSessions = activeSessions.filter((session) => session.deviceId !== device.deviceId);
        if (otherDeviceSessions.length > 0) {
            return {
                status: 'conflict',
                conflict: {
                    approvalToken: await this.createDeviceApprovalToken(user, device),
                    approvalExpiresInSeconds: DEVICE_APPROVAL_TTL_SECONDS,
                    activeSessions: otherDeviceSessions.map((session) => this.toDeviceSummary(session)),
                    deviceId: device.deviceId,
                },
            };
        }
        const tokens = await this.createStudentSession(user, device, context);
        await this.usersService.updateLastLogin(user.id);
        void this.loginActivityService.recordLogin({
            userId: user.id,
            userRole: 'student',
            email: user.email,
            name: `${user.firstName} ${user.lastName || ''}`.trim(),
            ipAddress: context.ipAddress,
            userAgent: context.userAgent,
            device: device.deviceName,
            status: 'success',
        });
        delete user.password;
        delete user.refreshTokenHash;
        return { status: 'success', ...tokens, user };
    }
    createGoogleOAuthState(hint, nonce) {
        const payload = {
            type: 'oauth-state',
            did: hint.deviceId,
            dn: hint.deviceName,
            pf: hint.platform,
            nonce,
        };
        return this.jwtService.sign(payload, {
            secret: this.configService.get('jwt.student.secret'),
            expiresIn: '10m',
        });
    }
    verifyGoogleOAuthState(state) {
        if (!state)
            return null;
        try {
            const payload = this.jwtService.verify(state, {
                secret: this.configService.get('jwt.student.secret'),
            });
            if (payload.type !== 'oauth-state')
                return null;
            return {
                deviceId: payload.did,
                deviceName: payload.dn,
                platform: payload.pf,
                nonce: payload.nonce,
            };
        }
        catch {
            return null;
        }
    }
    async studentForgotPassword(dto) {
        const message = 'If an account with that email exists, a password reset link has been sent.';
        const user = await this.usersService.findByEmail(dto.email);
        if (!user) {
            return { message };
        }
        const rawToken = (0, crypto_1.randomBytes)(32).toString('hex');
        const tokenHash = (0, crypto_1.createHash)('sha256').update(rawToken).digest('hex');
        const ttlMinutes = this.configService.get('mail.resetTokenTtlMinutes') ?? 60;
        const expiresAt = new Date(Date.now() + ttlMinutes * 60_000);
        await this.usersService.setPasswordResetToken(user.id, tokenHash, expiresAt);
        const baseUrl = (this.configService.get('mail.studentPanelUrl') ??
            this.configService.get('mail.adminPanelUrl') ??
            '').replace(/\/+$/, '');
        const resetUrl = `${baseUrl}/reset-password?token=${rawToken}`;
        await this.mailService.sendPasswordResetEmail({
            to: user.email,
            firstName: user.firstName,
            resetUrl,
            expiresInMinutes: ttlMinutes,
        });
        return { message };
    }
    async studentResetPassword(dto) {
        const tokenHash = (0, crypto_1.createHash)('sha256').update(dto.token).digest('hex');
        const user = await this.usersService.findByPasswordResetToken(tokenHash);
        if (!user) {
            throw new common_1.BadRequestException('This password reset link is invalid or has expired.');
        }
        const hashedPassword = await password_util_1.PasswordUtil.hash(dto.newPassword, this.configService.get('app.bcryptRounds'));
        await this.usersService.resetPassword(user.id, hashedPassword);
        return { message: 'Your password has been reset successfully.' };
    }
    async adminRegister(dto, createdByAdminId) {
        if (createdByAdminId) {
            const creator = await this.adminsService.findOne(createdByAdminId);
            if (!creator.isSuperAdmin()) {
                throw new common_1.ForbiddenException('Only Super Admin can create new admin accounts');
            }
        }
        else {
            const adminCount = await this.adminsService.countAll();
            if (adminCount > 0) {
                throw new common_1.ForbiddenException('Admin registration is restricted. Contact Super Admin.');
            }
            dto.role = user_status_enum_1.AdminRole.SUPER_ADMIN;
        }
        const admin = await this.adminsService.create(dto, createdByAdminId);
        const tokens = await this.generateAdminTokens({
            sub: admin.id,
            email: admin.email,
            role: admin.role,
            username: admin.username,
            type: 'admin',
        });
        await this.adminsService.updateRefreshToken(admin.id, tokens.refreshToken);
        delete admin.password;
        delete admin.refreshTokenHash;
        return { ...tokens, admin };
    }
    async adminForgotPassword(dto) {
        const message = 'If an account with that email exists, a password reset link has been sent.';
        const admin = await this.adminsService.findByEmail(dto.email);
        if (!admin) {
            return { message };
        }
        const rawToken = (0, crypto_1.randomBytes)(32).toString('hex');
        const tokenHash = (0, crypto_1.createHash)('sha256').update(rawToken).digest('hex');
        const ttlMinutes = this.configService.get('mail.resetTokenTtlMinutes') ?? 60;
        const expiresAt = new Date(Date.now() + ttlMinutes * 60_000);
        await this.adminsService.setPasswordResetToken(admin.id, tokenHash, expiresAt);
        const baseUrl = (this.configService.get('mail.adminPanelUrl') ?? '').replace(/\/+$/, '');
        const resetUrl = `${baseUrl}/update-password?token=${rawToken}`;
        await this.mailService.sendPasswordResetEmail({
            to: admin.email,
            firstName: admin.firstName,
            resetUrl,
            expiresInMinutes: ttlMinutes,
        });
        return { message };
    }
    async adminResetPassword(dto) {
        const tokenHash = (0, crypto_1.createHash)('sha256').update(dto.token).digest('hex');
        const admin = await this.adminsService.findByPasswordResetToken(tokenHash);
        if (!admin) {
            throw new common_1.BadRequestException('This password reset link is invalid or has expired.');
        }
        const hashedPassword = await password_util_1.PasswordUtil.hash(dto.newPassword, this.configService.get('app.bcryptRounds'));
        await this.adminsService.resetPassword(admin.id, hashedPassword);
        return { message: 'Your password has been reset successfully.' };
    }
    async adminLogin(dto, ipAddress, userAgent) {
        const admin = await this.adminsService.findByIdentifierWithPassword(dto.email);
        if (!admin) {
            void this.loginActivityService.recordLogin({
                userId: 'unknown',
                userRole: 'unknown',
                email: dto.email,
                ipAddress,
                userAgent,
                status: 'failed',
                failureReason: 'Account not found',
            });
            throw new common_1.UnauthorizedException('Invalid email, username, or password');
        }
        if (!admin.isActive()) {
            void this.loginActivityService.recordLogin({
                userId: admin.id,
                userRole: admin.role,
                email: admin.email,
                name: admin.fullName,
                ipAddress,
                userAgent,
                status: 'failed',
                failureReason: 'Account suspended',
            });
            throw new common_1.ForbiddenException('Your admin account is suspended. Contact Super Admin.');
        }
        const isPasswordValid = await password_util_1.PasswordUtil.compare(dto.password, admin.password);
        if (!isPasswordValid) {
            void this.loginActivityService.recordLogin({
                userId: admin.id,
                userRole: admin.role,
                email: admin.email,
                name: admin.fullName,
                ipAddress,
                userAgent,
                status: 'failed',
                failureReason: 'Invalid password',
            });
            throw new common_1.UnauthorizedException('Invalid email, username, or password');
        }
        let trainerSessionId = undefined;
        if (admin.role === user_status_enum_1.AdminRole.TRAINER) {
            const incomingDeviceId = dto.deviceId ||
                `device_${(0, crypto_1.createHash)('md5')
                    .update((ipAddress || '') + (userAgent || ''))
                    .digest('hex')
                    .slice(0, 12)}`;
            const now = new Date();
            const hasActiveSession = Boolean(admin.activeSessionId &&
                admin.activeSessionExpiresAt &&
                new Date(admin.activeSessionExpiresAt) > now);
            if (hasActiveSession &&
                admin.activeDeviceId &&
                admin.activeDeviceId !== incomingDeviceId) {
                void this.loginActivityService.recordLogin({
                    userId: admin.id,
                    userRole: 'trainer',
                    email: admin.email,
                    name: admin.fullName,
                    ipAddress,
                    userAgent,
                    device: dto.deviceName || 'Secondary Device',
                    status: 'conflict_blocked',
                    failureReason: 'Trainer already active on another device',
                });
                throw new common_1.ConflictException({
                    statusCode: 409,
                    error: 'Conflict',
                    code: 'TRAINER_ALREADY_LOGGED_IN',
                    message: 'Your account is already active on another device. Please log out from your existing session before logging in again.',
                    activeSession: {
                        deviceId: admin.activeDeviceId,
                        deviceName: admin.activeDeviceName || 'Active Session',
                        loggedInAt: admin.activeSessionLoggedInAt || admin.lastLoginAt,
                    },
                });
            }
            trainerSessionId = (0, uuid_util_1.generateUuid)();
            const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
            await this.adminsService.setTrainerActiveSession(admin.id, {
                sessionId: trainerSessionId,
                deviceId: incomingDeviceId,
                deviceName: dto.deviceName || 'Web Browser',
                ipAddress,
                expiresAt,
            });
        }
        const tokens = await this.generateAdminTokens({
            sub: admin.id,
            email: admin.email,
            role: admin.role,
            username: admin.username,
            sessionId: trainerSessionId,
            type: 'admin',
        });
        await this.adminsService.updateRefreshToken(admin.id, tokens.refreshToken);
        await this.adminsService.updateLastLogin(admin.id, ipAddress, dto.deviceName || undefined);
        void this.loginActivityService.recordLogin({
            userId: admin.id,
            userRole: admin.role,
            email: admin.email,
            name: admin.fullName,
            ipAddress,
            userAgent,
            device: dto.deviceName || 'Web Browser',
            status: 'success',
        });
        delete admin.password;
        delete admin.refreshTokenHash;
        delete admin.twoFactorSecret;
        return { ...tokens, admin };
    }
    async adminRefresh(dto) {
        let payload;
        try {
            payload = this.jwtService.verify(dto.refreshToken, {
                secret: this.configService.get('jwt.admin.refreshSecret'),
            });
        }
        catch {
            throw new common_1.UnauthorizedException('Invalid or expired refresh token');
        }
        if (payload.type !== 'admin') {
            throw new common_1.UnauthorizedException('Invalid token type');
        }
        const isValid = await this.adminsService.verifyRefreshToken(payload.sub, dto.refreshToken);
        if (!isValid) {
            throw new common_1.UnauthorizedException('Refresh token revoked or expired');
        }
        const tokens = await this.generateAdminTokens({
            sub: payload.sub,
            email: payload.email,
            role: payload.role,
            username: payload.username,
            sessionId: payload.sessionId,
            type: 'admin',
        });
        await this.adminsService.updateRefreshToken(payload.sub, tokens.refreshToken);
        return tokens;
    }
    async adminLogout(adminId) {
        try {
            const admin = await this.adminsService.findOne(adminId);
            if (admin && admin.role === user_status_enum_1.AdminRole.TRAINER) {
                await this.adminsService.clearTrainerActiveSession(adminId);
            }
        }
        catch {
        }
        await this.adminsService.updateRefreshToken(adminId, null);
    }
    async getAdminProfile(adminId) {
        return this.adminsService.findOne(adminId);
    }
    async createStudentSession(user, device, context) {
        const sessionId = (0, uuid_util_1.generateUuid)();
        const tokens = await this.generateStudentTokens({
            sub: user.id,
            email: user.email,
            role: user.role,
            type: 'student',
            sid: sessionId,
        });
        await this.usersService.startSession(user.id, {
            sessionId,
            deviceId: device.deviceId,
            deviceName: device.deviceName,
            platform: device.platform,
            ipAddress: context.ipAddress ?? null,
            userAgent: context.userAgent ?? null,
            loggedInAt: new Date(),
            lastActiveAt: new Date(),
            expiresAt: this.resolveRefreshExpiry(),
        });
        await this.usersService.updateRefreshToken(user.id, tokens.refreshToken);
        return tokens;
    }
    resolveDevice(dto, context) {
        const userAgent = context.userAgent || '';
        const deviceId = (dto.deviceId || context.deviceId || '').trim() ||
            `ua:${(0, crypto_1.createHash)('sha256')
                .update(userAgent || 'unknown-device')
                .digest('hex')
                .slice(0, 40)}`;
        return {
            deviceId,
            deviceName: dto.deviceName?.trim() || this.describeDevice(userAgent),
            platform: dto.platform || this.detectPlatform(userAgent),
        };
    }
    toDeviceSummary(session) {
        return {
            deviceName: session.deviceName,
            platform: session.platform,
            ipAddress: session.ipAddress,
            loggedInAt: session.loggedInAt,
            lastActiveAt: session.lastActiveAt,
            expiresAt: session.expiresAt,
        };
    }
    async createDeviceApprovalToken(user, device) {
        const payload = {
            sub: user.id,
            email: user.email,
            role: user.role,
            type: 'device-approval',
            did: device.deviceId,
        };
        return this.jwtService.sign(payload, {
            secret: this.configService.get('jwt.student.secret'),
            expiresIn: DEVICE_APPROVAL_TTL,
        });
    }
    toSessionResponse(session, currentSessionId) {
        return {
            sessionId: session.sessionId,
            deviceId: session.deviceId,
            deviceName: session.deviceName,
            platform: session.platform,
            ipAddress: session.ipAddress,
            loggedInAt: session.loggedInAt,
            lastActiveAt: session.lastActiveAt,
            expiresAt: session.expiresAt,
            isCurrent: !!currentSessionId && session.sessionId === currentSessionId,
        };
    }
    resolveRefreshExpiry() {
        const raw = this.configService.get('jwt.student.refreshExpiresIn') || '7d';
        const unitMs = {
            s: 1000,
            m: 60 * 1000,
            h: 60 * 60 * 1000,
            d: 24 * 60 * 60 * 1000,
        };
        const match = /^(\d+)\s*([smhd])$/i.exec(raw.trim());
        const durationMs = match
            ? Number(match[1]) * unitMs[match[2].toLowerCase()]
            : 7 * unitMs.d;
        return new Date(Date.now() + durationMs);
    }
    describeDevice(userAgent) {
        const browser = /Edg\//.test(userAgent)
            ? 'Edge'
            : /OPR\//.test(userAgent)
                ? 'Opera'
                : /Chrome\//.test(userAgent)
                    ? 'Chrome'
                    : /Firefox\//.test(userAgent)
                        ? 'Firefox'
                        : /Safari\//.test(userAgent)
                            ? 'Safari'
                            : 'Unknown browser';
        const os = /Windows/.test(userAgent)
            ? 'Windows'
            : /Android/.test(userAgent)
                ? 'Android'
                : /iPhone|iPad|iPod/.test(userAgent)
                    ? 'iOS'
                    : /Mac OS X/.test(userAgent)
                        ? 'macOS'
                        : /Linux/.test(userAgent)
                            ? 'Linux'
                            : 'Unknown OS';
        return `${browser} on ${os}`;
    }
    detectPlatform(userAgent) {
        if (/Android/i.test(userAgent))
            return 'android';
        if (/iPhone|iPad|iPod/i.test(userAgent))
            return 'ios';
        if (/Windows|Mac OS X|Linux/i.test(userAgent))
            return 'web';
        return 'unknown';
    }
    async notifyAdminsOfNewStudent(user) {
        const name = [user.firstName, user.lastName].filter(Boolean).join(' ') || user.email;
        await this.notificationsService.notifyAdmins({
            title: 'New student onboarded',
            body: `${name} just created an account (${user.email}).`,
            type: notification_entity_1.AdminNotificationType.STUDENT_REGISTERED,
            data: {
                type: 'student_registered',
                userId: user.id,
            },
            link: '/students',
        });
    }
    async generateStudentTokens(payload) {
        const accessToken = this.jwtService.sign(payload, {
            secret: this.configService.get('jwt.student.secret'),
            expiresIn: this.configService.get('jwt.student.expiresIn'),
        });
        const refreshToken = this.jwtService.sign(payload, {
            secret: this.configService.get('jwt.student.refreshSecret'),
            expiresIn: this.configService.get('jwt.student.refreshExpiresIn'),
        });
        return { accessToken, refreshToken };
    }
    async generateAdminTokens(payload) {
        const accessToken = this.jwtService.sign(payload, {
            secret: this.configService.get('jwt.admin.secret'),
            expiresIn: this.configService.get('jwt.admin.expiresIn'),
        });
        const refreshToken = this.jwtService.sign(payload, {
            secret: this.configService.get('jwt.admin.refreshSecret'),
            expiresIn: this.configService.get('jwt.admin.refreshExpiresIn'),
        });
        return { accessToken, refreshToken };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [jwt_1.JwtService,
        config_1.ConfigService,
        users_service_1.UsersService,
        admins_service_1.AdminsService,
        notifications_service_1.NotificationsService,
        mail_service_1.MailService,
        login_activity_service_1.LoginActivityService])
], AuthService);
//# sourceMappingURL=auth.service.js.map