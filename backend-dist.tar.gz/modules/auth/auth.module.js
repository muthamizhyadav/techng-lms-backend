"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthModule = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const passport_1 = require("@nestjs/passport");
const config_1 = require("@nestjs/config");
const auth_controller_1 = require("./auth.controller");
const auth_service_1 = require("./auth.service");
const student_jwt_strategy_1 = require("./strategies/student-jwt.strategy");
const admin_jwt_strategy_1 = require("./strategies/admin-jwt.strategy");
const google_strategy_1 = require("./strategies/google.strategy");
const google_auth_guard_1 = require("./strategies/google-auth.guard");
const users_module_1 = require("../users/users.module");
const admins_module_1 = require("../admins/admins.module");
const notifications_module_1 = require("../notifications/notifications.module");
const mail_module_1 = require("../mail/mail.module");
const login_activity_module_1 = require("../login-activity/login-activity.module");
const auth_admin_controller_1 = require("./auth-admin.controller");
let AuthModule = class AuthModule {
};
exports.AuthModule = AuthModule;
exports.AuthModule = AuthModule = __decorate([
    (0, common_1.Module)({
        imports: [
            passport_1.PassportModule.register({ defaultStrategy: 'student-jwt' }),
            jwt_1.JwtModule.registerAsync({
                imports: [config_1.ConfigModule],
                inject: [config_1.ConfigService],
                useFactory: (config) => ({
                    secret: config.get('jwt.student.secret'),
                    signOptions: {
                        expiresIn: config.get('jwt.student.expiresIn'),
                    },
                }),
            }),
            users_module_1.UsersModule,
            admins_module_1.AdminsModule,
            notifications_module_1.NotificationsModule,
            mail_module_1.MailModule,
            login_activity_module_1.LoginActivityModule,
        ],
        controllers: [auth_controller_1.AuthController, auth_admin_controller_1.AuthAdminController],
        providers: [
            auth_service_1.AuthService,
            student_jwt_strategy_1.StudentJwtStrategy,
            admin_jwt_strategy_1.AdminJwtStrategy,
            google_strategy_1.GoogleStrategy,
            google_auth_guard_1.GoogleAuthGuard,
        ],
        exports: [auth_service_1.AuthService],
    })
], AuthModule);
//# sourceMappingURL=auth.module.js.map