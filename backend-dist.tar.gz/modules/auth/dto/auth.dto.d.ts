import { CreateUserDto } from "../../users/dto/user.dto";
export declare class StudentRegisterDto extends CreateUserDto {
    deviceId?: string;
    deviceName?: string;
    platform?: string;
}
export declare class StudentLoginDto {
    email: string;
    password: string;
    deviceId?: string;
    deviceName?: string;
    platform?: string;
    logoutOtherDevices?: boolean;
}
export declare class ApproveDeviceLoginDto {
    approvalToken: string;
    deviceId?: string;
    deviceName?: string;
    platform?: string;
}
export declare class RefreshTokenDto {
    refreshToken: string;
}
export declare class ForgotPasswordDto {
    email: string;
}
export declare class ResetPasswordDto {
    token: string;
    newPassword: string;
}
export declare class StudentResetPasswordDto extends ResetPasswordDto {
    newPassword: string;
}
