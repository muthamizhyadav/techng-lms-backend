import { HydratedDocument } from 'mongoose';
export type EnrollmentDocument = HydratedDocument<Enrollment>;
export declare enum EnrollmentStatus {
    ACTIVE = "active",
    COMPLETED = "completed",
    DROPPED = "dropped"
}
export declare class Enrollment {
    _id: string;
    id: string;
    userId: string;
    courseId: string;
    orderId: string;
    status: EnrollmentStatus;
    progress: number;
    lessonProgress: Map<string, {
        completed: boolean;
        watchTime: number;
        lastPosition: number;
        completedAt: Date | null;
    }>;
    currentLessonId: string;
    enrolledAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const EnrollmentSchema: import("mongoose").Schema<Enrollment, import("mongoose").Model<Enrollment, any, any, any, any, any, Enrollment>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    userId?: import("mongoose").SchemaDefinitionProperty<string, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    courseId?: import("mongoose").SchemaDefinitionProperty<string, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    orderId?: import("mongoose").SchemaDefinitionProperty<string, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<EnrollmentStatus, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    progress?: import("mongoose").SchemaDefinitionProperty<number, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lessonProgress?: import("mongoose").SchemaDefinitionProperty<Map<string, {
        completed: boolean;
        watchTime: number;
        lastPosition: number;
        completedAt: Date | null;
    }>, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    currentLessonId?: import("mongoose").SchemaDefinitionProperty<string, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    enrolledAt?: import("mongoose").SchemaDefinitionProperty<Date, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, Enrollment, import("mongoose").Document<unknown, {}, Enrollment, {}, import("mongoose").DefaultSchemaOptions> & Enrollment & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, Enrollment>;
