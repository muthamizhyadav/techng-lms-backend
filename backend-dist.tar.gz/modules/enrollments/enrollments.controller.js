"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnrollmentsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const enrollments_service_1 = require("./enrollments.service");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const user_entity_1 = require("../users/entities/user.entity");
const update_progress_dto_1 = require("./dto/update-progress.dto");
let EnrollmentsController = class EnrollmentsController {
    constructor(enrollmentsService) {
        this.enrollmentsService = enrollmentsService;
    }
    async getMyCourses(user) {
        return this.enrollmentsService.getMyEnrolledCourses(user.id);
    }
    async checkEnrollment(user, courseId) {
        const isEnrolled = await this.enrollmentsService.isEnrolled(user.id, courseId);
        return { isEnrolled };
    }
    async getCurriculumByCourse(user, courseId) {
        return this.enrollmentsService.getCurriculumByCourseId(user.id, courseId);
    }
    async getCurriculum(user, enrollmentId) {
        return this.enrollmentsService.getCurriculum(user.id, enrollmentId);
    }
    async updateProgress(user, enrollmentId, dto) {
        return this.enrollmentsService.updateProgress(user.id, enrollmentId, dto);
    }
    async completeLesson(user, enrollmentId, lessonId) {
        return this.enrollmentsService.completeLesson(user.id, enrollmentId, lessonId);
    }
};
exports.EnrollmentsController = EnrollmentsController;
__decorate([
    (0, common_1.Get)('my-courses'),
    (0, swagger_1.ApiOperation)({ summary: 'Get all enrolled courses for logged in student' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'List of enrolled courses' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User]),
    __metadata("design:returntype", Promise)
], EnrollmentsController.prototype, "getMyCourses", null);
__decorate([
    (0, common_1.Get)('check/:courseId'),
    (0, swagger_1.ApiOperation)({ summary: 'Check if student is enrolled in a specific course' }),
    (0, swagger_1.ApiParam)({ name: 'courseId', description: 'Course UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Enrollment status' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('courseId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String]),
    __metadata("design:returntype", Promise)
], EnrollmentsController.prototype, "checkEnrollment", null);
__decorate([
    (0, common_1.Get)('course/:courseId/curriculum'),
    (0, swagger_1.ApiOperation)({ summary: 'Get course curriculum for enrolled student by course ID' }),
    (0, swagger_1.ApiParam)({ name: 'courseId', description: 'Course UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Curriculum data with progress' }),
    (0, swagger_1.ApiResponse)({ status: 403, description: 'User has not purchased this course' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('courseId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String]),
    __metadata("design:returntype", Promise)
], EnrollmentsController.prototype, "getCurriculumByCourse", null);
__decorate([
    (0, common_1.Get)(':enrollmentId/curriculum'),
    (0, swagger_1.ApiOperation)({ summary: 'Get course curriculum with enrollment progress' }),
    (0, swagger_1.ApiParam)({ name: 'enrollmentId', description: 'Enrollment UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Curriculum data with progress' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('enrollmentId', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String]),
    __metadata("design:returntype", Promise)
], EnrollmentsController.prototype, "getCurriculum", null);
__decorate([
    (0, common_1.Patch)(':enrollmentId/progress'),
    (0, swagger_1.ApiOperation)({ summary: 'Update video watch progress for a lesson' }),
    (0, swagger_1.ApiParam)({ name: 'enrollmentId', description: 'Enrollment UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Progress updated' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('enrollmentId', common_1.ParseUUIDPipe)),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String, update_progress_dto_1.UpdateProgressDto]),
    __metadata("design:returntype", Promise)
], EnrollmentsController.prototype, "updateProgress", null);
__decorate([
    (0, common_1.Post)(':enrollmentId/lessons/:lessonId/complete'),
    (0, swagger_1.ApiOperation)({ summary: 'Mark a lesson as completed' }),
    (0, swagger_1.ApiParam)({ name: 'enrollmentId', description: 'Enrollment UUID' }),
    (0, swagger_1.ApiParam)({ name: 'lessonId', description: 'Lesson UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Lesson completed, progress updated' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Param)('enrollmentId', common_1.ParseUUIDPipe)),
    __param(2, (0, common_1.Param)('lessonId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, String, String]),
    __metadata("design:returntype", Promise)
], EnrollmentsController.prototype, "completeLesson", null);
exports.EnrollmentsController = EnrollmentsController = __decorate([
    (0, swagger_1.ApiTags)('🎓 Student Enrollments'),
    (0, common_1.Controller)('enrollments'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    __metadata("design:paramtypes", [enrollments_service_1.EnrollmentsService])
], EnrollmentsController);
//# sourceMappingURL=enrollments.controller.js.map