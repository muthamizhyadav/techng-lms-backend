export declare class UpdateProgressDto {
    lessonId: string;
    watchTime: number;
    lastPosition: number;
}
