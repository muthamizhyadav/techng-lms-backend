import { EnrollmentsService } from './enrollments.service';
import { User } from "../users/entities/user.entity";
import { UpdateProgressDto } from './dto/update-progress.dto';
export declare class EnrollmentsController {
    private readonly enrollmentsService;
    constructor(enrollmentsService: EnrollmentsService);
    getMyCourses(user: User): Promise<{
        enrollmentId: string;
        status: import("./entities/enrollment.entity").EnrollmentStatus;
        progress: number;
        enrolledAt: Date;
        course: {
            id: string;
            title: string;
            description: string;
            instructor: string;
            category: string;
            duration: string;
            level: string;
            thumbnail: string;
            videoUrl: string;
            skills: string[];
        };
    }[]>;
    checkEnrollment(user: User, courseId: string): Promise<{
        isEnrolled: boolean;
    }>;
    getCurriculumByCourse(user: User, courseId: string): Promise<{
        enrollmentId: string;
        courseId: string;
        courseTitle: string;
        modules: any[];
        lessonProgress: Record<string, any>;
        currentLessonId: string;
        overallProgress: number;
    }>;
    getCurriculum(user: User, enrollmentId: string): Promise<{
        enrollmentId: string;
        courseId: string;
        courseTitle: string;
        modules: any[];
        lessonProgress: Record<string, any>;
        currentLessonId: string;
        overallProgress: number;
    }>;
    updateProgress(user: User, enrollmentId: string, dto: UpdateProgressDto): Promise<{
        success: boolean;
    }>;
    completeLesson(user: User, enrollmentId: string, lessonId: string): Promise<{
        success: boolean;
        progress: number;
        nextLessonId: string;
        completed: boolean;
    }>;
}
