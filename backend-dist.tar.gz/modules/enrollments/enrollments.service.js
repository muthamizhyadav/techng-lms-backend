"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnrollmentsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const enrollment_entity_1 = require("./entities/enrollment.entity");
const course_entity_1 = require("../courses/entities/course.entity");
const curriculum_util_1 = require("../../shared/utils/curriculum.util");
let EnrollmentsService = class EnrollmentsService {
    constructor(enrollmentModel, courseModel) {
        this.enrollmentModel = enrollmentModel;
        this.courseModel = courseModel;
    }
    async enrollUserInCourse(userId, courseId, orderId) {
        const existing = await this.enrollmentModel.findOne({ userId, courseId });
        if (existing) {
            return existing.toJSON();
        }
        const enrollment = await this.enrollmentModel.create({
            userId,
            courseId,
            orderId,
            status: enrollment_entity_1.EnrollmentStatus.ACTIVE,
            enrolledAt: new Date(),
        });
        await this.courseModel.updateOne({ _id: courseId }, { $inc: { students: 1 } });
        return enrollment.toJSON();
    }
    async isEnrolled(userId, courseId) {
        const count = await this.enrollmentModel.countDocuments({
            userId,
            courseId,
            status: { $in: [enrollment_entity_1.EnrollmentStatus.ACTIVE, enrollment_entity_1.EnrollmentStatus.COMPLETED] },
        });
        return count > 0;
    }
    async getMyEnrolledCourses(userId) {
        const enrollments = await this.enrollmentModel
            .find({ userId })
            .sort({ enrolledAt: -1 })
            .exec();
        const courseIds = enrollments.map((e) => e.courseId);
        const courses = await this.courseModel.find({
            _id: { $in: courseIds },
            deletedAt: null,
        });
        const courseMap = new Map();
        courses.forEach((c) => {
            courseMap.set(c._id.toString(), c);
        });
        return enrollments
            .map((enrollment) => {
            const course = courseMap.get(enrollment.courseId);
            if (!course)
                return null;
            return {
                enrollmentId: enrollment._id.toString(),
                status: enrollment.status,
                progress: enrollment.progress,
                enrolledAt: enrollment.enrolledAt,
                course: {
                    id: course._id.toString(),
                    title: course.title,
                    description: course.description,
                    instructor: course.instructor,
                    category: course.category,
                    duration: course.duration,
                    level: course.level,
                    thumbnail: course.thumbnail,
                    videoUrl: course.videoUrl,
                    skills: course.skills,
                },
            };
        })
            .filter(Boolean);
    }
    async getCurriculum(userId, enrollmentId) {
        const enrollment = await this.enrollmentModel.findOne({
            _id: enrollmentId,
            userId,
        });
        if (!enrollment) {
            throw new common_1.NotFoundException('Enrollment not found');
        }
        const course = await this.courseModel.findOne({
            _id: enrollment.courseId,
            deletedAt: null,
        });
        if (!course) {
            throw new common_1.NotFoundException('Course not found');
        }
        const lessonProgressObj = {};
        if (enrollment.lessonProgress) {
            enrollment.lessonProgress.forEach((value, key) => {
                lessonProgressObj[key] = value;
            });
        }
        return {
            enrollmentId: enrollment._id.toString(),
            courseId: course._id.toString(),
            courseTitle: course.title,
            modules: (0, curriculum_util_1.withCurriculumIds)(course.modules || []),
            lessonProgress: lessonProgressObj,
            currentLessonId: enrollment.currentLessonId || null,
            overallProgress: enrollment.progress,
        };
    }
    async getCurriculumByCourseId(userId, courseId) {
        const enrollment = await this.enrollmentModel.findOne({
            userId,
            courseId,
            status: enrollment_entity_1.EnrollmentStatus.ACTIVE,
        });
        if (!enrollment) {
            throw new common_1.ForbiddenException('Access Denied: You must purchase this course to access lessons and curriculum.');
        }
        return this.getCurriculum(userId, enrollment._id.toString());
    }
    async updateProgress(userId, enrollmentId, dto) {
        const enrollment = await this.enrollmentModel.findOne({
            _id: enrollmentId,
            userId,
        });
        if (!enrollment) {
            throw new common_1.NotFoundException('Enrollment not found');
        }
        const updateFields = {};
        updateFields[`lessonProgress.${dto.lessonId}.watchTime`] = dto.watchTime;
        updateFields[`lessonProgress.${dto.lessonId}.lastPosition`] =
            dto.lastPosition;
        updateFields.currentLessonId = dto.lessonId;
        await this.enrollmentModel.updateOne({ _id: enrollmentId }, { $set: updateFields });
        return { success: true };
    }
    async completeLesson(userId, enrollmentId, lessonId) {
        const enrollment = await this.enrollmentModel.findOne({
            _id: enrollmentId,
            userId,
        });
        if (!enrollment) {
            throw new common_1.NotFoundException('Enrollment not found');
        }
        const course = await this.courseModel.findOne({
            _id: enrollment.courseId,
            deletedAt: null,
        });
        if (!course) {
            throw new common_1.NotFoundException('Course not found');
        }
        const updateFields = {};
        updateFields[`lessonProgress.${lessonId}.completed`] = true;
        updateFields[`lessonProgress.${lessonId}.completedAt`] = new Date();
        const modules = (0, curriculum_util_1.withCurriculumIds)(course.modules || []);
        const allLessonIds = [];
        for (const mod of modules) {
            for (const lesson of mod.lessons || []) {
                allLessonIds.push(String(lesson._id || ''));
            }
        }
        const progress = await this.enrollmentModel.findOne({ _id: enrollmentId });
        const currentCompleted = new Set();
        if (progress?.lessonProgress) {
            progress.lessonProgress.forEach((val, key) => {
                if (val.completed)
                    currentCompleted.add(key);
            });
        }
        currentCompleted.add(lessonId);
        const totalLessons = allLessonIds.length || 1;
        const completedCount = currentCompleted.size;
        const overallProgress = Math.min(Math.round((completedCount / totalLessons) * 100), 100);
        updateFields.progress = overallProgress;
        if (overallProgress >= 100) {
            updateFields.status = enrollment_entity_1.EnrollmentStatus.COMPLETED;
        }
        await this.enrollmentModel.updateOne({ _id: enrollmentId }, { $set: updateFields });
        let nextLessonId = null;
        let foundCurrent = false;
        for (const mod of modules) {
            for (const lesson of mod.lessons || []) {
                const lid = String(lesson._id || '');
                if (foundCurrent && !currentCompleted.has(lid)) {
                    nextLessonId = lid;
                    break;
                }
                if (lid === lessonId) {
                    foundCurrent = true;
                }
            }
            if (nextLessonId)
                break;
        }
        return {
            success: true,
            progress: overallProgress,
            nextLessonId,
            completed: overallProgress >= 100,
        };
    }
};
exports.EnrollmentsService = EnrollmentsService;
exports.EnrollmentsService = EnrollmentsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(enrollment_entity_1.Enrollment.name)),
    __param(1, (0, mongoose_1.InjectModel)(course_entity_1.Course.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model])
], EnrollmentsService);
//# sourceMappingURL=enrollments.service.js.map