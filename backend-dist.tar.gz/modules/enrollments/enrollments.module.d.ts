export declare class EnrollmentsModule {
}
