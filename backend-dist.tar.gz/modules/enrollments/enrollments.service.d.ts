import { Model } from 'mongoose';
import { Enrollment, EnrollmentDocument, EnrollmentStatus } from './entities/enrollment.entity';
import { CourseDocument } from '../courses/entities/course.entity';
import { UpdateProgressDto } from './dto/update-progress.dto';
export declare class EnrollmentsService {
    private readonly enrollmentModel;
    private readonly courseModel;
    constructor(enrollmentModel: Model<EnrollmentDocument>, courseModel: Model<CourseDocument>);
    enrollUserInCourse(userId: string, courseId: string, orderId: string): Promise<Enrollment>;
    isEnrolled(userId: string, courseId: string): Promise<boolean>;
    getMyEnrolledCourses(userId: string): Promise<{
        enrollmentId: string;
        status: EnrollmentStatus;
        progress: number;
        enrolledAt: Date;
        course: {
            id: string;
            title: string;
            description: string;
            instructor: string;
            category: string;
            duration: string;
            level: string;
            thumbnail: string;
            videoUrl: string;
            skills: string[];
        };
    }[]>;
    getCurriculum(userId: string, enrollmentId: string): Promise<{
        enrollmentId: string;
        courseId: string;
        courseTitle: string;
        modules: any[];
        lessonProgress: Record<string, any>;
        currentLessonId: string;
        overallProgress: number;
    }>;
    getCurriculumByCourseId(userId: string, courseId: string): Promise<{
        enrollmentId: string;
        courseId: string;
        courseTitle: string;
        modules: any[];
        lessonProgress: Record<string, any>;
        currentLessonId: string;
        overallProgress: number;
    }>;
    updateProgress(userId: string, enrollmentId: string, dto: UpdateProgressDto): Promise<{
        success: boolean;
    }>;
    completeLesson(userId: string, enrollmentId: string, lessonId: string): Promise<{
        success: boolean;
        progress: number;
        nextLessonId: string;
        completed: boolean;
    }>;
}
