import { ConfigService } from '@nestjs/config';
export type UploadPurpose = 'video' | 'thumbnail';
export interface UploadedPart {
    partNumber: number;
    eTag: string;
}
export declare class R2Service {
    private readonly configService;
    private readonly logger;
    private readonly client;
    private readonly bucketName;
    private readonly publicBaseUrl;
    private readonly defaultExpiresIn;
    constructor(configService: ConfigService);
    private encodePathSegment;
    buildKey(purpose: UploadPurpose, originalName: string): string;
    getPublicUrl(key: string): string;
    getPresignedPutUrl(key: string, contentType: string, expiresIn?: number): Promise<string>;
    createMultipartUpload(key: string, contentType: string): Promise<{
        uploadId: string;
    }>;
    getPresignedPartUrl(key: string, uploadId: string, partNumber: number, expiresIn?: number): Promise<string>;
    completeMultipartUpload(key: string, uploadId: string, parts: UploadedPart[]): Promise<void>;
    abortMultipartUpload(key: string, uploadId: string): Promise<void>;
    deleteObject(key: string): Promise<void>;
    deleteObjectsByKeys(keys: string[]): Promise<void>;
    getSignedGetUrl(key: string, expiresIn?: number): Promise<string>;
    getObjectStream(key: string, range?: string): Promise<{
        stream: NodeJS.ReadableStream;
        contentLength?: number;
        contentRange?: string;
        contentType?: string;
        acceptRanges?: string;
        statusCode: number;
    }>;
}
