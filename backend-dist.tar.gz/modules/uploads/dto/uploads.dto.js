"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.IMAGE_CONTENT_TYPES = exports.VIDEO_CONTENT_TYPES = exports.AbortMultipartUploadDto = exports.CompleteMultipartUploadDto = exports.MultipartPartDto = exports.InitMultipartUploadDto = exports.PresignUploadDto = void 0;
exports.isAllowedContentType = isAllowedContentType;
exports.getPurposeFileExtension = getPurposeFileExtension;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
class PresignUploadDto {
}
exports.PresignUploadDto = PresignUploadDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'intro-course.mp4',
        description: 'Original file name (used to derive the stored key)',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(255),
    __metadata("design:type", String)
], PresignUploadDto.prototype, "fileName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'video/mp4',
        description: 'MIME content type of the file',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], PresignUploadDto.prototype, "contentType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'video',
        enum: ['video', 'thumbnail'],
        description: 'Purpose of the upload',
    }),
    (0, class_validator_1.IsEnum)(['video', 'thumbnail'], {
        message: 'purpose must be either "video" or "thumbnail"',
    }),
    __metadata("design:type", String)
], PresignUploadDto.prototype, "purpose", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 524288000,
        description: 'Exact file size in bytes. Enforced against the configured size limit for the purpose.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PresignUploadDto.prototype, "fileSize", void 0);
class InitMultipartUploadDto extends PresignUploadDto {
}
exports.InitMultipartUploadDto = InitMultipartUploadDto;
class MultipartPartDto {
}
exports.MultipartPartDto = MultipartPartDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1, description: 'Part number (1-based)' }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], MultipartPartDto.prototype, "partNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: '"etag-from-response-header"',
        description: 'ETag returned in the upload part response header',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.Matches)(/^[A-Za-z0-9+=\-_:.]+$/, {
        message: 'eTag contains invalid characters',
    }),
    __metadata("design:type", String)
], MultipartPartDto.prototype, "eTag", void 0);
class CompleteMultipartUploadDto {
}
exports.CompleteMultipartUploadDto = CompleteMultipartUploadDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'videos/uuid-intro-course.mp4',
        description: 'Object key returned when the multipart upload was started',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1024),
    __metadata("design:type", String)
], CompleteMultipartUploadDto.prototype, "key", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'upload-id-from-init',
        description: 'Upload ID returned when the multipart upload was started',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1024),
    __metadata("design:type", String)
], CompleteMultipartUploadDto.prototype, "uploadId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: 'Completed parts with their ETags, ordered by part number',
        type: [MultipartPartDto],
    }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ArrayMinSize)(1),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => MultipartPartDto),
    __metadata("design:type", Array)
], CompleteMultipartUploadDto.prototype, "parts", void 0);
class AbortMultipartUploadDto {
}
exports.AbortMultipartUploadDto = AbortMultipartUploadDto;
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Object key of the in-progress upload' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1024),
    __metadata("design:type", String)
], AbortMultipartUploadDto.prototype, "key", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ description: 'Upload ID to abort' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1),
    (0, class_validator_1.MaxLength)(1024),
    __metadata("design:type", String)
], AbortMultipartUploadDto.prototype, "uploadId", void 0);
const VIDEO_CONTENT_TYPES = [
    'video/mp4',
    'video/webm',
    'video/ogg',
    'video/quicktime',
    'video/x-matroska',
    'video/x-msvideo',
    'application/octet-stream',
];
exports.VIDEO_CONTENT_TYPES = VIDEO_CONTENT_TYPES;
const IMAGE_CONTENT_TYPES = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/webp',
    'image/gif',
    'image/avif',
];
exports.IMAGE_CONTENT_TYPES = IMAGE_CONTENT_TYPES;
function isAllowedContentType(purpose, contentType) {
    const normalized = (contentType || '').toLowerCase();
    return purpose === 'video'
        ? VIDEO_CONTENT_TYPES.includes(normalized)
        : IMAGE_CONTENT_TYPES.includes(normalized);
}
function getPurposeFileExtension(purpose) {
    return purpose === 'video' ? 'video' : 'image';
}
//# sourceMappingURL=uploads.dto.js.map