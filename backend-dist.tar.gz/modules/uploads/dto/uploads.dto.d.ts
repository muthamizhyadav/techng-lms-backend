import { UploadPurpose } from '../r2.service';
export declare class PresignUploadDto {
    fileName: string;
    contentType: string;
    purpose: UploadPurpose;
    fileSize?: number;
}
export declare class InitMultipartUploadDto extends PresignUploadDto {
}
export declare class MultipartPartDto {
    partNumber: number;
    eTag: string;
}
export declare class CompleteMultipartUploadDto {
    key: string;
    uploadId: string;
    parts: MultipartPartDto[];
}
export declare class AbortMultipartUploadDto {
    key: string;
    uploadId: string;
}
declare const VIDEO_CONTENT_TYPES: string[];
declare const IMAGE_CONTENT_TYPES: string[];
export declare function isAllowedContentType(purpose: UploadPurpose, contentType: string): boolean;
export { VIDEO_CONTENT_TYPES, IMAGE_CONTENT_TYPES };
export declare function getPurposeFileExtension(purpose: UploadPurpose): string;
