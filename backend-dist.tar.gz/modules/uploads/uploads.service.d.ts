import { ConfigService } from '@nestjs/config';
import { R2Service } from './r2.service';
import { PresignUploadDto, CompleteMultipartUploadDto, AbortMultipartUploadDto } from './dto/uploads.dto';
export interface PresignUploadResult {
    uploadUrl: string;
    publicUrl: string;
    key: string;
    expiresIn: number;
}
export interface InitMultipartResult {
    key: string;
    uploadId: string;
    publicUrl: string;
    expiresIn: number;
}
export interface PartPresignResult {
    partUrl: string;
    partNumber: number;
    expiresIn: number;
}
export interface CompleteMultipartResult {
    publicUrl: string;
    key: string;
}
export declare class UploadsService {
    private readonly r2Service;
    private readonly configService;
    private readonly maxVideoSizeBytes;
    private readonly maxThumbnailSizeBytes;
    private readonly uploadExpiresIn;
    constructor(r2Service: R2Service, configService: ConfigService);
    private validateUpload;
    getPresignedUpload(dto: PresignUploadDto): Promise<PresignUploadResult>;
    initMultipart(dto: PresignUploadDto): Promise<InitMultipartResult>;
    getPartPresign(key: string, uploadId: string, partNumber: number): Promise<PartPresignResult>;
    completeMultipart(dto: CompleteMultipartUploadDto): Promise<CompleteMultipartResult>;
    abortMultipart(dto: AbortMultipartUploadDto): Promise<void>;
    streamObject(key: string, range?: string): Promise<{
        stream: NodeJS.ReadableStream;
        contentLength?: number;
        contentRange?: string;
        contentType?: string;
        acceptRanges?: string;
        statusCode: number;
    }>;
    getViewUrl(key: string): Promise<string>;
}
