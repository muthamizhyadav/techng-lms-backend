"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var R2Service_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.R2Service = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const uuid_1 = require("uuid");
let R2Service = R2Service_1 = class R2Service {
    constructor(configService) {
        this.configService = configService;
        this.logger = new common_1.Logger(R2Service_1.name);
        const endpoint = this.configService.get('storage.endpoint');
        const accessKeyId = this.configService.get('storage.accessKeyId');
        const secretAccessKey = this.configService.get('storage.secretAccessKey');
        const region = this.configService.get('storage.region') || 'auto';
        if (!endpoint || !accessKeyId || !secretAccessKey) {
            this.logger.warn('R2 storage is not fully configured. Upload features will be unavailable.');
        }
        this.client = new client_s3_1.S3Client({
            region,
            endpoint,
            forcePathStyle: true,
            credentials: {
                accessKeyId,
                secretAccessKey,
            },
        });
        this.bucketName =
            this.configService.get('storage.bucketName') || 'techng-lms';
        this.publicBaseUrl = this.configService
            .get('storage.publicBaseUrl')
            ?.replace(/\/+$/, '');
        this.defaultExpiresIn =
            this.configService.get('storage.uploadExpiresIn') || 900;
    }
    encodePathSegment(segment) {
        return encodeURIComponent(segment);
    }
    buildKey(purpose, originalName) {
        const extMatch = /\.([a-zA-Z0-9]+)$/.exec(originalName || '');
        const ext = extMatch ? extMatch[1].toLowerCase() : 'bin';
        const safeBase = (originalName || 'file')
            .replace(/\.[a-zA-Z0-9]+$/, '')
            .replace(/[^a-zA-Z0-9-_]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 80) || 'file';
        const folder = purpose === 'video' ? 'videos' : 'thumbnails';
        return `${folder}/${(0, uuid_1.v4)()}-${safeBase}.${ext}`;
    }
    getPublicUrl(key) {
        if (this.publicBaseUrl &&
            this.publicBaseUrl.startsWith('http') &&
            !this.publicBaseUrl.includes('<HASH>')) {
            const encodedKey = key
                .split('/')
                .map((segment) => this.encodePathSegment(segment))
                .join('/');
            return `${this.publicBaseUrl}/${encodedKey}`;
        }
        return `/api/v1/uploads/stream?key=${encodeURIComponent(key)}`;
    }
    async getPresignedPutUrl(key, contentType, expiresIn = this.defaultExpiresIn) {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: this.bucketName,
            Key: key,
            ContentType: contentType,
        });
        return (0, s3_request_presigner_1.getSignedUrl)(this.client, command, { expiresIn });
    }
    async createMultipartUpload(key, contentType) {
        const command = new client_s3_1.CreateMultipartUploadCommand({
            Bucket: this.bucketName,
            Key: key,
            ContentType: contentType,
        });
        const result = await this.client.send(command);
        return { uploadId: result.UploadId };
    }
    async getPresignedPartUrl(key, uploadId, partNumber, expiresIn = this.defaultExpiresIn) {
        const command = new client_s3_1.UploadPartCommand({
            Bucket: this.bucketName,
            Key: key,
            UploadId: uploadId,
            PartNumber: partNumber,
        });
        return (0, s3_request_presigner_1.getSignedUrl)(this.client, command, { expiresIn });
    }
    async completeMultipartUpload(key, uploadId, parts) {
        const command = new client_s3_1.CompleteMultipartUploadCommand({
            Bucket: this.bucketName,
            Key: key,
            UploadId: uploadId,
            MultipartUpload: {
                Parts: parts.map((part) => ({
                    PartNumber: part.partNumber,
                    ETag: part.eTag,
                })),
            },
        });
        await this.client.send(command);
    }
    async abortMultipartUpload(key, uploadId) {
        const command = new client_s3_1.AbortMultipartUploadCommand({
            Bucket: this.bucketName,
            Key: key,
            UploadId: uploadId,
        });
        await this.client.send(command).catch((err) => {
            const message = err?.message ?? 'Unknown error';
            this.logger.warn(`Failed to abort multipart upload "${uploadId}": ${message}`);
        });
    }
    async deleteObject(key) {
        const command = new client_s3_1.DeleteObjectCommand({
            Bucket: this.bucketName,
            Key: key,
        });
        await this.client.send(command);
    }
    async deleteObjectsByKeys(keys) {
        await Promise.all(keys.filter(Boolean).map((key) => this.deleteObject(key)));
    }
    async getSignedGetUrl(key, expiresIn = 86400) {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: this.bucketName,
            Key: key,
        });
        return (0, s3_request_presigner_1.getSignedUrl)(this.client, command, { expiresIn });
    }
    async getObjectStream(key, range) {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: this.bucketName,
            Key: key,
            Range: range,
        });
        const response = await this.client.send(command);
        return {
            stream: response.Body,
            contentLength: response.ContentLength,
            contentRange: response.ContentRange,
            contentType: response.ContentType || 'video/mp4',
            acceptRanges: response.AcceptRanges || 'bytes',
            statusCode: range ? 206 : 200,
        };
    }
};
exports.R2Service = R2Service;
exports.R2Service = R2Service = R2Service_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], R2Service);
//# sourceMappingURL=r2.service.js.map