import type { Response } from 'express';
import { UploadsService } from './uploads.service';
import { PresignUploadDto, CompleteMultipartUploadDto, AbortMultipartUploadDto } from './dto/uploads.dto';
export declare class UploadsController {
    private readonly uploadsService;
    constructor(uploadsService: UploadsService);
    presign(dto: PresignUploadDto): Promise<import("./uploads.service").PresignUploadResult>;
    initMultipart(dto: PresignUploadDto): Promise<import("./uploads.service").InitMultipartResult>;
    partPresign(uploadId: string, partNumber: number, key: string): Promise<import("./uploads.service").PartPresignResult>;
    complete(uploadId: string, dto: CompleteMultipartUploadDto): Promise<import("./uploads.service").CompleteMultipartResult>;
    abort(uploadId: string, dto: AbortMultipartUploadDto): Promise<{
        message: string;
    }>;
    stream(key: string, range: string | undefined, res: Response): Promise<Response<any, Record<string, any>>>;
    getViewUrl(key: string): Promise<{
        url: string;
    }>;
}
