"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const uploads_service_1 = require("./uploads.service");
const uploads_dto_1 = require("./dto/uploads.dto");
let UploadsController = class UploadsController {
    constructor(uploadsService) {
        this.uploadsService = uploadsService;
    }
    async presign(dto) {
        return this.uploadsService.getPresignedUpload(dto);
    }
    async initMultipart(dto) {
        return this.uploadsService.initMultipart(dto);
    }
    async partPresign(uploadId, partNumber, key) {
        return this.uploadsService.getPartPresign(key, uploadId, partNumber);
    }
    async complete(uploadId, dto) {
        return this.uploadsService.completeMultipart({
            ...dto,
            uploadId,
        });
    }
    async abort(uploadId, dto) {
        await this.uploadsService.abortMultipart({
            ...dto,
            uploadId,
        });
        return { message: 'Multipart upload aborted' };
    }
    async stream(key, range, res) {
        if (!key) {
            return res.status(400).send('Object key is required');
        }
        try {
            const data = await this.uploadsService.streamObject(key, range);
            res.status(data.statusCode);
            if (data.contentType)
                res.setHeader('Content-Type', data.contentType);
            if (data.acceptRanges)
                res.setHeader('Accept-Ranges', data.acceptRanges);
            if (data.contentLength)
                res.setHeader('Content-Length', data.contentLength);
            if (data.contentRange)
                res.setHeader('Content-Range', data.contentRange);
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.setHeader('Access-Control-Allow-Headers', 'Range, Accept-Ranges, Content-Range');
            res.setHeader('Cache-Control', 'public, max-age=3600');
            data.stream.pipe(res);
        }
        catch (err) {
            return res
                .status(err?.$metadata?.httpStatusCode || 404)
                .send(err?.message || 'Failed to stream object');
        }
    }
    async getViewUrl(key) {
        if (!key)
            return { url: '' };
        const url = await this.uploadsService.getViewUrl(key);
        return { url };
    }
};
exports.UploadsController = UploadsController;
__decorate([
    (0, common_1.Post)('presign'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get presigned upload URL (Admin only)',
        description: 'Returns a presigned PUT URL to upload a thumbnail or small file directly to R2 from the browser.',
    }),
    (0, swagger_1.ApiBody)({ type: uploads_dto_1.PresignUploadDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Presigned URL generated',
        schema: {
            example: {
                uploadUrl: 'https://.../videos/uuid.mp4?X-Amz-...',
                publicUrl: 'https://pub-...r2.dev/videos/uuid.mp4',
                key: 'videos/uuid.mp4',
                expiresIn: 900,
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Invalid content type or size' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [uploads_dto_1.PresignUploadDto]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "presign", null);
__decorate([
    (0, common_1.Post)('multipart'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Initialize a multipart upload (Admin only)',
        description: 'Starts a multipart upload on R2 for large video files. Upload parts directly to R2 then call complete.',
    }),
    (0, swagger_1.ApiBody)({ type: uploads_dto_1.PresignUploadDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Multipart upload initialized',
        schema: {
            example: {
                key: 'videos/uuid.mp4',
                uploadId: 'a1b2c3...',
                publicUrl: 'https://pub-...r2.dev/videos/uuid.mp4',
                expiresIn: 900,
            },
        },
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [uploads_dto_1.PresignUploadDto]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "initMultipart", null);
__decorate([
    (0, common_1.Get)('multipart/:uploadId/parts/:partNumber/presign'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get presigned URL for a multipart part (Admin only)',
    }),
    (0, swagger_1.ApiParam)({ name: 'uploadId', description: 'Multipart upload ID' }),
    (0, swagger_1.ApiParam)({
        name: 'partNumber',
        description: '1-based part number',
        example: 1,
    }),
    (0, swagger_1.ApiQuery)({
        name: 'key',
        required: true,
        description: 'Object key from the init response',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Presigned part URL generated',
        schema: {
            example: {
                partUrl: 'https://.../videos/uuid.mp4?partNumber=1&X-Amz-...',
                partNumber: 1,
                expiresIn: 900,
            },
        },
    }),
    __param(0, (0, common_1.Param)('uploadId')),
    __param(1, (0, common_1.Param)('partNumber', common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, String]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "partPresign", null);
__decorate([
    (0, common_1.Post)('multipart/:uploadId/complete'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Complete a multipart upload (Admin only)',
        description: 'Finalizes a multipart upload after every part has been uploaded. Returns the public URL.',
    }),
    (0, swagger_1.ApiParam)({ name: 'uploadId', description: 'Multipart upload ID' }),
    (0, swagger_1.ApiBody)({ type: uploads_dto_1.CompleteMultipartUploadDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Multipart upload completed',
        schema: {
            example: {
                publicUrl: 'https://pub-...r2.dev/videos/uuid.mp4',
                key: 'videos/uuid.mp4',
            },
        },
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid parts or completion failed',
    }),
    __param(0, (0, common_1.Param)('uploadId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, uploads_dto_1.CompleteMultipartUploadDto]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "complete", null);
__decorate([
    (0, common_1.Post)('multipart/:uploadId/abort'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Abort a multipart upload (Admin only)',
        description: 'Cancels an in-progress multipart upload and frees its parts.',
    }),
    (0, swagger_1.ApiParam)({ name: 'uploadId', description: 'Multipart upload ID' }),
    (0, swagger_1.ApiBody)({ type: uploads_dto_1.AbortMultipartUploadDto }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Multipart upload aborted' }),
    __param(0, (0, common_1.Param)('uploadId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, uploads_dto_1.AbortMultipartUploadDto]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "abort", null);
__decorate([
    (0, common_1.Get)('stream'),
    (0, swagger_1.ApiOperation)({
        summary: 'Stream video or asset with HTTP Range and 206 Partial Content support',
    }),
    (0, swagger_1.ApiQuery)({ name: 'key', required: true, description: 'Storage object key' }),
    __param(0, (0, common_1.Query)('key')),
    __param(1, (0, common_1.Headers)('range')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "stream", null);
__decorate([
    (0, common_1.Get)('view-url'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get signed/public view URL for a storage key',
    }),
    (0, swagger_1.ApiQuery)({ name: 'key', required: true, description: 'Storage object key' }),
    __param(0, (0, common_1.Query)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UploadsController.prototype, "getViewUrl", null);
exports.UploadsController = UploadsController = __decorate([
    (0, swagger_1.ApiTags)('📤 Uploads'),
    (0, common_1.Controller)('uploads'),
    __metadata("design:paramtypes", [uploads_service_1.UploadsService])
], UploadsController);
//# sourceMappingURL=uploads.controller.js.map