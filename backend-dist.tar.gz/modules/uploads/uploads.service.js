"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadsService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const r2_service_1 = require("./r2.service");
const uploads_dto_1 = require("./dto/uploads.dto");
let UploadsService = class UploadsService {
    constructor(r2Service, configService) {
        this.r2Service = r2Service;
        this.configService = configService;
        this.maxVideoSizeBytes =
            (this.configService.get('storage.maxVideoSizeMb') || 4096) *
                1024 *
                1024;
        this.maxThumbnailSizeBytes =
            (this.configService.get('storage.maxThumbnailSizeMb') || 10) *
                1024 *
                1024;
        this.uploadExpiresIn =
            this.configService.get('storage.uploadExpiresIn') || 900;
    }
    validateUpload(dto) {
        if (!(0, uploads_dto_1.isAllowedContentType)(dto.purpose, dto.contentType)) {
            throw new common_1.BadRequestException(dto.purpose === 'video'
                ? 'Invalid video type. Supported: MP4, WebM, OGG, MOV, MKV, AVI'
                : 'Invalid image type. Supported: JPG, PNG, WebP, GIF, AVIF');
        }
        if (dto.fileSize !== undefined) {
            const maxBytes = dto.purpose === 'video'
                ? this.maxVideoSizeBytes
                : this.maxThumbnailSizeBytes;
            if (dto.fileSize > maxBytes) {
                const maxMb = maxBytes / 1024 / 1024;
                throw new common_1.BadRequestException(`File exceeds the ${maxMb} MB size limit for ${dto.purpose} uploads`);
            }
        }
    }
    async getPresignedUpload(dto) {
        this.validateUpload(dto);
        const key = this.r2Service.buildKey(dto.purpose, dto.fileName);
        const uploadUrl = await this.r2Service.getPresignedPutUrl(key, dto.contentType);
        return {
            uploadUrl,
            publicUrl: this.r2Service.getPublicUrl(key),
            key,
            expiresIn: this.uploadExpiresIn,
        };
    }
    async initMultipart(dto) {
        this.validateUpload(dto);
        const key = this.r2Service.buildKey(dto.purpose, dto.fileName);
        const { uploadId } = await this.r2Service.createMultipartUpload(key, dto.contentType);
        return {
            key,
            uploadId,
            publicUrl: this.r2Service.getPublicUrl(key),
            expiresIn: this.uploadExpiresIn,
        };
    }
    async getPartPresign(key, uploadId, partNumber) {
        const partUrl = await this.r2Service.getPresignedPartUrl(key, uploadId, partNumber);
        return { partUrl, partNumber, expiresIn: this.uploadExpiresIn };
    }
    async completeMultipart(dto) {
        const parts = [...dto.parts].sort((a, b) => a.partNumber - b.partNumber);
        const expectedPartNumbers = parts.map((part) => part.partNumber);
        const hasGaps = expectedPartNumbers.some((num, index) => num !== index + 1);
        if (hasGaps) {
            throw new common_1.BadRequestException('Multipart parts must be consecutive and start at part number 1');
        }
        try {
            await this.r2Service.completeMultipartUpload(dto.key, dto.uploadId, parts);
        }
        catch (err) {
            const message = err?.message ?? 'Unknown error';
            throw new common_1.BadRequestException(`Failed to finalize multipart upload: ${message}`);
        }
        return {
            publicUrl: this.r2Service.getPublicUrl(dto.key),
            key: dto.key,
        };
    }
    async abortMultipart(dto) {
        await this.r2Service.abortMultipartUpload(dto.key, dto.uploadId);
    }
    async streamObject(key, range) {
        return this.r2Service.getObjectStream(key, range);
    }
    async getViewUrl(key) {
        const publicUrl = this.r2Service.getPublicUrl(key);
        if (publicUrl && publicUrl.startsWith('http') && !publicUrl.includes('<HASH>')) {
            return publicUrl;
        }
        return this.r2Service.getSignedGetUrl(key);
    }
};
exports.UploadsService = UploadsService;
exports.UploadsService = UploadsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [r2_service_1.R2Service,
        config_1.ConfigService])
], UploadsService);
//# sourceMappingURL=uploads.service.js.map