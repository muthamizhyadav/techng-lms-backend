"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginActivityService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const login_activity_entity_1 = require("./entities/login-activity.entity");
const uuid_util_1 = require("../../common/utils/uuid.util");
let LoginActivityService = class LoginActivityService {
    constructor(activityModel) {
        this.activityModel = activityModel;
    }
    parseUserAgent(ua) {
        if (!ua) {
            return { device: 'Unknown Device', browser: 'Browser', os: 'Unknown OS' };
        }
        let os = 'Unknown OS';
        if (/windows/i.test(ua))
            os = 'Windows';
        else if (/macintosh|mac os x/i.test(ua))
            os = 'macOS';
        else if (/android/i.test(ua))
            os = 'Android';
        else if (/iphone|ipad|ipod/i.test(ua))
            os = 'iOS';
        else if (/linux/i.test(ua))
            os = 'Linux';
        let browser = 'Unknown Browser';
        if (/edg/i.test(ua))
            browser = 'Edge';
        else if (/chrome/i.test(ua) && !/chromium|edg/i.test(ua))
            browser = 'Chrome';
        else if (/safari/i.test(ua) && !/chrome/i.test(ua))
            browser = 'Safari';
        else if (/firefox/i.test(ua))
            browser = 'Firefox';
        else if (/opera|opr/i.test(ua))
            browser = 'Opera';
        let device = 'Desktop';
        if (/mobile/i.test(ua))
            device = 'Mobile';
        else if (/tablet|ipad/i.test(ua))
            device = 'Tablet';
        return { device, browser, os };
    }
    async recordLogin(params) {
        const parsed = this.parseUserAgent(params.userAgent);
        const doc = await this.activityModel.create({
            _id: (0, uuid_util_1.generateUuid)(),
            userId: params.userId,
            userRole: params.userRole,
            email: params.email.toLowerCase(),
            name: params.name || '',
            ipAddress: params.ipAddress || null,
            device: params.device || parsed.device,
            browser: params.browser || parsed.browser,
            os: params.os || parsed.os,
            status: params.status || 'success',
            failureReason: params.failureReason || null,
            loginAt: new Date(),
        });
        return doc.toJSON();
    }
    async findRecent(query) {
        const page = Math.max(1, Number(query.page) || 1);
        const limit = Math.max(1, Math.min(100, Number(query.limit) || 20));
        const skip = (page - 1) * limit;
        const filter = {};
        if (query.role && query.role !== 'all') {
            filter.userRole = query.role;
        }
        if (query.status && query.status !== 'all') {
            filter.status = query.status;
        }
        if (query.search && query.search.trim()) {
            const regex = { $regex: query.search.trim(), $options: 'i' };
            filter.$or = [{ email: regex }, { name: regex }, { ipAddress: regex }];
        }
        const [data, total] = await Promise.all([
            this.activityModel
                .find(filter)
                .sort({ loginAt: -1 })
                .skip(skip)
                .limit(limit)
                .exec(),
            this.activityModel.countDocuments(filter),
        ]);
        return {
            data: data.map((d) => d.toJSON()),
            total,
            page,
            limit,
        };
    }
    async getLatestForUser(userId) {
        const item = await this.activityModel
            .findOne({ userId, status: 'success' })
            .sort({ loginAt: -1 })
            .exec();
        return item ? item.toJSON() : null;
    }
};
exports.LoginActivityService = LoginActivityService;
exports.LoginActivityService = LoginActivityService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(login_activity_entity_1.LoginActivity.name)),
    __metadata("design:paramtypes", [mongoose_2.Model])
], LoginActivityService);
//# sourceMappingURL=login-activity.service.js.map