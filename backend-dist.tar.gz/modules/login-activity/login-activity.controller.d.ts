import { LoginActivityService, LoginActivityQuery } from './login-activity.service';
export declare class LoginActivityController {
    private readonly activityService;
    constructor(activityService: LoginActivityService);
    getRecentLogins(query: LoginActivityQuery): Promise<{
        data: import("./entities/login-activity.entity").LoginActivity[];
        total: number;
        page: number;
        limit: number;
    }>;
}
