"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginActivityController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const login_activity_service_1 = require("./login-activity.service");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
let LoginActivityController = class LoginActivityController {
    constructor(activityService) {
        this.activityService = activityService;
    }
    async getRecentLogins(query) {
        return this.activityService.findRecent(query);
    }
};
exports.LoginActivityController = LoginActivityController;
__decorate([
    (0, common_1.Get)('logins'),
    (0, swagger_1.ApiOperation)({ summary: 'Get recent login activity across admins, trainers, and students' }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number }),
    (0, swagger_1.ApiQuery)({ name: 'role', required: false, type: String, description: 'admin, trainer, student' }),
    (0, swagger_1.ApiQuery)({ name: 'search', required: false, type: String }),
    (0, swagger_1.ApiQuery)({ name: 'status', required: false, type: String }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], LoginActivityController.prototype, "getRecentLogins", null);
exports.LoginActivityController = LoginActivityController = __decorate([
    (0, swagger_1.ApiTags)('🛡️ Login Activity (Admin)'),
    (0, common_1.Controller)('admin/activity'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    __metadata("design:paramtypes", [login_activity_service_1.LoginActivityService])
], LoginActivityController);
//# sourceMappingURL=login-activity.controller.js.map