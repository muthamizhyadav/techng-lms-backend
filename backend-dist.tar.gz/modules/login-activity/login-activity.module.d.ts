export declare class LoginActivityModule {
}
