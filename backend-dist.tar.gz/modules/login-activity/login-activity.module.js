"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginActivityModule = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const login_activity_entity_1 = require("./entities/login-activity.entity");
const login_activity_service_1 = require("./login-activity.service");
const login_activity_controller_1 = require("./login-activity.controller");
let LoginActivityModule = class LoginActivityModule {
};
exports.LoginActivityModule = LoginActivityModule;
exports.LoginActivityModule = LoginActivityModule = __decorate([
    (0, common_1.Module)({
        imports: [
            mongoose_1.MongooseModule.forFeature([
                { name: login_activity_entity_1.LoginActivity.name, schema: login_activity_entity_1.LoginActivitySchema },
            ]),
        ],
        controllers: [login_activity_controller_1.LoginActivityController],
        providers: [login_activity_service_1.LoginActivityService],
        exports: [login_activity_service_1.LoginActivityService],
    })
], LoginActivityModule);
//# sourceMappingURL=login-activity.module.js.map