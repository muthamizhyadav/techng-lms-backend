import { Model } from 'mongoose';
import { LoginActivity, LoginActivityDocument } from './entities/login-activity.entity';
export interface RecordLoginParams {
    userId: string;
    userRole: string;
    email: string;
    name?: string;
    ipAddress?: string;
    userAgent?: string;
    device?: string;
    browser?: string;
    os?: string;
    status?: 'success' | 'failed' | 'conflict_blocked';
    failureReason?: string;
}
export interface LoginActivityQuery {
    page?: number;
    limit?: number;
    role?: string;
    search?: string;
    status?: string;
}
export declare class LoginActivityService {
    private readonly activityModel;
    constructor(activityModel: Model<LoginActivityDocument>);
    private parseUserAgent;
    recordLogin(params: RecordLoginParams): Promise<LoginActivity>;
    findRecent(query: LoginActivityQuery): Promise<{
        data: LoginActivity[];
        total: number;
        page: number;
        limit: number;
    }>;
    getLatestForUser(userId: string): Promise<LoginActivity | null>;
}
