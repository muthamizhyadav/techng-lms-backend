import { HydratedDocument } from 'mongoose';
export type LoginActivityDocument = HydratedDocument<LoginActivity>;
export declare class LoginActivity {
    _id: string;
    id: string;
    userId: string;
    userRole: string;
    email: string;
    name: string;
    ipAddress?: string;
    device?: string;
    browser?: string;
    os?: string;
    loginAt: Date;
    status: 'success' | 'failed' | 'conflict_blocked';
    failureReason?: string;
}
export declare const LoginActivitySchema: import("mongoose").Schema<LoginActivity, import("mongoose").Model<LoginActivity, any, any, any, any, any, LoginActivity>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    userId?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    userRole?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    email?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    name?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    ipAddress?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    device?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    browser?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    os?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    loginAt?: import("mongoose").SchemaDefinitionProperty<Date, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<"success" | "failed" | "conflict_blocked", LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    failureReason?: import("mongoose").SchemaDefinitionProperty<string, LoginActivity, import("mongoose").Document<unknown, {}, LoginActivity, {}, import("mongoose").DefaultSchemaOptions> & LoginActivity & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, LoginActivity>;
