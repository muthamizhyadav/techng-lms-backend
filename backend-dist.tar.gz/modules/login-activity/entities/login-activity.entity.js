"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginActivitySchema = exports.LoginActivity = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const uuid_util_1 = require("../../../common/utils/uuid.util");
let LoginActivity = class LoginActivity {
};
exports.LoginActivity = LoginActivity;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], LoginActivity.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, index: true }),
    __metadata("design:type", String)
], LoginActivity.prototype, "userId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, index: true }),
    __metadata("design:type", String)
], LoginActivity.prototype, "userRole", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, lowercase: true, trim: true, index: true }),
    __metadata("design:type", String)
], LoginActivity.prototype, "email", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: '' }),
    __metadata("design:type", String)
], LoginActivity.prototype, "name", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], LoginActivity.prototype, "ipAddress", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 'Desktop' }),
    __metadata("design:type", String)
], LoginActivity.prototype, "device", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 'Chrome' }),
    __metadata("design:type", String)
], LoginActivity.prototype, "browser", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: 'Windows' }),
    __metadata("design:type", String)
], LoginActivity.prototype, "os", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: Date.now, index: true }),
    __metadata("design:type", Date)
], LoginActivity.prototype, "loginAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({ enum: ['success', 'failed', 'conflict_blocked'], default: 'success' }),
    __metadata("design:type", String)
], LoginActivity.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], LoginActivity.prototype, "failureReason", void 0);
exports.LoginActivity = LoginActivity = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'login_activities',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                return ret;
            },
        },
        toObject: {
            virtuals: true,
            versionKey: false,
        },
    })
], LoginActivity);
exports.LoginActivitySchema = mongoose_1.SchemaFactory.createForClass(LoginActivity);
exports.LoginActivitySchema.index({ loginAt: -1 });
exports.LoginActivitySchema.index({ userRole: 1, loginAt: -1 });
//# sourceMappingURL=login-activity.entity.js.map