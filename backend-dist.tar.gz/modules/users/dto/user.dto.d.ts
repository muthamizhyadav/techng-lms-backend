import { UserStatus } from "../../../shared/enums/role.enum";
export declare class CreateUserDto {
    email: string;
    password: string;
    firstName: string;
    lastName?: string;
    phone?: string;
    dateOfBirth?: Date;
    gender?: string;
    address?: string;
    city?: string;
    state?: string;
    country?: string;
    pincode?: string;
    highestQualification?: string;
    college?: string;
    yearOfPassing?: number;
    currentCompany?: string;
    jobRole?: string;
    experienceYears?: number;
    preferredLanguage?: string;
    emailNotifications?: boolean;
    smsNotifications?: boolean;
    pushNotifications?: boolean;
}
declare const UpdateUserDto_base: import("@nestjs/common").Type<Partial<Omit<CreateUserDto, "email" | "password">>>;
export declare class UpdateUserDto extends UpdateUserDto_base {
}
export declare class AdminUpdateUserDto extends UpdateUserDto {
    email?: string;
}
export declare class UpdatePasswordDto {
    currentPassword: string;
    newPassword: string;
}
export declare class UserResponseDto {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    fullName: string;
    phone: string;
    experienceYears: number;
    avatar: string;
    status: UserStatus;
    emailVerified: boolean;
    phoneVerified: boolean;
    profileCompletionPercentage: number;
    isProfileComplete: boolean;
    preferredLanguage: string;
    createdAt: Date;
    updatedAt: Date;
}
export {};
