import { OnModuleInit } from '@nestjs/common';
import { Model } from 'mongoose';
import { ConfigService } from '@nestjs/config';
import { User, UserDocument, UserSession } from './entities/user.entity';
import { UserStatus } from "../../shared/enums/role.enum";
import { CreateUserDto, UpdatePasswordDto, AdminUpdateUserDto } from './dto/user.dto';
export declare class UsersService implements OnModuleInit {
    private readonly userModel;
    private readonly configService;
    constructor(userModel: Model<UserDocument>, configService: ConfigService);
    onModuleInit(): Promise<void>;
    create(createUserDto: CreateUserDto): Promise<User>;
    private mapDuplicateKeyError;
    findAll(page?: number, limit?: number): Promise<{
        data: User[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<UserDocument>;
    findByEmail(email: string): Promise<UserDocument | null>;
    findByEmailWithPassword(email: string): Promise<UserDocument | null>;
    findByGoogleId(googleId: string): Promise<UserDocument | null>;
    createGoogleUser(data: {
        googleId: string;
        email: string;
        firstName: string;
        lastName: string;
        avatar?: string;
    }): Promise<User>;
    update(id: string, updateUserDto: AdminUpdateUserDto): Promise<User>;
    updatePassword(id: string, updatePasswordDto: UpdatePasswordDto): Promise<void>;
    remove(id: string): Promise<void>;
    setPasswordResetToken(userId: string, tokenHash: string, expiresAt: Date): Promise<void>;
    findByPasswordResetToken(tokenHash: string): Promise<UserDocument | null>;
    resetPassword(userId: string, hashedPassword: string): Promise<void>;
    updateRefreshToken(userId: string, refreshToken: string | null): Promise<void>;
    verifyRefreshToken(userId: string, refreshToken: string): Promise<boolean>;
    private hashToken;
    updateLastLogin(userId: string): Promise<void>;
    getActiveSessions(userId: string): Promise<UserSession[]>;
    startSession(userId: string, session: UserSession, keepOtherSessions?: boolean): Promise<void>;
    touchSession(userId: string, sessionId: string, expiresAt?: Date): Promise<void>;
    revokeSession(userId: string, sessionId: string): Promise<boolean>;
    revokeAllSessions(userId: string): Promise<void>;
    isSessionActive(userId: string, sessionId: string): Promise<boolean>;
    verifyEmail(userId: string): Promise<void>;
    verifyPhone(userId: string): Promise<void>;
    updateStatus(userId: string, status: UserStatus): Promise<void>;
    getProfileCompletion(userId: string): Promise<{
        percentage: number;
        isComplete: boolean;
        missingFields: string[];
    }>;
    private calculateProfileCompletion;
    private getMissingProfileFields;
    countByStatus(): Promise<{
        total: number;
        active: number;
        inactive: number;
        pending: number;
        suspended: number;
    }>;
}
