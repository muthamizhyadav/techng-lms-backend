"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
const user_entity_1 = require("./entities/user.entity");
const password_util_1 = require("../../common/utils/password.util");
const normalize_util_1 = require("../../common/utils/normalize.util");
const role_enum_1 = require("../../shared/enums/role.enum");
let UsersService = class UsersService {
    constructor(userModel, configService) {
        this.userModel = userModel;
        this.configService = configService;
    }
    async onModuleInit() {
        try {
            await this.userModel.collection.createIndex({ phone: 1 }, {
                unique: true,
                partialFilterExpression: { phone: { $type: 'string' } },
            });
        }
        catch (error) {
            console.warn('[UsersService] Could not ensure unique phone index (duplicate phone data may exist):', error.message);
        }
    }
    async create(createUserDto) {
        const email = (0, normalize_util_1.normalizeEmail)(createUserDto.email);
        const phone = (0, normalize_util_1.compactPhone)(createUserDto.phone);
        const existingUser = await this.userModel.findOne({ email });
        if (existingUser) {
            throw new common_1.ConflictException('Email address is already registered');
        }
        if (phone) {
            const phoneExists = await this.userModel.findOne({
                phone: (0, normalize_util_1.phoneDuplicateRegex)(phone),
            });
            if (phoneExists) {
                throw new common_1.ConflictException('Phone number is already registered');
            }
        }
        const hashedPassword = await password_util_1.PasswordUtil.hash(createUserDto.password, this.configService.get('app.bcryptRounds'));
        const profileCompletionPercentage = this.calculateProfileCompletion({
            ...createUserDto,
        });
        let savedUser;
        try {
            savedUser = await this.userModel.create({
                ...createUserDto,
                email,
                phone,
                password: hashedPassword,
                status: role_enum_1.UserStatus.ACTIVE,
                profileCompletionPercentage,
                isProfileComplete: profileCompletionPercentage >= 80,
            });
        }
        catch (error) {
            throw this.mapDuplicateKeyError(error);
        }
        return savedUser.toJSON();
    }
    mapDuplicateKeyError(error) {
        const mongoError = error;
        if (mongoError?.code === 11000) {
            const field = mongoError.keyPattern?.phone
                ? 'Phone number'
                : 'Email address';
            return new common_1.ConflictException(`${field} is already registered`);
        }
        return error;
    }
    async findAll(page = 1, limit = 10) {
        const filter = { deletedAt: null };
        const [data, total] = await Promise.all([
            this.userModel
                .find(filter)
                .select('email firstName lastName phone experienceYears avatar status emailVerified phoneVerified profileCompletionPercentage isProfileComplete createdAt updatedAt')
                .sort({ createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .exec(),
            this.userModel.countDocuments(filter),
        ]);
        return { data, total, page, limit };
    }
    async findOne(id) {
        const user = await this.userModel.findOne({ _id: id, deletedAt: null });
        if (!user) {
            throw new common_1.NotFoundException(`User with ID "${id}" not found`);
        }
        return user;
    }
    async findByEmail(email) {
        return this.userModel.findOne({
            email: (0, normalize_util_1.normalizeEmail)(email),
            deletedAt: null,
        });
    }
    async findByEmailWithPassword(email) {
        return this.userModel.findOne({
            email: (0, normalize_util_1.normalizeEmail)(email),
            deletedAt: null,
        });
    }
    async findByGoogleId(googleId) {
        return this.userModel.findOne({ googleId, deletedAt: null });
    }
    async createGoogleUser(data) {
        const existingUser = await this.findByEmail(data.email);
        if (existingUser) {
            existingUser.googleId = data.googleId;
            if (data.avatar && !existingUser.avatar) {
                existingUser.avatar = data.avatar;
            }
            existingUser.emailVerified = true;
            if (existingUser.status !== role_enum_1.UserStatus.ACTIVE) {
                existingUser.status = role_enum_1.UserStatus.ACTIVE;
            }
            const saved = await existingUser.save();
            return saved.toJSON();
        }
        const savedUser = await this.userModel.create({
            googleId: data.googleId,
            email: data.email,
            firstName: data.firstName,
            lastName: data.lastName,
            avatar: data.avatar,
            emailVerified: true,
            status: role_enum_1.UserStatus.ACTIVE,
            profileCompletionPercentage: this.calculateProfileCompletion({
                firstName: data.firstName,
                lastName: data.lastName,
                avatar: data.avatar,
            }),
            isProfileComplete: false,
        });
        return savedUser.toJSON();
    }
    async update(id, updateUserDto) {
        const user = await this.findOne(id);
        if (updateUserDto.email) {
            const email = (0, normalize_util_1.normalizeEmail)(updateUserDto.email);
            if (email !== (0, normalize_util_1.normalizeEmail)(user.email)) {
                const emailExists = await this.userModel.findOne({
                    email,
                    _id: { $ne: id },
                });
                if (emailExists) {
                    throw new common_1.ConflictException('Email address is already in use');
                }
                updateUserDto.email = email;
            }
        }
        if (updateUserDto.phone) {
            const phone = (0, normalize_util_1.compactPhone)(updateUserDto.phone);
            if (phone && phone !== (0, normalize_util_1.compactPhone)(user.phone)) {
                const phoneExists = await this.userModel.findOne({
                    phone: (0, normalize_util_1.phoneDuplicateRegex)(phone),
                    _id: { $ne: id },
                });
                if (phoneExists) {
                    throw new common_1.ConflictException('Phone number is already in use');
                }
                updateUserDto.phone = phone;
            }
        }
        Object.assign(user, updateUserDto);
        user.profileCompletionPercentage = this.calculateProfileCompletion(user);
        user.isProfileComplete = user.profileCompletionPercentage >= 80;
        let savedUser;
        try {
            savedUser = await user.save();
        }
        catch (error) {
            throw this.mapDuplicateKeyError(error);
        }
        return savedUser.toJSON();
    }
    async updatePassword(id, updatePasswordDto) {
        const user = await this.userModel.findById(id);
        if (!user || user.deletedAt) {
            throw new common_1.NotFoundException('User not found');
        }
        const isCurrentPasswordValid = await password_util_1.PasswordUtil.compare(updatePasswordDto.currentPassword, user.password);
        if (!isCurrentPasswordValid) {
            throw new common_1.BadRequestException('Current password is incorrect');
        }
        const hashedNewPassword = await password_util_1.PasswordUtil.hash(updatePasswordDto.newPassword, this.configService.get('app.bcryptRounds'));
        await this.userModel.findByIdAndUpdate(id, {
            password: hashedNewPassword,
        });
    }
    async remove(id) {
        await this.findOne(id);
        await this.userModel.findByIdAndUpdate(id, { deletedAt: new Date() });
    }
    async setPasswordResetToken(userId, tokenHash, expiresAt) {
        await this.userModel.updateOne({ _id: userId, deletedAt: null }, {
            passwordResetToken: tokenHash,
            passwordResetExpires: expiresAt,
        });
    }
    async findByPasswordResetToken(tokenHash) {
        return this.userModel.findOne({
            passwordResetToken: tokenHash,
            passwordResetExpires: { $gt: new Date() },
            deletedAt: null,
        });
    }
    async resetPassword(userId, hashedPassword) {
        await this.userModel.updateOne({ _id: userId }, {
            password: hashedPassword,
            passwordResetToken: null,
            passwordResetExpires: null,
            refreshTokenHash: null,
            activeSessions: [],
        });
    }
    async updateRefreshToken(userId, refreshToken) {
        const refreshTokenHash = refreshToken ? this.hashToken(refreshToken) : null;
        await this.userModel.findByIdAndUpdate(userId, { refreshTokenHash });
    }
    async verifyRefreshToken(userId, refreshToken) {
        const user = await this.userModel.findById(userId);
        if (!user || !user.refreshTokenHash)
            return false;
        return this.hashToken(refreshToken) === user.refreshTokenHash;
    }
    hashToken(token) {
        return (0, crypto_1.createHash)('sha256').update(token).digest('hex');
    }
    async updateLastLogin(userId) {
        await this.userModel.findByIdAndUpdate(userId, {
            lastLoginAt: new Date(),
        });
    }
    async getActiveSessions(userId) {
        const user = await this.userModel.findById(userId).select('activeSessions');
        if (!user) {
            throw new common_1.NotFoundException(`User with ID "${userId}" not found`);
        }
        const now = Date.now();
        return (user.activeSessions ?? []).filter((session) => session.expiresAt && new Date(session.expiresAt).getTime() > now);
    }
    async startSession(userId, session, keepOtherSessions = false) {
        const user = await this.userModel.findById(userId).select('activeSessions');
        if (!user) {
            throw new common_1.NotFoundException(`User with ID "${userId}" not found`);
        }
        const now = Date.now();
        const existing = (user.activeSessions ?? []).filter((current) => current.expiresAt && new Date(current.expiresAt).getTime() > now);
        const sessions = keepOtherSessions
            ? [
                ...existing.filter((current) => current.sessionId !== session.sessionId),
                session,
            ]
            : [session];
        await this.userModel.findByIdAndUpdate(userId, {
            activeSessions: sessions,
        });
    }
    async touchSession(userId, sessionId, expiresAt) {
        const update = {
            'activeSessions.$.lastActiveAt': new Date(),
        };
        if (expiresAt) {
            update['activeSessions.$.expiresAt'] = expiresAt;
        }
        await this.userModel.updateOne({ _id: userId, 'activeSessions.sessionId': sessionId }, { $set: update });
    }
    async revokeSession(userId, sessionId) {
        if (!sessionId)
            return false;
        const result = await this.userModel.updateOne({ _id: userId }, { $pull: { activeSessions: { sessionId } } });
        return (result.modifiedCount ?? 0) > 0;
    }
    async revokeAllSessions(userId) {
        await this.userModel.findByIdAndUpdate(userId, { activeSessions: [] });
    }
    async isSessionActive(userId, sessionId) {
        if (!sessionId)
            return false;
        const count = await this.userModel.countDocuments({
            _id: userId,
            activeSessions: {
                $elemMatch: {
                    sessionId,
                    expiresAt: { $gt: new Date() },
                },
            },
        });
        return count > 0;
    }
    async verifyEmail(userId) {
        await this.userModel.findByIdAndUpdate(userId, {
            emailVerified: true,
            emailVerificationToken: null,
            emailVerificationExpires: null,
            status: role_enum_1.UserStatus.ACTIVE,
        });
    }
    async verifyPhone(userId) {
        await this.userModel.findByIdAndUpdate(userId, {
            phoneVerified: true,
            phoneOtp: null,
            phoneOtpExpires: null,
        });
    }
    async updateStatus(userId, status) {
        await this.userModel.findByIdAndUpdate(userId, { status });
    }
    async getProfileCompletion(userId) {
        const user = await this.findOne(userId);
        const percentage = this.calculateProfileCompletion(user);
        const missingFields = this.getMissingProfileFields(user);
        return {
            percentage,
            isComplete: percentage >= 80,
            missingFields,
        };
    }
    calculateProfileCompletion(user) {
        const fields = [
            { key: 'firstName', weight: 5 },
            { key: 'lastName', weight: 5 },
            { key: 'phone', weight: 10 },
            { key: 'dateOfBirth', weight: 5 },
            { key: 'gender', weight: 5 },
            { key: 'address', weight: 10 },
            { key: 'city', weight: 5 },
            { key: 'state', weight: 5 },
            { key: 'pincode', weight: 5 },
            { key: 'highestQualification', weight: 10 },
            { key: 'college', weight: 10 },
            { key: 'yearOfPassing', weight: 5 },
            { key: 'currentCompany', weight: 5 },
            { key: 'jobRole', weight: 5 },
            { key: 'experienceYears', weight: 5 },
            { key: 'avatar', weight: 5 },
        ];
        let score = 0;
        let totalWeight = 0;
        for (const field of fields) {
            totalWeight += field.weight;
            const value = user[field.key];
            if (value !== null && value !== undefined && value !== '') {
                score += field.weight;
            }
        }
        return Math.round((score / totalWeight) * 100);
    }
    getMissingProfileFields(user) {
        const requiredFields = [
            { key: 'phone', label: 'Phone Number' },
            { key: 'dateOfBirth', label: 'Date of Birth' },
            { key: 'gender', label: 'Gender' },
            { key: 'address', label: 'Address' },
            { key: 'city', label: 'City' },
            { key: 'state', label: 'State' },
            { key: 'pincode', label: 'PIN Code' },
            { key: 'highestQualification', label: 'Highest Qualification' },
            { key: 'college', label: 'College/University' },
            { key: 'yearOfPassing', label: 'Year of Passing' },
        ];
        return requiredFields
            .filter((field) => {
            const value = user[field.key];
            return value === null || value === undefined || value === '';
        })
            .map((field) => field.label);
    }
    async countByStatus() {
        const [total, active, inactive, pending, suspended] = await Promise.all([
            this.userModel.countDocuments({ deletedAt: null }),
            this.userModel.countDocuments({
                status: role_enum_1.UserStatus.ACTIVE,
                deletedAt: null,
            }),
            this.userModel.countDocuments({
                status: role_enum_1.UserStatus.INACTIVE,
                deletedAt: null,
            }),
            this.userModel.countDocuments({
                status: role_enum_1.UserStatus.PENDING,
                deletedAt: null,
            }),
            this.userModel.countDocuments({
                status: role_enum_1.UserStatus.SUSPENDED,
                deletedAt: null,
            }),
        ]);
        return { total, active, inactive, pending, suspended };
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(user_entity_1.User.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        config_1.ConfigService])
], UsersService);
//# sourceMappingURL=users.service.js.map