import { UsersService } from './users.service';
import { User } from './entities/user.entity';
import { UserStatus } from "../../shared/enums/role.enum";
import { CreateUserDto, AdminUpdateUserDto, UpdatePasswordDto, UpdateUserDto } from './dto/user.dto';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    findAll(page: number, limit: number): Promise<{
        data: User[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    create(dto: CreateUserDto): Promise<User>;
    update(id: string, dto: AdminUpdateUserDto): Promise<User>;
    updateStatus(id: string, status: UserStatus): Promise<{
        message: string;
    }>;
    getMyProfile(user: User): Promise<import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updateMyProfile(userId: string, dto: UpdateUserDto): Promise<User>;
    changeMyPassword(userId: string, dto: UpdatePasswordDto): Promise<{
        message: string;
    }>;
    deleteMyAccount(userId: string): Promise<{
        message: string;
    }>;
    getMyProfileCompletion(userId: string): Promise<{
        percentage: number;
        isComplete: boolean;
        missingFields: string[];
    }>;
    getUserStats(): Promise<{
        total: number;
        active: number;
        inactive: number;
        pending: number;
        suspended: number;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
