import { HydratedDocument } from 'mongoose';
import { UserRole, UserStatus } from "../../../shared/enums/role.enum";
export type UserDocument = HydratedDocument<User>;
export declare class UserSession {
    sessionId: string;
    deviceId: string;
    deviceName: string;
    platform: string;
    ipAddress: string;
    userAgent: string;
    loggedInAt: Date;
    lastActiveAt: Date;
    expiresAt: Date;
}
export declare const UserSessionSchema: import("mongoose").Schema<UserSession, import("mongoose").Model<UserSession, any, any, any, any, any, UserSession>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
    id: string;
}, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, "id"> & import("mongoose").HydratedDocumentOverrides<{
    id: string;
}>, {
    sessionId?: import("mongoose").SchemaDefinitionProperty<string, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    deviceId?: import("mongoose").SchemaDefinitionProperty<string, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    deviceName?: import("mongoose").SchemaDefinitionProperty<string, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    platform?: import("mongoose").SchemaDefinitionProperty<string, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    ipAddress?: import("mongoose").SchemaDefinitionProperty<string, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    userAgent?: import("mongoose").SchemaDefinitionProperty<string, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    loggedInAt?: import("mongoose").SchemaDefinitionProperty<Date, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    lastActiveAt?: import("mongoose").SchemaDefinitionProperty<Date, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    expiresAt?: import("mongoose").SchemaDefinitionProperty<Date, UserSession, import("mongoose").Document<unknown, {}, UserSession, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<UserSession & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
}, UserSession>;
export declare class User {
    _id: string;
    id: string;
    email: string;
    password: string;
    googleId: string;
    firstName: string;
    lastName: string;
    phone: string;
    avatar: string;
    dateOfBirth: Date;
    gender: string;
    address: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
    highestQualification: string;
    college: string;
    yearOfPassing: number;
    currentCompany: string;
    jobRole: string;
    experienceYears: number;
    role: UserRole;
    status: UserStatus;
    emailVerified: boolean;
    phoneVerified: boolean;
    emailVerificationToken: string;
    emailVerificationExpires: Date;
    phoneOtp: string;
    phoneOtpExpires: Date;
    refreshTokenHash: string;
    passwordResetToken: string;
    passwordResetExpires: Date;
    activeSessions: UserSession[];
    lastLoginAt: Date;
    lastLoginIp?: string;
    lastLoginDevice?: string;
    lastLoginBrowser?: string;
    profileCompletionPercentage: number;
    isProfileComplete: boolean;
    preferredLanguage: string;
    emailNotifications: boolean;
    smsNotifications: boolean;
    pushNotifications: boolean;
    deletedAt: Date;
    createdAt: Date;
    updatedAt: Date;
    get fullName(): string;
    isActive(): boolean;
    isSuspended(): boolean;
}
export declare const UserSchema: import("mongoose").Schema<User, import("mongoose").Model<User, any, any, any, any, any, User>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    email?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    password?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    googleId?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    firstName?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastName?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    phone?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    avatar?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    dateOfBirth?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    gender?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    address?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    city?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    state?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    country?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    pincode?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    highestQualification?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    college?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    yearOfPassing?: import("mongoose").SchemaDefinitionProperty<number, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    currentCompany?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    jobRole?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    experienceYears?: import("mongoose").SchemaDefinitionProperty<number, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    role?: import("mongoose").SchemaDefinitionProperty<UserRole, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<UserStatus, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    emailVerified?: import("mongoose").SchemaDefinitionProperty<boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    phoneVerified?: import("mongoose").SchemaDefinitionProperty<boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    emailVerificationToken?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    emailVerificationExpires?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    phoneOtp?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    phoneOtpExpires?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    refreshTokenHash?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    passwordResetToken?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    passwordResetExpires?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    activeSessions?: import("mongoose").SchemaDefinitionProperty<UserSession[], User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginAt?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginIp?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginDevice?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginBrowser?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    profileCompletionPercentage?: import("mongoose").SchemaDefinitionProperty<number, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isProfileComplete?: import("mongoose").SchemaDefinitionProperty<boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    preferredLanguage?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    emailNotifications?: import("mongoose").SchemaDefinitionProperty<boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    smsNotifications?: import("mongoose").SchemaDefinitionProperty<boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    pushNotifications?: import("mongoose").SchemaDefinitionProperty<boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    deletedAt?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    readonly fullName?: import("mongoose").SchemaDefinitionProperty<string, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isActive?: import("mongoose").SchemaDefinitionProperty<() => boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isSuspended?: import("mongoose").SchemaDefinitionProperty<() => boolean, User, import("mongoose").Document<unknown, {}, User, {}, import("mongoose").DefaultSchemaOptions> & User & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, User>;
