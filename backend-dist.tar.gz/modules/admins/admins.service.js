"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const config_1 = require("@nestjs/config");
const admin_entity_1 = require("./entities/admin.entity");
const password_util_1 = require("../../common/utils/password.util");
const normalize_util_1 = require("../../common/utils/normalize.util");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
let AdminsService = class AdminsService {
    constructor(adminModel, configService) {
        this.adminModel = adminModel;
        this.configService = configService;
    }
    async onModuleInit() {
        try {
            await this.adminModel.collection.createIndex({ phone: 1 }, {
                unique: true,
                partialFilterExpression: { phone: { $type: 'string' } },
            });
        }
        catch (error) {
            console.warn('[AdminsService] Could not ensure unique phone index (duplicate phone data may exist):', error.message);
        }
    }
    async countAll() {
        return this.adminModel.countDocuments({ deletedAt: null });
    }
    async create(createAdminDto, createdByAdminId) {
        const email = (0, normalize_util_1.normalizeEmail)(createAdminDto.email);
        const phone = (0, normalize_util_1.compactPhone)(createAdminDto.phone);
        const existingAdmin = await this.adminModel.findOne({ email });
        if (existingAdmin) {
            throw new common_1.ConflictException('Email address is already registered as admin');
        }
        if (phone) {
            const phoneExists = await this.adminModel.findOne({
                phone: (0, normalize_util_1.phoneDuplicateRegex)(phone),
            });
            if (phoneExists) {
                throw new common_1.ConflictException('Phone number is already registered');
            }
        }
        let permissions = createAdminDto.permissions;
        if (!permissions || permissions.length === 0) {
            permissions = this.getDefaultPermissions(createAdminDto.role);
        }
        const hashedPassword = await password_util_1.PasswordUtil.hash(createAdminDto.password, this.configService.get('app.bcryptRounds'));
        let savedAdmin;
        try {
            savedAdmin = await this.adminModel.create({
                ...createAdminDto,
                email,
                phone,
                password: hashedPassword,
                permissions,
                createdByAdminId: createdByAdminId || null,
                loginCount: 0,
            });
        }
        catch (error) {
            throw this.mapDuplicateKeyError(error);
        }
        return savedAdmin.toJSON();
    }
    mapDuplicateKeyError(error) {
        const mongoError = error;
        if (mongoError?.code === 11000) {
            const field = mongoError.keyPattern?.phone
                ? 'Phone number'
                : 'Email address';
            return new common_1.ConflictException(`${field} is already registered`);
        }
        return error;
    }
    async findAll(page = 1, limit = 10, currentAdmin) {
        const filter = { deletedAt: null };
        if (currentAdmin && !currentAdmin.isSuperAdmin()) {
            filter.role = { $nin: [user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.SUPER_ADMIN] };
        }
        const [data, total] = await Promise.all([
            this.adminModel
                .find(filter)
                .select('email firstName lastName phone avatar role status permissions department designation loginCount lastLoginAt lastActiveAt createdAt updatedAt createdByAdminId')
                .populate('createdBy', 'firstName lastName email')
                .sort({ createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .exec(),
            this.adminModel.countDocuments(filter),
        ]);
        return { data, total, page, limit };
    }
    async findOne(id) {
        const admin = await this.adminModel
            .findOne({ _id: id, deletedAt: null })
            .populate('createdBy', 'firstName lastName email');
        if (!admin) {
            throw new common_1.NotFoundException(`Admin with ID "${id}" not found`);
        }
        return admin;
    }
    async findByEmail(email) {
        return this.adminModel.findOne({
            email: (0, normalize_util_1.normalizeEmail)(email),
            deletedAt: null,
        });
    }
    async findByEmailWithPassword(email) {
        return this.findByIdentifierWithPassword(email);
    }
    async findByIdentifierWithPassword(identifier) {
        if (!identifier)
            return null;
        const clean = identifier.toLowerCase().trim();
        return this.adminModel.findOne({
            $or: [
                { email: clean },
                { username: clean },
            ],
            deletedAt: null,
        });
    }
    async setPasswordResetToken(adminId, tokenHash, expiresAt) {
        await this.adminModel.updateOne({ _id: adminId, deletedAt: null }, {
            passwordResetToken: tokenHash,
            passwordResetExpires: expiresAt,
        });
    }
    async findByPasswordResetToken(tokenHash) {
        return this.adminModel.findOne({
            passwordResetToken: tokenHash,
            passwordResetExpires: { $gt: new Date() },
            deletedAt: null,
        });
    }
    async resetPassword(adminId, hashedPassword) {
        await this.adminModel.updateOne({ _id: adminId }, {
            password: hashedPassword,
            passwordResetToken: null,
            passwordResetExpires: null,
            refreshTokenHash: null,
        });
    }
    async update(id, updateAdminDto, currentAdminId) {
        const admin = await this.findOne(id);
        if (id !== currentAdminId) {
            const currentAdmin = await this.findOne(currentAdminId);
            if (!currentAdmin.isSuperAdmin()) {
                throw new common_1.ForbiddenException('Only Super Admin can update other admins');
            }
        }
        if (updateAdminDto.phone) {
            const phone = (0, normalize_util_1.compactPhone)(updateAdminDto.phone);
            if (phone && phone !== (0, normalize_util_1.compactPhone)(admin.phone)) {
                const phoneExists = await this.adminModel.findOne({
                    phone: (0, normalize_util_1.phoneDuplicateRegex)(phone),
                    _id: { $ne: id },
                });
                if (phoneExists) {
                    throw new common_1.ConflictException('Phone number is already in use');
                }
                updateAdminDto.phone = phone;
            }
        }
        Object.assign(admin, updateAdminDto, {
            updatedByAdminId: currentAdminId,
        });
        let updatedAdmin;
        try {
            updatedAdmin = await admin.save();
        }
        catch (error) {
            throw this.mapDuplicateKeyError(error);
        }
        return updatedAdmin.toJSON();
    }
    async updatePassword(id, updatePasswordDto) {
        const admin = await this.adminModel.findById(id);
        if (!admin || admin.deletedAt) {
            throw new common_1.NotFoundException('Admin not found');
        }
        const isCurrentPasswordValid = await password_util_1.PasswordUtil.compare(updatePasswordDto.currentPassword, admin.password);
        if (!isCurrentPasswordValid) {
            throw new common_1.BadRequestException('Current password is incorrect');
        }
        const hashedNewPassword = await password_util_1.PasswordUtil.hash(updatePasswordDto.newPassword, this.configService.get('app.bcryptRounds'));
        await this.adminModel.findByIdAndUpdate(id, {
            password: hashedNewPassword,
        });
    }
    async updateStatus(id, dto, currentAdminId) {
        const admin = await this.findOne(id);
        if (id === currentAdminId) {
            throw new common_1.ForbiddenException('You cannot change your own status');
        }
        if (admin.role === user_status_enum_1.AdminRole.SUPER_ADMIN &&
            dto.status === user_status_enum_1.AdminStatus.SUSPENDED) {
            const superAdminCount = await this.adminModel.countDocuments({
                role: user_status_enum_1.AdminRole.SUPER_ADMIN,
                status: user_status_enum_1.AdminStatus.ACTIVE,
                deletedAt: null,
            });
            if (superAdminCount <= 1) {
                throw new common_1.ForbiddenException('Cannot suspend the last active Super Admin');
            }
        }
        await this.adminModel.findByIdAndUpdate(id, {
            status: dto.status,
            updatedByAdminId: currentAdminId,
        });
        return this.findOne(id);
    }
    async updateRole(id, dto, currentAdminId) {
        const admin = await this.findOne(id);
        if (id === currentAdminId) {
            throw new common_1.ForbiddenException('You cannot change your own role');
        }
        if (admin.role === user_status_enum_1.AdminRole.SUPER_ADMIN &&
            dto.role !== user_status_enum_1.AdminRole.SUPER_ADMIN) {
            const superAdminCount = await this.adminModel.countDocuments({
                role: user_status_enum_1.AdminRole.SUPER_ADMIN,
                status: user_status_enum_1.AdminStatus.ACTIVE,
                deletedAt: null,
            });
            if (superAdminCount <= 1) {
                throw new common_1.ForbiddenException('Cannot demote the last Super Admin');
            }
        }
        const permissions = dto.permissions && dto.permissions.length > 0
            ? dto.permissions
            : this.getDefaultPermissions(dto.role);
        await this.adminModel.findByIdAndUpdate(id, {
            role: dto.role,
            permissions,
            updatedByAdminId: currentAdminId,
        });
        return this.findOne(id);
    }
    async remove(id, currentAdminId) {
        const admin = await this.findOne(id);
        if (id === currentAdminId) {
            throw new common_1.ForbiddenException('You cannot delete your own account');
        }
        if (admin.role === user_status_enum_1.AdminRole.SUPER_ADMIN) {
            const superAdminCount = await this.adminModel.countDocuments({
                role: user_status_enum_1.AdminRole.SUPER_ADMIN,
                status: user_status_enum_1.AdminStatus.ACTIVE,
                deletedAt: null,
            });
            if (superAdminCount <= 1) {
                throw new common_1.ForbiddenException('Cannot delete the last Super Admin');
            }
        }
        await this.adminModel.findByIdAndUpdate(id, { deletedAt: new Date() });
    }
    async updateRefreshToken(adminId, refreshToken) {
        const refreshTokenHash = refreshToken
            ? await password_util_1.PasswordUtil.hash(refreshToken, this.configService.get('app.bcryptRounds'))
            : null;
        await this.adminModel.findByIdAndUpdate(adminId, { refreshTokenHash });
    }
    async verifyRefreshToken(adminId, refreshToken) {
        const admin = await this.adminModel.findById(adminId);
        if (!admin || !admin.refreshTokenHash)
            return false;
        return password_util_1.PasswordUtil.compare(refreshToken, admin.refreshTokenHash);
    }
    async updateLastLogin(adminId, ipAddress, device, browser) {
        await this.adminModel.findByIdAndUpdate(adminId, {
            $set: {
                lastLoginAt: new Date(),
                lastActiveAt: new Date(),
                lastLoginIp: ipAddress || null,
                ...(device ? { lastLoginDevice: device } : {}),
                ...(browser ? { lastLoginBrowser: browser } : {}),
            },
            $inc: { loginCount: 1 },
        });
    }
    async setTrainerActiveSession(adminId, session) {
        await this.adminModel.findByIdAndUpdate(adminId, {
            $set: {
                activeSessionId: session.sessionId,
                activeDeviceId: session.deviceId,
                activeDeviceName: session.deviceName,
                activeSessionIp: session.ipAddress || null,
                activeSessionExpiresAt: session.expiresAt,
                activeSessionLoggedInAt: new Date(),
            },
        });
    }
    async clearTrainerActiveSession(adminId) {
        await this.adminModel.findByIdAndUpdate(adminId, {
            $set: {
                activeSessionId: null,
                activeDeviceId: null,
                activeDeviceName: null,
                activeSessionIp: null,
                activeSessionExpiresAt: null,
            },
        });
    }
    async updateLastActive(adminId) {
        await this.adminModel.findByIdAndUpdate(adminId, {
            lastActiveAt: new Date(),
        });
    }
    async hasPermission(adminId, permission) {
        const admin = await this.findOne(adminId);
        return admin.can(permission);
    }
    async getAdminStats(currentAdmin) {
        const scoped = !!currentAdmin && !currentAdmin.isSuperAdmin();
        const scopedRoles = [user_status_enum_1.AdminRole.ADMIN, user_status_enum_1.AdminRole.SUPER_ADMIN];
        const baseFilter = { deletedAt: null };
        const activeFilter = {
            status: user_status_enum_1.AdminStatus.ACTIVE,
            deletedAt: null,
        };
        if (scoped) {
            baseFilter.role = { $nin: scopedRoles };
            activeFilter.role = { $nin: scopedRoles };
        }
        const totalAdmins = await this.adminModel.countDocuments(baseFilter);
        const activeAdmins = await this.adminModel.countDocuments(activeFilter);
        const roleCounts = {};
        for (const role of Object.values(user_status_enum_1.AdminRole)) {
            if (scoped && scopedRoles.includes(role))
                continue;
            const count = await this.adminModel.countDocuments({
                role,
                deletedAt: null,
            });
            roleCounts[role] = count;
        }
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        const recentLogins = await this.adminModel.countDocuments({
            ...baseFilter,
            lastLoginAt: { $gte: sevenDaysAgo },
        });
        return { totalAdmins, activeAdmins, byRole: roleCounts, recentLogins };
    }
    getDefaultPermissions(role) {
        const allPermissions = [
            'course.create',
            'course.edit',
            'course.delete',
            'course.view',
            'student.view',
            'student.edit',
            'student.suspend',
            'student.delete',
            'batch.create',
            'batch.edit',
            'batch.delete',
            'batch.view',
            'payment.view',
            'payment.refund',
            'payment.create',
            'trainer.create',
            'trainer.edit',
            'trainer.delete',
            'trainer.view',
            'admin.create',
            'admin.edit',
            'admin.delete',
            'admin.view',
            'report.view',
            'report.export',
            'settings.manage',
        ];
        switch (role) {
            case user_status_enum_1.AdminRole.SUPER_ADMIN:
                return allPermissions;
            case user_status_enum_1.AdminRole.ADMIN:
                return [
                    'course.create',
                    'course.edit',
                    'course.view',
                    'student.view',
                    'student.edit',
                    'batch.create',
                    'batch.edit',
                    'batch.view',
                    'payment.view',
                    'trainer.view',
                    'report.view',
                    'report.export',
                ];
            case user_status_enum_1.AdminRole.SUPPORT:
                return ['student.view', 'student.edit', 'batch.view', 'report.view'];
            case user_status_enum_1.AdminRole.FINANCE:
                return [
                    'payment.view',
                    'payment.refund',
                    'payment.create',
                    'student.view',
                    'report.view',
                    'report.export',
                ];
            default:
                return [];
        }
    }
};
exports.AdminsService = AdminsService;
exports.AdminsService = AdminsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(admin_entity_1.Admin.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        config_1.ConfigService])
], AdminsService);
//# sourceMappingURL=admins.service.js.map