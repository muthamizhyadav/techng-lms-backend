"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const admins_service_1 = require("./admins.service");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const current_admin_decorator_1 = require("../../common/decorators/current-admin.decorator");
const admin_entity_1 = require("./entities/admin.entity");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const admin_dto_1 = require("./dto/admin.dto");
let AdminsController = class AdminsController {
    constructor(adminsService) {
        this.adminsService = adminsService;
    }
    async findAll(page, limit, currentAdmin) {
        return this.adminsService.findAll(page, limit, currentAdmin);
    }
    async findOne(id, currentAdmin) {
        const admin = await this.adminsService.findOne(id);
        if (!currentAdmin.isSuperAdmin() &&
            (admin.role === user_status_enum_1.AdminRole.ADMIN || admin.role === user_status_enum_1.AdminRole.SUPER_ADMIN)) {
            throw new common_1.ForbiddenException('You can only view Support or Finance user profiles');
        }
        return admin;
    }
    async create(dto, currentAdmin) {
        return this.adminsService.create(dto, currentAdmin.id);
    }
    async update(id, dto, currentAdmin) {
        if (id !== currentAdmin.id && !currentAdmin.isSuperAdmin()) {
            throw new common_1.ForbiddenException('You can only update your own profile');
        }
        return this.adminsService.update(id, dto, currentAdmin.id);
    }
    async updateStatus(id, dto, currentAdmin) {
        return this.adminsService.updateStatus(id, dto, currentAdmin.id);
    }
    async updateRole(id, dto, currentAdmin) {
        return this.adminsService.updateRole(id, dto, currentAdmin.id);
    }
    async updatePassword(id, dto, currentAdmin) {
        if (id !== currentAdmin.id) {
            throw new common_1.ForbiddenException('You can only change your own password');
        }
        await this.adminsService.updatePassword(id, dto);
        return { message: 'Password changed successfully' };
    }
    async remove(id, currentAdmin) {
        await this.adminsService.remove(id, currentAdmin.id);
        return { message: 'Admin deleted successfully' };
    }
    async getMyProfile(admin) {
        return this.adminsService.findOne(admin.id);
    }
    async getAdminStats(currentAdmin) {
        return this.adminsService.getAdminStats(currentAdmin);
    }
};
exports.AdminsController = AdminsController;
__decorate([
    (0, common_1.Get)(),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'List all admins',
        description: 'Any admin can view the admin directory',
    }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number, example: 1 }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number, example: 10 }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'List of admins retrieved',
        schema: {
            example: {
                data: [],
                total: 15,
                page: 1,
                limit: 10,
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    __param(0, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(1, (0, common_1.Query)('limit', new common_1.DefaultValuePipe(10), common_1.ParseIntPipe)),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Get admin by ID' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Admin UUID',
        example: '0f8fad5b-d9cb-469f-a165-70867728950e',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Admin found',
        type: admin_dto_1.AdminResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Cannot view Admin or Super Admin profiles',
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Admin not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Create new admin (Super Admin only)',
        description: 'Creates a new admin account with role and permissions',
    }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.CreateAdminDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Admin created',
        type: admin_dto_1.AdminResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Only Super Admin can create admins',
    }),
    (0, swagger_1.ApiResponse)({ status: 409, description: 'Email already registered' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_dto_1.CreateAdminDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Update admin profile',
        description: 'Admins can update their own profile. Super Admin can update any admin.',
    }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Admin UUID' }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.UpdateAdminDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Profile updated',
        type: admin_dto_1.AdminResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Can only update your own profile or need Super Admin access',
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, admin_dto_1.UpdateAdminDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Update admin status (Super Admin only)',
        description: 'Activate, suspend, or deactivate an admin account',
    }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Admin UUID' }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.UpdateAdminStatusDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Status updated' }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Cannot change own status or last Super Admin',
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, admin_dto_1.UpdateAdminStatusDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Patch)(':id/role'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Update admin role & permissions (Super Admin only)',
        description: 'Change role and custom permissions. Cannot demote last Super Admin.',
    }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Admin UUID' }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.UpdateAdminRoleDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Role updated' }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Cannot change own role or last Super Admin',
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, admin_dto_1.UpdateAdminRoleDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "updateRole", null);
__decorate([
    (0, common_1.Patch)(':id/password'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Change admin password (Self only)',
        description: 'Admins can only change their own password',
    }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Admin UUID' }),
    (0, swagger_1.ApiBody)({ type: admin_dto_1.UpdateAdminPasswordDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Password changed successfully' }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Can only change your own password',
    }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Current password is incorrect' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, admin_dto_1.UpdateAdminPasswordDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "updatePassword", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Delete admin (Super Admin only)',
        description: 'Soft deletes an admin account. Cannot delete self or last Super Admin.',
    }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Admin UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Admin deleted' }),
    (0, swagger_1.ApiResponse)({
        status: 403,
        description: 'Cannot delete self or last Super Admin',
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)('me/profile'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Get my admin profile' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Profile retrieved',
        type: admin_dto_1.AdminResponseDto,
    }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "getMyProfile", null);
__decorate([
    (0, common_1.Get)('stats/overview'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get admin statistics',
        description: 'Total admins, active count, role distribution, recent logins. For non Super Admins, statistics are scoped to non-administrator roles (Support & Finance) only.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Admin statistics',
        schema: {
            example: {
                totalAdmins: 15,
                activeAdmins: 12,
                byRole: {
                    super_admin: 2,
                    admin: 8,
                    support: 3,
                    finance: 2,
                },
                recentLogins: 5,
            },
        },
    }),
    __param(0, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], AdminsController.prototype, "getAdminStats", null);
exports.AdminsController = AdminsController = __decorate([
    (0, swagger_1.ApiTags)('🛡️ Admins'),
    (0, common_1.Controller)('admins'),
    __metadata("design:paramtypes", [admins_service_1.AdminsService])
], AdminsController);
//# sourceMappingURL=admins.controller.js.map