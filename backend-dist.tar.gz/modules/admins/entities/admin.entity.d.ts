import { HydratedDocument } from 'mongoose';
import { AdminRole, AdminStatus } from "../../../shared/enums/user-status.enum";
export type AdminDocument = HydratedDocument<Admin>;
export declare class Admin {
    _id: string;
    id: string;
    email: string;
    username?: string;
    trainerProfileId?: string;
    password: string;
    firstName: string;
    lastName: string;
    phone: string;
    avatar: string;
    role: AdminRole;
    status: AdminStatus;
    permissions: string[];
    department: string;
    designation: string;
    bio: string;
    createdByAdminId: string;
    createdBy?: Admin;
    updatedByAdminId: string;
    loginCount: number;
    lastLoginAt: Date;
    lastActiveAt: Date;
    lastLoginIp: string;
    lastLoginDevice?: string;
    lastLoginBrowser?: string;
    activeSessionId?: string;
    activeDeviceId?: string;
    activeDeviceName?: string;
    activeSessionIp?: string;
    activeSessionExpiresAt?: Date;
    activeSessionLoggedInAt?: Date;
    refreshTokenHash: string;
    passwordResetToken: string;
    passwordResetExpires: Date;
    twoFactorEnabled: boolean;
    twoFactorSecret: string;
    emailNotifications: boolean;
    smsNotifications: boolean;
    fcmTokens: string[];
    deletedAt: Date;
    createdAt: Date;
    updatedAt: Date;
    get fullName(): string;
    isSuperAdmin(): boolean;
    isActive(): boolean;
    can(permission: string): boolean;
    hasAnyPermission(permissions: string[]): boolean;
    hasAllPermissions(permissions: string[]): boolean;
    updateLastActive(): void;
}
export declare const AdminSchema: import("mongoose").Schema<Admin, import("mongoose").Model<Admin, any, any, any, any, any, Admin>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    email?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    username?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    trainerProfileId?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    password?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    firstName?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastName?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    phone?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    avatar?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    role?: import("mongoose").SchemaDefinitionProperty<AdminRole, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<AdminStatus, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    permissions?: import("mongoose").SchemaDefinitionProperty<string[], Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    department?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    designation?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    bio?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdByAdminId?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdBy?: import("mongoose").SchemaDefinitionProperty<Admin, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedByAdminId?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    loginCount?: import("mongoose").SchemaDefinitionProperty<number, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginAt?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastActiveAt?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginIp?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginDevice?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    lastLoginBrowser?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    activeSessionId?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    activeDeviceId?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    activeDeviceName?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    activeSessionIp?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    activeSessionExpiresAt?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    activeSessionLoggedInAt?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    refreshTokenHash?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    passwordResetToken?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    passwordResetExpires?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    twoFactorEnabled?: import("mongoose").SchemaDefinitionProperty<boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    twoFactorSecret?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    emailNotifications?: import("mongoose").SchemaDefinitionProperty<boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    smsNotifications?: import("mongoose").SchemaDefinitionProperty<boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    fcmTokens?: import("mongoose").SchemaDefinitionProperty<string[], Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    deletedAt?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    readonly fullName?: import("mongoose").SchemaDefinitionProperty<string, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isSuperAdmin?: import("mongoose").SchemaDefinitionProperty<() => boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    isActive?: import("mongoose").SchemaDefinitionProperty<() => boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    can?: import("mongoose").SchemaDefinitionProperty<(permission: string) => boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    hasAnyPermission?: import("mongoose").SchemaDefinitionProperty<(permissions: string[]) => boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    hasAllPermissions?: import("mongoose").SchemaDefinitionProperty<(permissions: string[]) => boolean, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updateLastActive?: import("mongoose").SchemaDefinitionProperty<() => void, Admin, import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, Admin>;
