"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminSchema = exports.Admin = void 0;
const mongoose_1 = require("@nestjs/mongoose");
const user_status_enum_1 = require("../../../shared/enums/user-status.enum");
const uuid_util_1 = require("../../../common/utils/uuid.util");
let Admin = class Admin {
    get fullName() {
        return this.lastName ? `${this.firstName} ${this.lastName}` : this.firstName;
    }
    isSuperAdmin() {
        return this.role === user_status_enum_1.AdminRole.SUPER_ADMIN;
    }
    isActive() {
        return this.status === user_status_enum_1.AdminStatus.ACTIVE;
    }
    can(permission) {
        if (this.role === user_status_enum_1.AdminRole.SUPER_ADMIN)
            return true;
        return this.permissions.includes(permission);
    }
    hasAnyPermission(permissions) {
        if (this.role === user_status_enum_1.AdminRole.SUPER_ADMIN)
            return true;
        return permissions.some((p) => this.permissions.includes(p));
    }
    hasAllPermissions(permissions) {
        if (this.role === user_status_enum_1.AdminRole.SUPER_ADMIN)
            return true;
        return permissions.every((p) => this.permissions.includes(p));
    }
    updateLastActive() {
        this.lastActiveAt = new Date();
    }
};
exports.Admin = Admin;
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: uuid_util_1.generateUuid, unique: true }),
    __metadata("design:type", String)
], Admin.prototype, "_id", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, unique: true, lowercase: true, trim: true }),
    __metadata("design:type", String)
], Admin.prototype, "email", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, sparse: true, unique: true, lowercase: true, default: null }),
    __metadata("design:type", String)
], Admin.prototype, "username", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, default: null }),
    __metadata("design:type", String)
], Admin.prototype, "trainerProfileId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true }),
    __metadata("design:type", String)
], Admin.prototype, "password", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: true, trim: true }),
    __metadata("design:type", String)
], Admin.prototype, "firstName", void 0);
__decorate([
    (0, mongoose_1.Prop)({ required: false, trim: true, default: null }),
    __metadata("design:type", String)
], Admin.prototype, "lastName", void 0);
__decorate([
    (0, mongoose_1.Prop)({ trim: true, default: null }),
    __metadata("design:type", String)
], Admin.prototype, "phone", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "avatar", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, enum: user_status_enum_1.AdminRole, default: user_status_enum_1.AdminRole.ADMIN }),
    __metadata("design:type", String)
], Admin.prototype, "role", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, enum: user_status_enum_1.AdminStatus, default: user_status_enum_1.AdminStatus.ACTIVE }),
    __metadata("design:type", String)
], Admin.prototype, "status", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [String], default: [] }),
    __metadata("design:type", Array)
], Admin.prototype, "permissions", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "department", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "designation", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "bio", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], Admin.prototype, "createdByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: String, ref: 'Admin', default: null }),
    __metadata("design:type", String)
], Admin.prototype, "updatedByAdminId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Number, default: 0 }),
    __metadata("design:type", Number)
], Admin.prototype, "loginCount", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], Admin.prototype, "lastLoginAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], Admin.prototype, "lastActiveAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "lastLoginIp", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "lastLoginDevice", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "lastLoginBrowser", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "activeSessionId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "activeDeviceId", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "activeDeviceName", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "activeSessionIp", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], Admin.prototype, "activeSessionExpiresAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], Admin.prototype, "activeSessionLoggedInAt", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "refreshTokenHash", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "passwordResetToken", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], Admin.prototype, "passwordResetExpires", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: false }),
    __metadata("design:type", Boolean)
], Admin.prototype, "twoFactorEnabled", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: null }),
    __metadata("design:type", String)
], Admin.prototype, "twoFactorSecret", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: true }),
    __metadata("design:type", Boolean)
], Admin.prototype, "emailNotifications", void 0);
__decorate([
    (0, mongoose_1.Prop)({ default: true }),
    __metadata("design:type", Boolean)
], Admin.prototype, "smsNotifications", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: [String], default: [] }),
    __metadata("design:type", Array)
], Admin.prototype, "fcmTokens", void 0);
__decorate([
    (0, mongoose_1.Prop)({ type: Date, default: null }),
    __metadata("design:type", Date)
], Admin.prototype, "deletedAt", void 0);
exports.Admin = Admin = __decorate([
    (0, mongoose_1.Schema)({
        _id: false,
        timestamps: true,
        collection: 'admins',
        toJSON: {
            virtuals: true,
            versionKey: false,
            transform: (_doc, ret) => {
                ret.id = ret._id;
                delete ret._id;
                delete ret.password;
                delete ret.refreshTokenHash;
                delete ret.twoFactorSecret;
                delete ret.passwordResetToken;
                delete ret.fcmTokens;
                return ret;
            },
        },
        toObject: {
            virtuals: true,
            versionKey: false,
        },
    })
], Admin);
exports.AdminSchema = mongoose_1.SchemaFactory.createForClass(Admin);
exports.AdminSchema.index({ phone: 1 });
exports.AdminSchema.virtual('createdBy', {
    ref: 'Admin',
    localField: 'createdByAdminId',
    foreignField: '_id',
    justOne: true,
});
exports.AdminSchema.virtual('fullName').get(function () {
    return this.lastName ? `${this.firstName} ${this.lastName}` : this.firstName;
});
exports.AdminSchema.methods.isSuperAdmin = function () {
    return this.role === user_status_enum_1.AdminRole.SUPER_ADMIN;
};
exports.AdminSchema.methods.isActive = function () {
    return this.status === user_status_enum_1.AdminStatus.ACTIVE;
};
exports.AdminSchema.methods.can = function (permission) {
    if (this.role === user_status_enum_1.AdminRole.SUPER_ADMIN)
        return true;
    return this.permissions.includes(permission);
};
exports.AdminSchema.methods.hasAnyPermission = function (permissions) {
    if (this.role === user_status_enum_1.AdminRole.SUPER_ADMIN)
        return true;
    return permissions.some((p) => this.permissions.includes(p));
};
exports.AdminSchema.methods.hasAllPermissions = function (permissions) {
    if (this.role === user_status_enum_1.AdminRole.SUPER_ADMIN)
        return true;
    return permissions.every((p) => this.permissions.includes(p));
};
exports.AdminSchema.methods.updateLastActive = function () {
    this.lastActiveAt = new Date();
};
//# sourceMappingURL=admin.entity.js.map