import { OnModuleInit } from '@nestjs/common';
import { Model } from 'mongoose';
import { ConfigService } from '@nestjs/config';
import { Admin, AdminDocument } from './entities/admin.entity';
import { CreateAdminDto, UpdateAdminDto, UpdateAdminPasswordDto, UpdateAdminRoleDto, UpdateAdminStatusDto } from './dto/admin.dto';
export declare class AdminsService implements OnModuleInit {
    private readonly adminModel;
    private readonly configService;
    constructor(adminModel: Model<AdminDocument>, configService: ConfigService);
    onModuleInit(): Promise<void>;
    countAll(): Promise<number>;
    create(createAdminDto: CreateAdminDto, createdByAdminId: string): Promise<Admin>;
    private mapDuplicateKeyError;
    findAll(page?: number, limit?: number, currentAdmin?: Admin): Promise<{
        data: Admin[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<AdminDocument>;
    findByEmail(email: string): Promise<AdminDocument | null>;
    findByEmailWithPassword(email: string): Promise<AdminDocument | null>;
    findByIdentifierWithPassword(identifier: string): Promise<AdminDocument | null>;
    setPasswordResetToken(adminId: string, tokenHash: string, expiresAt: Date): Promise<void>;
    findByPasswordResetToken(tokenHash: string): Promise<AdminDocument | null>;
    resetPassword(adminId: string, hashedPassword: string): Promise<void>;
    update(id: string, updateAdminDto: UpdateAdminDto, currentAdminId: string): Promise<Admin>;
    updatePassword(id: string, updatePasswordDto: UpdateAdminPasswordDto): Promise<void>;
    updateStatus(id: string, dto: UpdateAdminStatusDto, currentAdminId: string): Promise<AdminDocument>;
    updateRole(id: string, dto: UpdateAdminRoleDto, currentAdminId: string): Promise<AdminDocument>;
    remove(id: string, currentAdminId: string): Promise<void>;
    updateRefreshToken(adminId: string, refreshToken: string | null): Promise<void>;
    verifyRefreshToken(adminId: string, refreshToken: string): Promise<boolean>;
    updateLastLogin(adminId: string, ipAddress?: string, device?: string, browser?: string): Promise<void>;
    setTrainerActiveSession(adminId: string, session: {
        sessionId: string;
        deviceId: string;
        deviceName: string;
        ipAddress?: string;
        expiresAt: Date;
    }): Promise<void>;
    clearTrainerActiveSession(adminId: string): Promise<void>;
    updateLastActive(adminId: string): Promise<void>;
    hasPermission(adminId: string, permission: string): Promise<boolean>;
    getAdminStats(currentAdmin?: Admin): Promise<{
        totalAdmins: number;
        activeAdmins: number;
        byRole: Record<string, number>;
        recentLogins: number;
    }>;
    private getDefaultPermissions;
}
