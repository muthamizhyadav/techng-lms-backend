import { AdminsService } from './admins.service';
import { Admin } from './entities/admin.entity';
import { CreateAdminDto, UpdateAdminDto, UpdateAdminPasswordDto, UpdateAdminStatusDto, UpdateAdminRoleDto } from './dto/admin.dto';
export declare class AdminsController {
    private readonly adminsService;
    constructor(adminsService: AdminsService);
    findAll(page: number, limit: number, currentAdmin: Admin): Promise<{
        data: Admin[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string, currentAdmin: Admin): Promise<import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    create(dto: CreateAdminDto, currentAdmin: Admin): Promise<Admin>;
    update(id: string, dto: UpdateAdminDto, currentAdmin: Admin): Promise<Admin>;
    updateStatus(id: string, dto: UpdateAdminStatusDto, currentAdmin: Admin): Promise<import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updateRole(id: string, dto: UpdateAdminRoleDto, currentAdmin: Admin): Promise<import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatePassword(id: string, dto: UpdateAdminPasswordDto, currentAdmin: Admin): Promise<{
        message: string;
    }>;
    remove(id: string, currentAdmin: Admin): Promise<{
        message: string;
    }>;
    getMyProfile(admin: Admin): Promise<import("mongoose").Document<unknown, {}, Admin, {}, import("mongoose").DefaultSchemaOptions> & Admin & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    getAdminStats(currentAdmin: Admin): Promise<{
        totalAdmins: number;
        activeAdmins: number;
        byRole: Record<string, number>;
        recentLogins: number;
    }>;
}
