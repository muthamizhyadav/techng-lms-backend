import { AdminRole, AdminStatus } from "../../../shared/enums/user-status.enum";
export declare class CreateAdminDto {
    email: string;
    password: string;
    firstName: string;
    lastName?: string;
    phone?: string;
    role: AdminRole;
    status?: AdminStatus;
    permissions?: string[];
    department?: string;
    designation?: string;
    bio?: string;
    emailNotifications?: boolean;
    smsNotifications?: boolean;
}
declare const UpdateAdminDto_base: import("@nestjs/common").Type<Partial<Omit<CreateAdminDto, "email" | "password">>>;
export declare class UpdateAdminDto extends UpdateAdminDto_base {
}
export declare class AdminLoginDto {
    email: string;
    password: string;
    deviceId?: string;
    deviceName?: string;
}
export declare class AdminRegisterDto extends CreateAdminDto {
}
export declare class UpdateAdminPasswordDto {
    currentPassword: string;
    newPassword: string;
}
export declare class AdminResponseDto {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    fullName: string;
    phone: string;
    avatar: string;
    role: AdminRole;
    status: AdminStatus;
    permissions: string[];
    department: string;
    designation: string;
    bio: string;
    loginCount: number;
    lastLoginAt: Date;
    lastActiveAt: Date;
    emailNotifications: boolean;
    smsNotifications: boolean;
    createdAt: Date;
    updatedAt: Date;
}
export declare class UpdateAdminStatusDto {
    status: AdminStatus;
    reason?: string;
}
export declare class UpdateAdminRoleDto {
    role: AdminRole;
    permissions?: string[];
}
export {};
