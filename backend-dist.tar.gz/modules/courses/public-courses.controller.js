"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicCoursesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const courses_service_1 = require("./courses.service");
const course_dto_1 = require("./dto/course.dto");
const curriculum_util_1 = require("../../shared/utils/curriculum.util");
let PublicCoursesController = class PublicCoursesController {
    constructor(coursesService) {
        this.coursesService = coursesService;
    }
    async getPublicCourses(page, limit, category, search) {
        return this.coursesService.findAll({
            page,
            limit,
            category,
            search,
        });
    }
    async getPublicCourseById(id) {
        const course = await this.coursesService.findOne(id);
        const rawModules = (0, curriculum_util_1.withCurriculumIds)(course.modules || []);
        const sanitizedModules = rawModules.map((mod) => ({
            ...mod,
            lessons: (mod.lessons || []).map((lesson) => {
                if (lesson.isPreview) {
                    return lesson;
                }
                const { videoUrl, ...safeLesson } = lesson;
                return {
                    ...safeLesson,
                    hasVideo: Boolean(videoUrl),
                };
            }),
        }));
        return {
            ...course.toJSON(),
            modules: sanitizedModules,
        };
    }
};
exports.PublicCoursesController = PublicCoursesController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({
        summary: 'Browse published courses (Public)',
        description: 'Get paginated list of active/published courses for students and visitors',
    }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number, example: 1 }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number, example: 12 }),
    (0, swagger_1.ApiQuery)({
        name: 'category',
        required: false,
        type: String,
        example: 'Web Development',
    }),
    (0, swagger_1.ApiQuery)({ name: 'search', required: false, type: String, example: 'React' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'List of published courses',
        type: [course_dto_1.CourseResponseDto],
    }),
    __param(0, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(1, (0, common_1.Query)('limit', new common_1.DefaultValuePipe(50), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('category')),
    __param(3, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String, String]),
    __metadata("design:returntype", Promise)
], PublicCoursesController.prototype, "getPublicCourses", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get course details by ID (Public)' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Course UUID',
        example: '0f8fad5b-d9cb-469f-a165-70867728950e',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Course details found',
        type: course_dto_1.CourseResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PublicCoursesController.prototype, "getPublicCourseById", null);
exports.PublicCoursesController = PublicCoursesController = __decorate([
    (0, swagger_1.ApiTags)('🌐 Public Courses'),
    (0, common_1.Controller)('public/courses'),
    __metadata("design:paramtypes", [courses_service_1.CoursesService])
], PublicCoursesController);
//# sourceMappingURL=public-courses.controller.js.map