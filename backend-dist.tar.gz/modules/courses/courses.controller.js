"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoursesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const courses_service_1 = require("./courses.service");
const jwt_admin_guard_1 = require("../../common/guards/jwt-admin.guard");
const roles_guard_1 = require("../../common/guards/roles.guard");
const roles_decorator_1 = require("../../common/decorators/roles.decorator");
const user_status_enum_1 = require("../../shared/enums/user-status.enum");
const current_admin_decorator_1 = require("../../common/decorators/current-admin.decorator");
const admin_entity_1 = require("../admins/entities/admin.entity");
const course_entity_1 = require("./entities/course.entity");
const course_dto_1 = require("./dto/course.dto");
let CoursesController = class CoursesController {
    constructor(coursesService) {
        this.coursesService = coursesService;
    }
    async findAll(page, limit, status, category, search) {
        return this.coursesService.findAll({
            page,
            limit,
            status,
            category,
            search,
        });
    }
    async findOne(id) {
        return this.coursesService.findOne(id);
    }
    async getPurchasedUsers(id, page, limit, search, status) {
        return this.coursesService.getPurchasedUsers(id, {
            page,
            limit,
            search,
            status,
        });
    }
    async create(dto, currentAdmin) {
        return this.coursesService.create(dto, currentAdmin.id);
    }
    async update(id, dto, currentAdmin) {
        return this.coursesService.update(id, dto, currentAdmin.id);
    }
    async updateStatus(id, dto, currentAdmin) {
        await this.coursesService.updateStatus(id, dto.status, currentAdmin.id);
        return { message: `Course status updated to ${dto.status}` };
    }
    async remove(id) {
        await this.coursesService.remove(id);
        return { message: 'Course deleted successfully' };
    }
    async getCourseStats() {
        return this.coursesService.getStats();
    }
};
exports.CoursesController = CoursesController;
__decorate([
    (0, common_1.Get)(),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'List all courses (Admin only)',
        description: 'Paginated list of courses with status, category, and search filters',
    }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number, example: 1 }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number, example: 10 }),
    (0, swagger_1.ApiQuery)({
        name: 'status',
        required: false,
        enum: course_entity_1.CourseStatus,
        example: 'active',
    }),
    (0, swagger_1.ApiQuery)({
        name: 'category',
        required: false,
        type: String,
        example: 'Web Design',
    }),
    (0, swagger_1.ApiQuery)({ name: 'search', required: false, type: String, example: 'web' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'List of courses retrieved',
        schema: {
            example: {
                data: [],
                total: 40,
                page: 1,
                limit: 10,
            },
        },
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    (0, swagger_1.ApiResponse)({ status: 403, description: 'Admin access required' }),
    __param(0, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(1, (0, common_1.Query)('limit', new common_1.DefaultValuePipe(10), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('status')),
    __param(3, (0, common_1.Query)('category')),
    __param(4, (0, common_1.Query)('search')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String, String, String]),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Get course by ID (Admin only)' }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Course UUID',
        example: '0f8fad5b-d9cb-469f-a165-70867728950e',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Course found',
        type: course_dto_1.CourseResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Get)(':id/purchased-users'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get purchased users for a course (Admin only)',
        description: 'Paginated list of users who purchased/enrolled in the course with their profile and enrollment details',
    }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Course UUID',
        example: '0f8fad5b-d9cb-469f-a165-70867728950e',
    }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number, example: 1 }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number, example: 20 }),
    (0, swagger_1.ApiQuery)({ name: 'status', required: false, type: String, example: 'active' }),
    (0, swagger_1.ApiQuery)({ name: 'search', required: false, type: String, example: 'john' }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'List of purchased users retrieved',
        type: course_dto_1.PurchasedUsersResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 401, description: 'Unauthorized' }),
    (0, swagger_1.ApiResponse)({ status: 403, description: 'Admin access required' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Query)('page', new common_1.DefaultValuePipe(1), common_1.ParseIntPipe)),
    __param(2, (0, common_1.Query)('limit', new common_1.DefaultValuePipe(20), common_1.ParseIntPipe)),
    __param(3, (0, common_1.Query)('search')),
    __param(4, (0, common_1.Query)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Number, Number, String, String]),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "getPurchasedUsers", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new course (Admin only)' }),
    (0, swagger_1.ApiBody)({ type: course_dto_1.CreateCourseDto }),
    (0, swagger_1.ApiResponse)({
        status: 201,
        description: 'Course created',
        type: course_dto_1.CourseResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Validation failed' }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [course_dto_1.CreateCourseDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "create", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Update course details (Admin only)' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Course UUID' }),
    (0, swagger_1.ApiBody)({ type: course_dto_1.UpdateCourseDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Course updated',
        type: course_dto_1.CourseResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, course_dto_1.UpdateCourseDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({ summary: 'Update course status (Admin only)' }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Course UUID' }),
    (0, swagger_1.ApiBody)({ type: course_dto_1.UpdateCourseStatusDto }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Course status updated' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_admin_decorator_1.CurrentAdmin)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, course_dto_1.UpdateCourseStatusDto,
        admin_entity_1.Admin]),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Delete course (Admin only)',
        description: 'Soft deletes the course from the catalog',
    }),
    (0, swagger_1.ApiParam)({ name: 'id', description: 'Course UUID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Course deleted' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Course not found' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)('stats/overview'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get course statistics (Admin only)',
        description: 'Total, active, published, draft, archived counts and enrollments for dashboard',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Course statistics',
        schema: {
            example: {
                total: 40,
                active: 18,
                published: 12,
                draft: 8,
                archived: 2,
                totalStudents: 1250,
                categories: 6,
            },
        },
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CoursesController.prototype, "getCourseStats", null);
exports.CoursesController = CoursesController = __decorate([
    (0, swagger_1.ApiTags)('📚 Courses'),
    (0, common_1.Controller)('courses'),
    (0, common_1.UseGuards)(jwt_admin_guard_1.JwtAdminGuard, roles_guard_1.RolesGuard),
    (0, roles_decorator_1.Roles)(user_status_enum_1.AdminRole.SUPER_ADMIN, user_status_enum_1.AdminRole.ADMIN),
    (0, swagger_1.ApiBearerAuth)('admin-access-token'),
    __metadata("design:paramtypes", [courses_service_1.CoursesService])
], CoursesController);
//# sourceMappingURL=courses.controller.js.map