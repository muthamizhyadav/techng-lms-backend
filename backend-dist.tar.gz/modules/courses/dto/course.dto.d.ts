import { CourseStatus } from '../entities/course.entity';
export declare class ModuleLessonDto {
    _id?: string;
    title: string;
    videoUrl?: string;
    duration?: number;
    order: number;
    type?: 'video' | 'quiz' | 'document';
}
export declare class ModuleDto {
    _id?: string;
    title: string;
    order: number;
    thumbnail?: string;
    lessons?: ModuleLessonDto[];
}
export declare class SessionVideoDto {
    _id?: string;
    title: string;
    videoUrl?: string;
    duration?: number;
    order: number;
    type?: 'video' | 'quiz' | 'document';
}
export declare class SessionDto {
    _id?: string;
    title: string;
    order: number;
    thumbnail?: string;
    videos?: SessionVideoDto[];
}
export declare class CreateCourseDto {
    title: string;
    description?: string;
    instructor?: string;
    category: string;
    status?: CourseStatus;
    students?: number;
    duration?: string;
    videoDuration?: string;
    level?: string;
    skills?: string[];
    price?: number;
    thumbnail?: string;
    videoUrl?: string;
    modules?: ModuleDto[];
    sessions?: SessionDto[];
}
declare const UpdateCourseDto_base: import("@nestjs/common").Type<Partial<CreateCourseDto>>;
export declare class UpdateCourseDto extends UpdateCourseDto_base {
}
export declare class UpdateCourseStatusDto {
    status: CourseStatus;
}
export declare class PurchasedUserQueryDto {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
}
export declare class PurchasedUserDto {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    avatar: string;
    enrollmentId: string;
    enrollmentStatus: string;
    progress: number;
    enrolledAt: Date;
    orderId: string;
}
export declare class PurchasedUsersResponseDto {
    data: PurchasedUserDto[];
    total: number;
    purchasedCount: number;
    page: number;
    limit: number;
}
export declare class CourseResponseDto {
    id: string;
    title: string;
    description: string;
    instructor: string;
    category: string;
    status: CourseStatus;
    students: number;
    duration: string;
    videoDuration: string;
    level: string;
    skills: string[];
    price: number;
    thumbnail: string;
    videoUrl: string;
    createdAt: Date;
    updatedAt: Date;
}
export {};
