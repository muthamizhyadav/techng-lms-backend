"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourseResponseDto = exports.PurchasedUsersResponseDto = exports.PurchasedUserDto = exports.PurchasedUserQueryDto = exports.UpdateCourseStatusDto = exports.UpdateCourseDto = exports.CreateCourseDto = exports.SessionDto = exports.SessionVideoDto = exports.ModuleDto = exports.ModuleLessonDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_2 = require("class-transformer");
const course_entity_1 = require("../entities/course.entity");
class ModuleLessonDto {
}
exports.ModuleLessonDto = ModuleLessonDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '507f1f77bcf86cd799439011',
        description: 'Stable lesson ID. Sent back unchanged when editing so enrollment progress keeps working.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], ModuleLessonDto.prototype, "_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Introduction to Java 21' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(3),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], ModuleLessonDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'https://r2.dev/lesson-1.mp4' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], ModuleLessonDto.prototype, "videoUrl", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 720, description: 'Duration in seconds' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], ModuleLessonDto.prototype, "duration", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1 }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], ModuleLessonDto.prototype, "order", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        enum: ['video', 'quiz', 'document'],
        default: 'video',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['video', 'quiz', 'document']),
    __metadata("design:type", String)
], ModuleLessonDto.prototype, "type", void 0);
class ModuleDto {
}
exports.ModuleDto = ModuleDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '507f1f77bcf86cd799439011',
        description: 'Stable module ID. Sent back unchanged when editing.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], ModuleDto.prototype, "_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Module 1: Java 21 Core Fundamentals' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(3),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], ModuleDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1 }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], ModuleDto.prototype, "order", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'https://cdn.example.com/session-1.jpg',
        description: 'Optional thumbnail image URL for this session/module',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], ModuleDto.prototype, "thumbnail", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ type: [ModuleLessonDto] }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => ModuleLessonDto),
    __metadata("design:type", Array)
], ModuleDto.prototype, "lessons", void 0);
class SessionVideoDto {
}
exports.SessionVideoDto = SessionVideoDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '507f1f77bcf86cd799439011',
        description: 'Stable video ID. Sent back unchanged when editing so enrollment progress keeps working.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], SessionVideoDto.prototype, "_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Session 1 – Course Introduction' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(2),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], SessionVideoDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'https://r2.dev/session-1-intro.mp4' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], SessionVideoDto.prototype, "videoUrl", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 720, description: 'Duration in seconds' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], SessionVideoDto.prototype, "duration", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1 }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SessionVideoDto.prototype, "order", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        enum: ['video', 'quiz', 'document'],
        default: 'video',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['video', 'quiz', 'document']),
    __metadata("design:type", String)
], SessionVideoDto.prototype, "type", void 0);
class SessionDto {
}
exports.SessionDto = SessionDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '507f1f77bcf86cd799439011',
        description: 'Stable session ID. Sent back unchanged when editing.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(120),
    __metadata("design:type", String)
], SessionDto.prototype, "_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'Session 1: Foundations & Setup' }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(3),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], SessionDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1 }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], SessionDto.prototype, "order", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'https://cdn.example.com/session-1.jpg',
        description: 'Optional thumbnail image URL for this session',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], SessionDto.prototype, "thumbnail", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        type: [SessionVideoDto],
        description: 'Videos (lessons) inside this session',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => SessionVideoDto),
    __metadata("design:type", Array)
], SessionDto.prototype, "videos", void 0);
class CreateCourseDto {
    constructor() {
        this.status = course_entity_1.CourseStatus.DRAFT;
        this.students = 0;
        this.price = 1;
    }
}
exports.CreateCourseDto = CreateCourseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'Advanced Web Development',
        description: 'Course title',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(3, { message: 'Course title must be at least 3 characters' }),
    (0, class_validator_1.MaxLength)(200),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'Master modern web development with React and Node.js',
        description: 'Course description',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(2000),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "description", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'Bola Johnson',
        description: 'Lead instructor name',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(150),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "instructor", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'Web Design',
        description: 'Course category / track',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "category", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'draft',
        description: 'Course status',
        enum: course_entity_1.CourseStatus,
        default: course_entity_1.CourseStatus.DRAFT,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(course_entity_1.CourseStatus, {
        message: 'Status must be draft, published, active, or archived',
    }),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 0,
        description: 'Number of enrolled students',
        default: 0,
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(0),
    __metadata("design:type", Number)
], CreateCourseDto.prototype, "students", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '6 Weeks (24 hours)',
        description: 'Estimated course duration',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(100),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "duration", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '12 min 30 sec',
        description: 'Intro / promo video duration (auto-detected on upload)',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(50),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "videoDuration", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'Beginner',
        description: 'Course difficulty level',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(50),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "level", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: ['JavaScript', 'React', 'Node.js'],
        description: 'Skills covered',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsString)({ each: true }),
    (0, class_validator_1.ArrayUnique)(),
    __metadata("design:type", Array)
], CreateCourseDto.prototype, "skills", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 4999,
        description: 'Course price in INR (minimum ₹1)',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1, { message: 'Course price must be at least ₹1' }),
    __metadata("design:type", Number)
], CreateCourseDto.prototype, "price", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'https://cdn.example.com/course.jpg',
        description: 'Course thumbnail URL',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "thumbnail", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'https://cdn.example.com/course.mp4',
        description: 'Course promo / intro video URL',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(500),
    __metadata("design:type", String)
], CreateCourseDto.prototype, "videoUrl", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        type: [ModuleDto],
        description: 'Course curriculum modules with lessons',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => ModuleDto),
    __metadata("design:type", Array)
], CreateCourseDto.prototype, "modules", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        type: [SessionDto],
        description: 'Course sessions with per-session videos (curriculum). Stored on the course as modules so students, progress tracking, and the curriculum player keep working.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => SessionDto),
    __metadata("design:type", Array)
], CreateCourseDto.prototype, "sessions", void 0);
class UpdateCourseDto extends (0, swagger_1.PartialType)(CreateCourseDto) {
}
exports.UpdateCourseDto = UpdateCourseDto;
class UpdateCourseStatusDto {
}
exports.UpdateCourseStatusDto = UpdateCourseStatusDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'published',
        description: 'New course status',
        enum: course_entity_1.CourseStatus,
    }),
    (0, class_validator_1.IsEnum)(course_entity_1.CourseStatus, {
        message: 'Status must be draft, published, active, or archived',
    }),
    __metadata("design:type", String)
], UpdateCourseStatusDto.prototype, "status", void 0);
class PurchasedUserQueryDto {
    constructor() {
        this.page = 1;
        this.limit = 20;
    }
}
exports.PurchasedUserQueryDto = PurchasedUserQueryDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 1 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PurchasedUserQueryDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 20 }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], PurchasedUserQueryDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'john' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PurchasedUserQueryDto.prototype, "search", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: 'active',
        enum: ['active', 'completed', 'dropped'],
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], PurchasedUserQueryDto.prototype, "status", void 0);
let PurchasedUserDto = class PurchasedUserDto {
};
exports.PurchasedUserDto = PurchasedUserDto;
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "id", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "firstName", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "lastName", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "email", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "phone", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "avatar", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "enrollmentId", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "enrollmentStatus", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Number)
], PurchasedUserDto.prototype, "progress", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Date)
], PurchasedUserDto.prototype, "enrolledAt", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], PurchasedUserDto.prototype, "orderId", void 0);
exports.PurchasedUserDto = PurchasedUserDto = __decorate([
    (0, class_transformer_2.Exclude)()
], PurchasedUserDto);
let PurchasedUsersResponseDto = class PurchasedUsersResponseDto {
};
exports.PurchasedUsersResponseDto = PurchasedUsersResponseDto;
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Array)
], PurchasedUsersResponseDto.prototype, "data", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Number)
], PurchasedUsersResponseDto.prototype, "total", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Number)
], PurchasedUsersResponseDto.prototype, "purchasedCount", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Number)
], PurchasedUsersResponseDto.prototype, "page", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Number)
], PurchasedUsersResponseDto.prototype, "limit", void 0);
exports.PurchasedUsersResponseDto = PurchasedUsersResponseDto = __decorate([
    (0, class_transformer_2.Exclude)()
], PurchasedUsersResponseDto);
let CourseResponseDto = class CourseResponseDto {
};
exports.CourseResponseDto = CourseResponseDto;
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "id", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "title", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "description", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "instructor", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "category", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "status", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Number)
], CourseResponseDto.prototype, "students", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "duration", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "videoDuration", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "level", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Array)
], CourseResponseDto.prototype, "skills", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Number)
], CourseResponseDto.prototype, "price", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "thumbnail", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", String)
], CourseResponseDto.prototype, "videoUrl", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Date)
], CourseResponseDto.prototype, "createdAt", void 0);
__decorate([
    (0, class_transformer_2.Expose)(),
    __metadata("design:type", Date)
], CourseResponseDto.prototype, "updatedAt", void 0);
exports.CourseResponseDto = CourseResponseDto = __decorate([
    (0, class_transformer_2.Exclude)()
], CourseResponseDto);
//# sourceMappingURL=course.dto.js.map