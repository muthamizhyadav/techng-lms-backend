import { HydratedDocument } from 'mongoose';
export declare enum CourseStatus {
    DRAFT = "draft",
    PUBLISHED = "published",
    ACTIVE = "active",
    ARCHIVED = "archived"
}
export type CourseDocument = HydratedDocument<Course>;
export declare class Course {
    _id: string;
    id: string;
    title: string;
    description: string;
    instructor: string;
    category: string;
    status: CourseStatus;
    students: number;
    duration: string;
    videoDuration: string;
    level: string;
    skills: string[];
    price: number;
    thumbnail: string;
    videoUrl: string;
    modules: Array<{
        _id?: string;
        title: string;
        order: number;
        thumbnail?: string | null;
        lessons: Array<{
            _id?: string;
            title: string;
            videoUrl: string;
            duration: number;
            order: number;
            type: 'video' | 'quiz' | 'document';
        }>;
    }>;
    createdByAdminId: string;
    updatedByAdminId: string;
    deletedAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const CourseSchema: import("mongoose").Schema<Course, import("mongoose").Model<Course, any, any, any, any, any, Course>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    title?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    description?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    instructor?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    category?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<CourseStatus, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    students?: import("mongoose").SchemaDefinitionProperty<number, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    duration?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    videoDuration?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    level?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    skills?: import("mongoose").SchemaDefinitionProperty<string[], Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    price?: import("mongoose").SchemaDefinitionProperty<number, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    thumbnail?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    videoUrl?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    modules?: import("mongoose").SchemaDefinitionProperty<{
        _id?: string;
        title: string;
        order: number;
        thumbnail?: string | null;
        lessons: Array<{
            _id?: string;
            title: string;
            videoUrl: string;
            duration: number;
            order: number;
            type: "video" | "quiz" | "document";
        }>;
    }[], Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdByAdminId?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedByAdminId?: import("mongoose").SchemaDefinitionProperty<string, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    deletedAt?: import("mongoose").SchemaDefinitionProperty<Date, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, Course, import("mongoose").Document<unknown, {}, Course, {}, import("mongoose").DefaultSchemaOptions> & Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, Course>;
