"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CoursesService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const course_entity_1 = require("./entities/course.entity");
const enrollment_entity_1 = require("../enrollments/entities/enrollment.entity");
const user_entity_1 = require("../users/entities/user.entity");
let CoursesService = class CoursesService {
    constructor(courseModel, enrollmentModel, userModel) {
        this.courseModel = courseModel;
        this.enrollmentModel = enrollmentModel;
        this.userModel = userModel;
    }
    async findAll(query) {
        const { page, limit, status, category, search } = query;
        const filter = { deletedAt: null };
        if (status) {
            filter.status = status;
        }
        if (category) {
            filter.category = category;
        }
        if (search && search.trim()) {
            const regex = new RegExp(search.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
            filter.$or = [
                { title: regex },
                { category: regex },
                { instructor: regex },
            ];
        }
        const [data, total] = await Promise.all([
            this.courseModel
                .find(filter)
                .sort({ createdAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .exec(),
            this.courseModel.countDocuments(filter),
        ]);
        return { data, total, page, limit };
    }
    async findOne(id) {
        const course = await this.courseModel.findOne({ _id: id, deletedAt: null });
        if (!course) {
            throw new common_1.NotFoundException(`Course with ID "${id}" not found`);
        }
        return course;
    }
    async create(createCourseDto, adminId) {
        const { sessions, modules, ...rest } = createCourseDto;
        const payload = {
            ...rest,
            createdByAdminId: adminId,
            updatedByAdminId: adminId,
        };
        if (sessions !== undefined) {
            payload.modules = sessions;
        }
        else if (modules !== undefined) {
            payload.modules = modules;
        }
        const savedCourse = await this.courseModel.create(payload);
        return savedCourse.toJSON();
    }
    async update(id, updateCourseDto, adminId) {
        await this.findOne(id);
        const { sessions, modules, ...rest } = updateCourseDto;
        const payload = {
            ...rest,
            updatedByAdminId: adminId,
        };
        if (sessions !== undefined) {
            payload.modules = sessions;
        }
        else if (modules !== undefined) {
            payload.modules = modules;
        }
        const updatedCourse = await this.courseModel.findOneAndUpdate({ _id: id, deletedAt: null }, payload, { new: true });
        return updatedCourse.toJSON();
    }
    async updateStatus(id, status, adminId) {
        await this.findOne(id);
        await this.courseModel.findOneAndUpdate({ _id: id, deletedAt: null }, { status, updatedByAdminId: adminId });
    }
    async remove(id) {
        await this.findOne(id);
        await this.courseModel.findOneAndUpdate({ _id: id, deletedAt: null }, { deletedAt: new Date() });
    }
    async getStats() {
        const [total, active, published, draft, archived, totalStudents, categories,] = await Promise.all([
            this.courseModel.countDocuments({ deletedAt: null }),
            this.courseModel.countDocuments({
                status: course_entity_1.CourseStatus.ACTIVE,
                deletedAt: null,
            }),
            this.courseModel.countDocuments({
                status: course_entity_1.CourseStatus.PUBLISHED,
                deletedAt: null,
            }),
            this.courseModel.countDocuments({
                status: course_entity_1.CourseStatus.DRAFT,
                deletedAt: null,
            }),
            this.courseModel.countDocuments({
                status: course_entity_1.CourseStatus.ARCHIVED,
                deletedAt: null,
            }),
            this.courseModel.aggregate([
                { $match: { deletedAt: null } },
                { $group: { _id: null, total: { $sum: '$students' } } },
            ]),
            this.courseModel.distinct('category', { deletedAt: null }),
        ]);
        return {
            total,
            active,
            published,
            draft,
            archived,
            totalStudents: totalStudents[0]?.total ?? 0,
            categories: categories.length,
        };
    }
    async getPurchasedUsers(courseId, query) {
        const course = await this.courseModel.findOne({
            _id: courseId,
            deletedAt: null,
        });
        if (!course) {
            throw new common_1.NotFoundException(`Course with ID "${courseId}" not found`);
        }
        const { page, limit, search, status } = query;
        const filter = { courseId };
        if (status) {
            filter.status = status;
        }
        let searchUserIds = null;
        if (search && search.trim()) {
            const regex = new RegExp(search.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
            const matchingUsers = await this.userModel
                .find({
                $or: [
                    { firstName: regex },
                    { lastName: regex },
                    { email: regex },
                    { phone: regex },
                ],
            })
                .select('_id')
                .exec();
            searchUserIds = matchingUsers.map((u) => u._id.toString());
            if (searchUserIds.length === 0) {
                return { data: [], total: 0, purchasedCount: 0, page, limit };
            }
            filter.userId = { $in: searchUserIds };
        }
        const [enrollments, total, purchasedCount] = await Promise.all([
            this.enrollmentModel
                .find(filter)
                .sort({ enrolledAt: -1 })
                .skip((page - 1) * limit)
                .limit(limit)
                .exec(),
            this.enrollmentModel.countDocuments(filter),
            this.enrollmentModel.countDocuments({ courseId }),
        ]);
        const userIds = enrollments.map((e) => e.userId);
        const users = userIds.length
            ? await this.userModel.find({ _id: { $in: userIds } })
            : [];
        const userMap = new Map();
        users.forEach((u) => {
            userMap.set(u._id.toString(), u);
        });
        const data = enrollments
            .map((enrollment) => {
            const user = userMap.get(enrollment.userId);
            if (!user)
                return null;
            const fullName = user.lastName
                ? `${user.firstName} ${user.lastName}`
                : user.firstName;
            return {
                id: user._id.toString(),
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
                phone: user.phone,
                avatar: user.avatar,
                enrollmentId: enrollment._id.toString(),
                enrollmentStatus: enrollment.status,
                progress: enrollment.progress,
                enrolledAt: enrollment.enrolledAt,
                orderId: enrollment.orderId,
                fullName,
            };
        })
            .filter(Boolean);
        return {
            data: data,
            total,
            purchasedCount,
            page,
            limit,
        };
    }
};
exports.CoursesService = CoursesService;
exports.CoursesService = CoursesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(course_entity_1.Course.name)),
    __param(1, (0, mongoose_1.InjectModel)(enrollment_entity_1.Enrollment.name)),
    __param(2, (0, mongoose_1.InjectModel)(user_entity_1.User.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model,
        mongoose_2.Model])
], CoursesService);
//# sourceMappingURL=courses.service.js.map