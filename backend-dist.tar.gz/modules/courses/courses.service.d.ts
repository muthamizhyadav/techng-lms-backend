import { Model } from 'mongoose';
import { Course, CourseDocument, CourseStatus } from './entities/course.entity';
import { EnrollmentDocument } from '../enrollments/entities/enrollment.entity';
import { UserDocument } from '../users/entities/user.entity';
import { CreateCourseDto, UpdateCourseDto } from './dto/course.dto';
export interface CourseQuery {
    page: number;
    limit: number;
    status?: CourseStatus;
    category?: string;
    search?: string;
}
export declare class CoursesService {
    private readonly courseModel;
    private readonly enrollmentModel;
    private readonly userModel;
    constructor(courseModel: Model<CourseDocument>, enrollmentModel: Model<EnrollmentDocument>, userModel: Model<UserDocument>);
    findAll(query: CourseQuery): Promise<{
        data: Course[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<CourseDocument>;
    create(createCourseDto: CreateCourseDto, adminId: string): Promise<Course>;
    update(id: string, updateCourseDto: UpdateCourseDto, adminId: string): Promise<Course>;
    updateStatus(id: string, status: CourseStatus, adminId: string): Promise<void>;
    remove(id: string): Promise<void>;
    getStats(): Promise<{
        total: number;
        active: number;
        published: number;
        draft: number;
        archived: number;
        totalStudents: number;
        categories: number;
    }>;
    getPurchasedUsers(courseId: string, query: {
        page: number;
        limit: number;
        search?: string;
        status?: string;
    }): Promise<{
        data: Array<Record<string, unknown>>;
        total: number;
        purchasedCount: number;
        page: number;
        limit: number;
    }>;
}
