import { CoursesService } from './courses.service';
import { Admin } from "../admins/entities/admin.entity";
import { CourseStatus } from './entities/course.entity';
import { CreateCourseDto, UpdateCourseDto, UpdateCourseStatusDto } from './dto/course.dto';
export declare class CoursesController {
    private readonly coursesService;
    constructor(coursesService: CoursesService);
    findAll(page: number, limit: number, status?: CourseStatus, category?: string, search?: string): Promise<{
        data: import("./entities/course.entity").Course[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<import("mongoose").Document<unknown, {}, import("./entities/course.entity").Course, {}, import("mongoose").DefaultSchemaOptions> & import("./entities/course.entity").Course & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    getPurchasedUsers(id: string, page: number, limit: number, search?: string, status?: string): Promise<{
        data: Array<Record<string, unknown>>;
        total: number;
        purchasedCount: number;
        page: number;
        limit: number;
    }>;
    create(dto: CreateCourseDto, currentAdmin: Admin): Promise<import("./entities/course.entity").Course>;
    update(id: string, dto: UpdateCourseDto, currentAdmin: Admin): Promise<import("./entities/course.entity").Course>;
    updateStatus(id: string, dto: UpdateCourseStatusDto, currentAdmin: Admin): Promise<{
        message: string;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
    getCourseStats(): Promise<{
        total: number;
        active: number;
        published: number;
        draft: number;
        archived: number;
        totalStudents: number;
        categories: number;
    }>;
}
