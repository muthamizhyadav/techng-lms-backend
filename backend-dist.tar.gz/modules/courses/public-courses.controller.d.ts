import { CoursesService } from './courses.service';
import { CourseStatus } from './entities/course.entity';
export declare class PublicCoursesController {
    private readonly coursesService;
    constructor(coursesService: CoursesService);
    getPublicCourses(page: number, limit: number, category?: string, search?: string): Promise<{
        data: import("./entities/course.entity").Course[];
        total: number;
        page: number;
        limit: number;
    }>;
    getPublicCourseById(id: string): Promise<{
        modules: any[];
        _id: string;
        id: string;
        title: string;
        description: string;
        instructor: string;
        category: string;
        status: CourseStatus;
        students: number;
        duration: string;
        videoDuration: string;
        level: string;
        skills: string[];
        price: number;
        thumbnail: string;
        videoUrl: string;
        createdByAdminId: string;
        updatedByAdminId: string;
        deletedAt: Date;
        createdAt: Date;
        updatedAt: Date;
        __v: number;
    }>;
}
