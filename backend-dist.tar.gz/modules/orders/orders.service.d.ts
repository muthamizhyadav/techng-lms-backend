import { Model } from 'mongoose';
import { ConfigService } from '@nestjs/config';
import { Order, OrderDocument } from './entities/order.entity';
import { CartService } from '../cart/cart.service';
import { EnrollmentsService } from '../enrollments/enrollments.service';
import { UsersService } from '../users/users.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CourseDocument } from '../courses/entities/course.entity';
import { CreateOrderDto, VerifyPaymentDto, CheckoutResponseDto } from './dto/order.dto';
export declare class OrdersService {
    private readonly orderModel;
    private readonly courseModel;
    private readonly configService;
    private readonly cartService;
    private readonly enrollmentsService;
    private readonly usersService;
    private readonly notificationsService;
    private readonly logger;
    private razorpayInstance;
    constructor(orderModel: Model<OrderDocument>, courseModel: Model<CourseDocument>, configService: ConfigService, cartService: CartService, enrollmentsService: EnrollmentsService, usersService: UsersService, notificationsService: NotificationsService);
    private getRazorpay;
    createCheckoutOrder(userId: string, dto: CreateOrderDto): Promise<CheckoutResponseDto>;
    private ensurePurchasablePhone;
    verifyPayment(userId: string, dto: VerifyPaymentDto): Promise<{
        success: boolean;
        message: string;
        order: OrderDocument;
    }>;
    getMyOrders(userId: string): Promise<Order[]>;
    private notifyAdminsOfPurchase;
}
