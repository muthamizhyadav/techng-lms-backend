"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const orders_service_1 = require("./orders.service");
const jwt_auth_guard_1 = require("../../common/guards/jwt-auth.guard");
const current_user_decorator_1 = require("../../common/decorators/current-user.decorator");
const user_entity_1 = require("../users/entities/user.entity");
const order_dto_1 = require("./dto/order.dto");
let OrdersController = class OrdersController {
    constructor(ordersService) {
        this.ordersService = ordersService;
    }
    async checkout(user, dto) {
        return this.ordersService.createCheckoutOrder(user.id, dto);
    }
    async verifyPayment(user, dto) {
        return this.ordersService.verifyPayment(user.id, dto);
    }
    async getMyOrders(user) {
        return this.ordersService.getMyOrders(user.id);
    }
};
exports.OrdersController = OrdersController;
__decorate([
    (0, common_1.Post)('checkout'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Initiate Razorpay checkout order for student cart or specific courses',
    }),
    (0, swagger_1.ApiBody)({ type: order_dto_1.CreateOrderDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Razorpay order created for payment processing',
        type: order_dto_1.CheckoutResponseDto,
    }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Cart empty or invalid items' }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'A phone number is required before purchase (code: PHONE_REQUIRED)',
        schema: {
            example: {
                statusCode: 400,
                code: 'PHONE_REQUIRED',
                field: 'phone',
                message: 'Please add your phone number before purchasing a course.',
                error: 'Bad Request',
            },
        },
    }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User, order_dto_1.CreateOrderDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "checkout", null);
__decorate([
    (0, common_1.Post)('verify'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Verify Razorpay payment signature and complete enrollment',
    }),
    (0, swagger_1.ApiBody)({ type: order_dto_1.VerifyPaymentDto }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Payment verified and courses enrolled',
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid signature or payment failed',
    }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User,
        order_dto_1.VerifyPaymentDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "verifyPayment", null);
__decorate([
    (0, common_1.Get)('my-orders'),
    (0, swagger_1.ApiOperation)({ summary: 'Get order and payment history for student' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Order history retrieved' }),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_entity_1.User]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getMyOrders", null);
exports.OrdersController = OrdersController = __decorate([
    (0, swagger_1.ApiTags)('💳 Orders & Checkout'),
    (0, common_1.Controller)('orders'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, swagger_1.ApiBearerAuth)('student-access-token'),
    __metadata("design:paramtypes", [orders_service_1.OrdersService])
], OrdersController);
//# sourceMappingURL=orders.controller.js.map