"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var OrdersService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const config_1 = require("@nestjs/config");
const crypto = __importStar(require("crypto"));
const razorpay_1 = __importDefault(require("razorpay"));
const order_entity_1 = require("./entities/order.entity");
const cart_service_1 = require("../cart/cart.service");
const enrollments_service_1 = require("../enrollments/enrollments.service");
const users_service_1 = require("../users/users.service");
const notifications_service_1 = require("../notifications/notifications.service");
const notification_entity_1 = require("../notifications/entities/notification.entity");
const course_entity_1 = require("../courses/entities/course.entity");
let OrdersService = OrdersService_1 = class OrdersService {
    constructor(orderModel, courseModel, configService, cartService, enrollmentsService, usersService, notificationsService) {
        this.orderModel = orderModel;
        this.courseModel = courseModel;
        this.configService = configService;
        this.cartService = cartService;
        this.enrollmentsService = enrollmentsService;
        this.usersService = usersService;
        this.notificationsService = notificationsService;
        this.logger = new common_1.Logger(OrdersService_1.name);
        this.razorpayInstance = null;
        const keyId = this.configService.get('razorpay.keyId');
        const keySecret = this.configService.get('razorpay.keySecret');
        if (keyId && keySecret) {
            this.razorpayInstance = new razorpay_1.default({
                key_id: keyId,
                key_secret: keySecret,
            });
        }
    }
    getRazorpay() {
        const keyId = this.configService.get('razorpay.keyId');
        const keySecret = this.configService.get('razorpay.keySecret');
        if (!keyId || !keySecret || keyId === 'rzp_test_placeholder_key_id') {
            this.logger.warn('Razorpay keys are not configured or set to placeholder. Please update RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in .env');
        }
        if (!this.razorpayInstance && keyId && keySecret) {
            this.razorpayInstance = new razorpay_1.default({
                key_id: keyId,
                key_secret: keySecret,
            });
        }
        return this.razorpayInstance;
    }
    async createCheckoutOrder(userId, dto) {
        let orderItems = [];
        if (dto.courseIds && dto.courseIds.length > 0) {
            const courses = await this.courseModel.find({
                _id: { $in: dto.courseIds },
                deletedAt: null,
            });
            if (courses.length !== dto.courseIds.length) {
                throw new common_1.BadRequestException('One or more selected courses were not found');
            }
            orderItems = courses.map((c) => ({
                courseId: c._id.toString(),
                title: c.title,
                price: c.price || 0,
                thumbnail: c.thumbnail || '',
            }));
        }
        else {
            const cart = await this.cartService.getCart(userId);
            if (!cart.items || cart.items.length === 0) {
                throw new common_1.BadRequestException('Your cart is empty');
            }
            orderItems = cart.items.map((item) => ({
                courseId: item.courseId,
                title: item.title,
                price: item.price || 0,
                thumbnail: item.thumbnail || '',
            }));
        }
        for (const item of orderItems) {
            const enrolled = await this.enrollmentsService.isEnrolled(userId, item.courseId);
            if (enrolled) {
                throw new common_1.BadRequestException(`You are already enrolled in "${item.title}"`);
            }
        }
        await this.ensurePurchasablePhone(userId, dto.phone);
        const totalAmount = orderItems.reduce((sum, item) => sum + item.price, 0);
        const finalAmount = totalAmount < 1 ? 1 : totalAmount;
        const amountInPaise = Math.round(finalAmount * 100);
        const keyId = this.configService.get('razorpay.keyId') || '';
        const keySecret = this.configService.get('razorpay.keySecret') || '';
        const currency = this.configService.get('razorpay.currency') || 'INR';
        let razorpayOrderId = `order_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
        if (keyId && keySecret && keyId !== 'rzp_test_placeholder_key_id') {
            try {
                const rzp = this.getRazorpay();
                const rzpOrder = await rzp.orders.create({
                    amount: amountInPaise,
                    currency,
                    receipt: `rcpt_${Date.now().toString().slice(-8)}`,
                    notes: {
                        userId,
                        courseCount: orderItems.length.toString(),
                    },
                });
                razorpayOrderId = rzpOrder.id;
            }
            catch (error) {
                this.logger.error('Error creating Razorpay order:', error);
                throw new common_1.BadRequestException(error?.error?.description ||
                    error?.message ||
                    'Failed to create payment order with Razorpay');
            }
        }
        const order = await this.orderModel.create({
            userId,
            items: orderItems,
            totalAmount: finalAmount,
            currency,
            razorpayOrderId,
            status: order_entity_1.OrderStatus.CREATED,
        });
        return {
            orderId: order._id.toString(),
            razorpayOrderId,
            amount: finalAmount,
            amountInPaise,
            currency,
            keyId,
        };
    }
    async ensurePurchasablePhone(userId, phone) {
        const normalizedPhone = phone?.trim();
        if (normalizedPhone) {
            await this.usersService.update(userId, { phone: normalizedPhone });
            return;
        }
        const user = await this.usersService.findOne(userId);
        if (!user.phone || !user.phone.trim()) {
            throw new common_1.BadRequestException({
                statusCode: 400,
                error: 'Bad Request',
                code: 'PHONE_REQUIRED',
                field: 'phone',
                message: 'Please add your phone number before purchasing a course.',
            });
        }
    }
    async verifyPayment(userId, dto) {
        const order = await this.orderModel.findOne({
            razorpayOrderId: dto.razorpayOrderId,
            userId,
        });
        if (!order) {
            throw new common_1.NotFoundException('Order not found for this payment');
        }
        if (order.status === order_entity_1.OrderStatus.PAID) {
            return {
                success: true,
                message: 'Payment already verified',
                order,
            };
        }
        const keySecret = this.configService.get('razorpay.keySecret') || '';
        const keyId = this.configService.get('razorpay.keyId') || '';
        if (keySecret && keyId !== 'rzp_test_placeholder_key_id') {
            const generatedSignature = crypto
                .createHmac('sha256', keySecret)
                .update(`${dto.razorpayOrderId}|${dto.razorpayPaymentId}`)
                .digest('hex');
            if (generatedSignature !== dto.razorpaySignature) {
                order.status = order_entity_1.OrderStatus.FAILED;
                await order.save();
                throw new common_1.BadRequestException('Invalid payment signature verification');
            }
        }
        order.status = order_entity_1.OrderStatus.PAID;
        order.razorpayPaymentId = dto.razorpayPaymentId;
        order.razorpaySignature = dto.razorpaySignature;
        order.paidAt = new Date();
        await order.save();
        for (const item of order.items) {
            await this.enrollmentsService.enrollUserInCourse(userId, item.courseId, order._id.toString());
        }
        await this.cartService.clearCart(userId);
        void this.notifyAdminsOfPurchase(userId, order);
        return {
            success: true,
            message: 'Payment verified and courses enrolled successfully',
            order,
        };
    }
    async getMyOrders(userId) {
        return this.orderModel.find({ userId }).sort({ createdAt: -1 }).exec();
    }
    async notifyAdminsOfPurchase(userId, order) {
        try {
            const user = await this.usersService.findOne(userId);
            const name = [user.firstName, user.lastName].filter(Boolean).join(' ') || user.email;
            const courseTitles = order.items.map((item) => item.title);
            const summary = courseTitles.length === 1
                ? `"${courseTitles[0]}"`
                : `${courseTitles.length} courses`;
            await this.notificationsService.notifyAdmins({
                title: 'Course purchased',
                body: `${name} purchased ${summary} for ${order.currency} ${order.totalAmount}.`,
                type: notification_entity_1.AdminNotificationType.COURSE_PURCHASED,
                data: {
                    type: 'course_purchased',
                    orderId: order._id.toString(),
                    userId,
                },
                link: '/dashboard',
            });
        }
        catch (error) {
            this.logger.warn(`Could not build purchase notification: ${error.message}`);
        }
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = OrdersService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(order_entity_1.Order.name)),
    __param(1, (0, mongoose_1.InjectModel)(course_entity_1.Course.name)),
    __metadata("design:paramtypes", [mongoose_2.Model,
        mongoose_2.Model,
        config_1.ConfigService,
        cart_service_1.CartService,
        enrollments_service_1.EnrollmentsService,
        users_service_1.UsersService,
        notifications_service_1.NotificationsService])
], OrdersService);
//# sourceMappingURL=orders.service.js.map