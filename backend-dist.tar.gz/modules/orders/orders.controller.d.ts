import { OrdersService } from './orders.service';
import { User } from "../users/entities/user.entity";
import { CreateOrderDto, VerifyPaymentDto, CheckoutResponseDto } from './dto/order.dto';
export declare class OrdersController {
    private readonly ordersService;
    constructor(ordersService: OrdersService);
    checkout(user: User, dto: CreateOrderDto): Promise<CheckoutResponseDto>;
    verifyPayment(user: User, dto: VerifyPaymentDto): Promise<{
        success: boolean;
        message: string;
        order: import("./entities/order.entity").OrderDocument;
    }>;
    getMyOrders(user: User): Promise<import("./entities/order.entity").Order[]>;
}
