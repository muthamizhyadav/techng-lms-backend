export declare class CreateOrderDto {
    courseIds?: string[];
    phone?: string;
}
export declare class VerifyPaymentDto {
    razorpayOrderId: string;
    razorpayPaymentId: string;
    razorpaySignature: string;
}
export declare class CheckoutResponseDto {
    orderId: string;
    razorpayOrderId: string;
    amount: number;
    amountInPaise: number;
    currency: string;
    keyId: string;
}
