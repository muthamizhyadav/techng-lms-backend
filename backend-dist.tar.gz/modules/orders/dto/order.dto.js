"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckoutResponseDto = exports.VerifyPaymentDto = exports.CreateOrderDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class CreateOrderDto {
}
exports.CreateOrderDto = CreateOrderDto;
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: ['0f8fad5b-d9cb-469f-a165-70867728950e'],
        description: 'Optional list of specific course IDs to checkout. If omitted, checks out all items in cart.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.IsUUID)('4', { each: true, message: 'Each course ID must be a valid UUID' }),
    __metadata("design:type", Array)
], CreateOrderDto.prototype, "courseIds", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({
        example: '+91 9876543210',
        description: 'Contact phone number. Required to start a purchase; if the profile has no phone, this value is saved to it.',
    }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MaxLength)(20),
    (0, class_validator_1.Matches)(/^\+?[0-9\s-]{10,20}$/, {
        message: 'Please provide a valid phone number',
    }),
    __metadata("design:type", String)
], CreateOrderDto.prototype, "phone", void 0);
class VerifyPaymentDto {
}
exports.VerifyPaymentDto = VerifyPaymentDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'order_Nx8YdF3Q1z2AbC',
        description: 'Razorpay order ID returned during checkout',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'razorpayOrderId is required' }),
    __metadata("design:type", String)
], VerifyPaymentDto.prototype, "razorpayOrderId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: 'pay_Nx8ZkL7M4p5QeR',
        description: 'Razorpay payment ID from frontend checkout modal',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'razorpayPaymentId is required' }),
    __metadata("design:type", String)
], VerifyPaymentDto.prototype, "razorpayPaymentId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        example: '9ef8a23078a9c3d4...',
        description: 'Razorpay signature from frontend checkout modal',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)({ message: 'razorpaySignature is required' }),
    __metadata("design:type", String)
], VerifyPaymentDto.prototype, "razorpaySignature", void 0);
class CheckoutResponseDto {
}
exports.CheckoutResponseDto = CheckoutResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'order_uuid' }),
    __metadata("design:type", String)
], CheckoutResponseDto.prototype, "orderId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'order_Nx8YdF3Q1z2AbC' }),
    __metadata("design:type", String)
], CheckoutResponseDto.prototype, "razorpayOrderId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 4999 }),
    __metadata("design:type", Number)
], CheckoutResponseDto.prototype, "amount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 499900 }),
    __metadata("design:type", Number)
], CheckoutResponseDto.prototype, "amountInPaise", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'INR' }),
    __metadata("design:type", String)
], CheckoutResponseDto.prototype, "currency", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'rzp_test_placeholder_key_id' }),
    __metadata("design:type", String)
], CheckoutResponseDto.prototype, "keyId", void 0);
//# sourceMappingURL=order.dto.js.map