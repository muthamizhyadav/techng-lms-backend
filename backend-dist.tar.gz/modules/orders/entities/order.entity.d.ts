import { HydratedDocument } from 'mongoose';
export type OrderDocument = HydratedDocument<Order>;
export declare enum OrderStatus {
    CREATED = "created",
    PAID = "paid",
    FAILED = "failed",
    REFUNDED = "refunded"
}
export declare class OrderItem {
    courseId: string;
    title: string;
    price: number;
    thumbnail: string;
}
export declare const OrderItemSchema: import("mongoose").Schema<OrderItem, import("mongoose").Model<OrderItem, any, any, any, any, any, OrderItem>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, OrderItem, import("mongoose").Document<unknown, {}, OrderItem, {
    id: string;
}, import("mongoose").DefaultSchemaOptions> & Omit<OrderItem & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, "id"> & import("mongoose").HydratedDocumentOverrides<{
    id: string;
}>, {
    courseId?: import("mongoose").SchemaDefinitionProperty<string, OrderItem, import("mongoose").Document<unknown, {}, OrderItem, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<OrderItem & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    title?: import("mongoose").SchemaDefinitionProperty<string, OrderItem, import("mongoose").Document<unknown, {}, OrderItem, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<OrderItem & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    price?: import("mongoose").SchemaDefinitionProperty<number, OrderItem, import("mongoose").Document<unknown, {}, OrderItem, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<OrderItem & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
    thumbnail?: import("mongoose").SchemaDefinitionProperty<string, OrderItem, import("mongoose").Document<unknown, {}, OrderItem, {
        id: string;
    }, import("mongoose").DefaultSchemaOptions> & Omit<OrderItem & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, "id"> & import("mongoose").HydratedDocumentOverrides<{
        id: string;
    }>>;
}, OrderItem>;
export declare class Order {
    _id: string;
    id: string;
    userId: string;
    items: OrderItem[];
    totalAmount: number;
    currency: string;
    razorpayOrderId: string;
    razorpayPaymentId: string;
    razorpaySignature: string;
    status: OrderStatus;
    paidAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare const OrderSchema: import("mongoose").Schema<Order, import("mongoose").Model<Order, any, any, any, any, any, Order>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
    _id: string;
}> & {
    __v: number;
}, {
    _id?: import("mongoose").SchemaDefinitionProperty<string, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    id?: import("mongoose").SchemaDefinitionProperty<string, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    userId?: import("mongoose").SchemaDefinitionProperty<string, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    items?: import("mongoose").SchemaDefinitionProperty<OrderItem[], Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    totalAmount?: import("mongoose").SchemaDefinitionProperty<number, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    currency?: import("mongoose").SchemaDefinitionProperty<string, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    razorpayOrderId?: import("mongoose").SchemaDefinitionProperty<string, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    razorpayPaymentId?: import("mongoose").SchemaDefinitionProperty<string, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    razorpaySignature?: import("mongoose").SchemaDefinitionProperty<string, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    status?: import("mongoose").SchemaDefinitionProperty<OrderStatus, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    paidAt?: import("mongoose").SchemaDefinitionProperty<Date, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    createdAt?: import("mongoose").SchemaDefinitionProperty<Date, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
    updatedAt?: import("mongoose").SchemaDefinitionProperty<Date, Order, import("mongoose").Document<unknown, {}, Order, {}, import("mongoose").DefaultSchemaOptions> & Order & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, Order>;
