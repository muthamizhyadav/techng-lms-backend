// src/modules/auth/auth.controller.ts

import {
  Controller,
  Post,
  Get,
  Delete,
  Body,
  Param,
  HttpCode,
  HttpStatus,
  UseGuards,
  Req,
  Res,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiBody,
} from '@nestjs/swagger';
import { AuthService, StudentLoginContext } from './auth.service';
import { JwtAuthGuard } from '@common/guards/jwt-auth.guard';
import { CurrentUser } from '@common/decorators/current-user.decorator';
import {
  ApproveDeviceLoginDto,
  ForgotPasswordDto,
  RefreshTokenDto,
  StudentLoginDto,
  StudentRegisterDto,
  StudentResetPasswordDto,
} from './dto/auth.dto';
import { User } from '@modules/users/entities/user.entity';
import { UserResponseDto } from '../users/dto/user.dto';
import { AuthGuard } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { Request, Response } from 'express';
import {
  GoogleAuthGuard,
  OAUTH_NONCE_COOKIE,
} from './strategies/google-auth.guard';

@ApiTags('🎓 Student Auth')
@Controller('auth/student')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly configService: ConfigService,
  ) {}

  // ═══════════════════════════════════════════════════
  // ║  STUDENT REGISTER                               ║
  // ═══════════════════════════════════════════════════

  @Post('register')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Register a new student account' })
  @ApiBody({ type: StudentRegisterDto })
  @ApiResponse({
    status: 201,
    description: 'Student registered successfully',
    schema: {
      example: {
        accessToken: 'eyJhbGciOiJIUzI1NiIs...',
        refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
        user: {
          id: '0f8fad5b-d9cb-469f-a165-70867728950e',
          email: 'rahul@email.com',
          firstName: 'Rahul',
          lastName: 'Kumar',
          status: 'pending',
        },
      },
    },
  })
  @ApiResponse({ status: 409, description: 'Email already registered' })
  @ApiResponse({ status: 400, description: 'Validation failed' })
  async register(@Body() dto: StudentRegisterDto, @Req() req: Request) {
    return this.authService.studentRegister(dto, this.loginContext(req));
  }

  // ═══════════════════════════════════════════════════
  // ║  STUDENT LOGIN                                  ║
  // ═══════════════════════════════════════════════════

  @Post('login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Student login' })
  @ApiBody({ type: StudentLoginDto })
  @ApiResponse({
    status: 200,
    description: 'Login successful',
    schema: {
      example: {
        accessToken: 'eyJhbGciOiJIUzI1NiIs...',
        refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
        user: {
          id: '0f8fad5b-d9cb-469f-a165-70867728950e',
          email: 'rahul@email.com',
          firstName: 'Rahul',
          lastName: 'Kumar',
        },
      },
    },
  })
  @ApiResponse({ status: 401, description: 'Invalid email or password' })
  @ApiResponse({ status: 403, description: 'Account not active' })
  @ApiResponse({
    status: 409,
    description:
      'Account is already logged in on another device. Show the active device, then call POST /auth/student/login/approve with the approvalToken to sign the other device out and continue. Clients that cannot show a prompt may resend the login with logoutOtherDevices=true.',
    schema: {
      example: {
        statusCode: 409,
        code: 'ALREADY_LOGGED_IN',
        message:
          'Your account is already active on another device. Sign out of that device to continue here.',
        error: 'Conflict',
        activeSessions: [
          {
            deviceName: 'Chrome on Windows',
            platform: 'web',
            ipAddress: '203.0.113.24',
            loggedInAt: '2026-10-21T08:55:12.000Z',
            lastActiveAt: '2026-10-21T09:12:44.000Z',
            expiresAt: '2026-10-28T08:55:12.000Z',
          },
        ],
        approvalToken: 'eyJhbGciOiJIUzI1NiIs...',
        approvalExpiresInSeconds: 300,
      },
    },
  })
  @ApiResponse({ status: 400, description: 'Validation failed' })
  async login(@Body() dto: StudentLoginDto, @Req() req: Request) {
    return this.authService.studentLogin(dto, this.loginContext(req));
  }

  // ═══════════════════════════════════════════════════
  // ║  APPROVE DEVICE TAKEOVER                        ║
  // ═══════════════════════════════════════════════════

  @Post('login/approve')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary:
      'Approve signing out the other device and finish logging in on this one',
  })
  @ApiBody({ type: ApproveDeviceLoginDto })
  @ApiResponse({
    status: 200,
    description: 'Other device signed out; this device is now logged in',
    schema: {
      example: {
        accessToken: 'eyJhbGciOiJIUzI1NiIs...',
        refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
        user: {
          id: '0f8fad5b-d9cb-469f-a165-70867728950e',
          email: 'rahul@email.com',
          firstName: 'Rahul',
          lastName: 'Kumar',
        },
      },
    },
  })
  @ApiResponse({
    status: 401,
    description: 'Approval token missing, expired or issued for another device',
  })
  async approveDeviceLogin(
    @Body() dto: ApproveDeviceLoginDto,
    @Req() req: Request,
  ) {
    return this.authService.approveDeviceLogin(dto, this.loginContext(req));
  }

  // ═══════════════════════════════════════════════════
  // ║  PASSWORD RESET                                 ║
  // ═══════════════════════════════════════════════════

  @Post('forgot-password')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Request a student password reset email',
    description:
      'Sends a single-use reset link when the email belongs to a student account. Always responds with the same message to prevent account enumeration.',
  })
  @ApiBody({ type: ForgotPasswordDto })
  @ApiResponse({ status: 200, description: 'Reset email requested.' })
  @ApiResponse({ status: 400, description: 'Validation failed' })
  async forgotPassword(@Body() dto: ForgotPasswordDto) {
    return this.authService.studentForgotPassword(dto);
  }

  @Post('reset-password')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Reset a student password with an emailed token',
  })
  @ApiBody({ type: StudentResetPasswordDto })
  @ApiResponse({ status: 200, description: 'Password reset successfully.' })
  @ApiResponse({ status: 400, description: 'Invalid or expired reset token' })
  async resetPassword(@Body() dto: StudentResetPasswordDto) {
    return this.authService.studentResetPassword(dto);
  }

  // ═══════════════════════════════════════════════════
  // ║  REFRESH TOKEN                                  ║
  // ═══════════════════════════════════════════════════

  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Refresh access token using refresh token' })
  @ApiBody({ type: RefreshTokenDto })
  @ApiResponse({
    status: 200,
    description: 'New tokens generated',
    schema: {
      example: {
        accessToken: 'eyJhbGciOiJIUzI1NiIs...',
        refreshToken: 'eyJhbGciOiJIUzI1NiIs...',
      },
    },
  })
  @ApiResponse({ status: 401, description: 'Invalid or expired refresh token' })
  @ApiResponse({ status: 400, description: 'Validation failed' })
  async refresh(@Body() dto: RefreshTokenDto) {
    return this.authService.studentRefresh(dto);
  }

  // ═══════════════════════════════════════════════════
  // ║  LOGOUT                                         ║
  // ═══════════════════════════════════════════════════

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth('student-access-token')
  @ApiOperation({
    summary: 'Logout student (revokes the current device session)',
  })
  @ApiResponse({ status: 200, description: 'Logged out successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async logout(@CurrentUser('id') userId: string, @Req() req: Request) {
    await this.authService.studentLogout(userId, this.currentSessionId(req));
    return { message: 'Logged out successfully' };
  }

  // ═══════════════════════════════════════════════════
  // ║  DEVICE SESSIONS                                ║
  // ═══════════════════════════════════════════════════

  @Get('sessions')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('student-access-token')
  @ApiOperation({ summary: 'List active device sessions for this student' })
  @ApiResponse({ status: 200, description: 'Active sessions retrieved' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async listSessions(@CurrentUser('id') userId: string, @Req() req: Request) {
    return this.authService.getStudentSessions(
      userId,
      this.currentSessionId(req),
    );
  }

  @Delete('sessions')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth('student-access-token')
  @ApiOperation({ summary: 'Logout student from all devices' })
  @ApiResponse({ status: 200, description: 'Logged out from all devices' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async logoutAll(@CurrentUser('id') userId: string) {
    return this.authService.studentLogoutAll(userId);
  }

  @Delete('sessions/:sessionId')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth('student-access-token')
  @ApiOperation({ summary: 'Logout one device session by id' })
  @ApiResponse({ status: 200, description: 'Device logged out successfully' })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  @ApiResponse({ status: 404, description: 'Session not found' })
  async logoutDevice(
    @CurrentUser('id') userId: string,
    @Param('sessionId') sessionId: string,
    @Req() req: Request,
  ) {
    return this.authService.revokeStudentSession(
      userId,
      sessionId,
      this.currentSessionId(req),
    );
  }

  // ═══════════════════════════════════════════════════
  // ║  GET CURRENT STUDENT PROFILE                    ║
  // ═══════════════════════════════════════════════════

  @Get('me')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('student-access-token')
  @ApiOperation({ summary: 'Get current student profile' })
  @ApiResponse({
    status: 200,
    description: 'Student profile retrieved',
    type: UserResponseDto,
  })
  @ApiResponse({ status: 401, description: 'Unauthorized' })
  async getProfile(@CurrentUser() user: User) {
    return this.authService.getStudentProfile(user.id);
  }

  // ═══════════════════════════════════════════════════
  // ║  GOOGLE OAUTH                                   ║
  // ═══════════════════════════════════════════════════

  @Get('google')
  @UseGuards(GoogleAuthGuard)
  @ApiOperation({ summary: 'Initiate Google OAuth login' })
  async googleAuth() {
    // Guard redirects to Google
  }

  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  @ApiOperation({ summary: 'Google OAuth callback' })
  async googleAuthCallback(@Req() req: Request, @Res() res: Response) {
    const user = req.user as any;
    const frontendUrl = (
      this.configService.get<string>('google.frontendUrl') ?? ''
    ).replace(/\/+$/, '');

    const state =
      typeof req.query.state === 'string' ? req.query.state : undefined;
    const deviceHint = this.authService.verifyGoogleOAuthState(state);
    const nonceCookie = req.cookies?.[OAUTH_NONCE_COOKIE];

    // One-time value: clear it before doing anything else.
    res.clearCookie(OAUTH_NONCE_COOKIE, { path: '/' });

    if (
      !deviceHint ||
      !deviceHint.nonce ||
      typeof nonceCookie !== 'string' ||
      nonceCookie !== deviceHint.nonce
    ) {
      return res.redirect(
        `${frontendUrl}/auth/callback?error=${encodeURIComponent(
          'Sign-in could not be verified. Please try again.',
        )}`,
      );
    }

    const result = await this.authService.googleLogin(
      user,
      this.loginContext(req),
      deviceHint,
    );

    if (result.status === 'conflict') {
      // Keep the approval token out of server logs and referrer headers by
      // delivering it in the URL fragment, which browsers never send upstream.
      const payload = Buffer.from(
        JSON.stringify(result.conflict),
        'utf8',
      ).toString('base64url');
      return res.redirect(
        `${frontendUrl}/auth/callback#deviceConflict=${payload}`,
      );
    }

    const params = new URLSearchParams({
      accessToken: result.accessToken,
      refreshToken: result.refreshToken,
    });
    return res.redirect(`${frontendUrl}/auth/callback?${params.toString()}`);
  }

  private currentSessionId(req: Request): string | undefined {
    const user = req.user as (User & { currentSessionId?: string }) | undefined;
    return user?.currentSessionId;
  }

  private loginContext(req: Request): StudentLoginContext {
    const headerDeviceId = req.headers['x-device-id'];
    return {
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      deviceId: Array.isArray(headerDeviceId)
        ? headerDeviceId[0]
        : headerDeviceId,
    };
  }
}
